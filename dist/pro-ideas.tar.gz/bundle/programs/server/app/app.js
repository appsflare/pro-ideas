var require = meteorInstall({"imports":{"api":{"ideas.js":["meteor/mongo","meteor/check",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// imports/api/ideas.js                                                                               //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
exports.__esModule = true;                                                                            //
exports.Ideas = undefined;                                                                            //
                                                                                                      //
var _mongo = require('meteor/mongo');                                                                 // 1
                                                                                                      //
var _check = require('meteor/check');                                                                 // 4
                                                                                                      //
var Ideas = exports.Ideas = new _mongo.Mongo.Collection('ideas');                                     // 3
                                                                                                      //
                                                                                                      //
Meteor.methods({                                                                                      // 7
  'ideas.insert': function () {                                                                       // 8
    function ideasInsert(name, description) {                                                         //
      (0, _check.check)(name, String);                                                                // 9
      (0, _check.check)(description, String);                                                         // 10
                                                                                                      //
      // Make sure the user is logged in before inserting a task                                      //
      if (!this.userId) {                                                                             // 8
        throw new Meteor.Error('not-authorized');                                                     // 14
      }                                                                                               //
                                                                                                      //
      var userEmail = Meteor.user().emails[0].address;                                                // 17
                                                                                                      //
      Ideas.insert({                                                                                  // 19
        name: name,                                                                                   // 20
        description: description,                                                                     // 21
        createdAt: new Date(),                                                                        // 22
        owner: this.userId,                                                                           // 23
        ownerName: userEmail                                                                          // 24
      });                                                                                             //
    }                                                                                                 //
                                                                                                      //
    return ideasInsert;                                                                               //
  }(),                                                                                                //
  'ideas.calcVotes': function () {                                                                    // 27
    function ideasCalcVotes(ideaId) {                                                                 //
                                                                                                      //
      // Make sure the user is logged in before inserting a task                                      //
      if (!this.userId) {                                                                             // 30
        throw new Meteor.Error('not-authorized');                                                     // 31
      }                                                                                               //
                                                                                                      //
      var idea = Ideas.findOne(ideaId);                                                               // 34
                                                                                                      //
      if (!idea) {                                                                                    // 36
        throw new Meteor.Error('idea-not-found');                                                     // 38
      }                                                                                               //
                                                                                                      //
      var stats = Meteor.call('votes.getStats', ideaId);                                              // 41
      Ideas.update(ideaId, { $set: stats });                                                          // 42
    }                                                                                                 //
                                                                                                      //
    return ideasCalcVotes;                                                                            //
  }(),                                                                                                //
  'ideas.update': function () {                                                                       // 45
    function ideasUpdate(ideaId, data) {                                                              //
      (0, _check.check)(data, Object);                                                                // 46
      (0, _check.check)(data.name, String);                                                           // 47
      (0, _check.check)(data.description, String);                                                    // 48
                                                                                                      //
      var idea = Ideas.findOne(ideaId);                                                               // 51
                                                                                                      //
      if (!this.userId) {                                                                             // 53
        throw new Meteor.Error('not-authorized');                                                     // 54
      }                                                                                               //
                                                                                                      //
      Ideas.update(ideaId, { $set: { name: name, description: description } });                       // 58
    }                                                                                                 //
                                                                                                      //
    return ideasUpdate;                                                                               //
  }(),                                                                                                //
  'ideas.remove': function () {                                                                       // 60
    function ideasRemove(ideaId) {                                                                    //
      (0, _check.check)(ideaId, String);                                                              // 61
                                                                                                      //
      var idea = Ideas.findOne(ideaId);                                                               // 63
                                                                                                      //
      if (!this.userId) {                                                                             // 65
        throw new Meteor.Error('not-authorized');                                                     // 66
      }                                                                                               //
                                                                                                      //
      Ideas.remove(ideaId);                                                                           // 70
    }                                                                                                 //
                                                                                                      //
    return ideasRemove;                                                                               //
  }()                                                                                                 //
});                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"votes.js":["meteor/mongo","meteor/check",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// imports/api/votes.js                                                                               //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
exports.__esModule = true;                                                                            //
exports.Votes = undefined;                                                                            //
                                                                                                      //
var _mongo = require('meteor/mongo');                                                                 // 1
                                                                                                      //
var _check = require('meteor/check');                                                                 // 2
                                                                                                      //
var Votes = exports.Votes = new _mongo.Mongo.Collection('votes');                                     // 4
                                                                                                      //
function getVotesCount(ideaId, isUpvote) {                                                            // 6
    return Votes.find({ idea: ideaId, isUpVote: isUpvote }).count();                                  // 7
}                                                                                                     //
                                                                                                      //
Meteor.methods({                                                                                      // 11
    'votes.getStats': function () {                                                                   // 12
        function votesGetStats(ideaId) {                                                              //
            return { upVotes: getVotesCount(ideaId, true), downVotes: getVotesCount(ideaId, false) };
        }                                                                                             //
                                                                                                      //
        return votesGetStats;                                                                         //
    }(),                                                                                              //
    'votes.cast': function () {                                                                       // 15
        function votesCast(ideaId, isUpVote) {                                                        //
                                                                                                      //
            (0, _check.check)(isUpVote, Boolean);                                                     // 17
                                                                                                      //
            if (!this.userId) {                                                                       // 19
                throw new Meteor.Error('not-authorized');                                             // 20
            }                                                                                         //
                                                                                                      //
            var castedVote = Votes.findOne({ idea: ideaId, user: this.userId });                      // 24
            if (!castedVote) {                                                                        // 25
                Votes.insert({ idea: ideaId, user: this.userId, isUpVote: isUpVote });                // 26
            } else {                                                                                  //
                Votes.update(castedVote._id, { $set: { idea: ideaId, isUpVote: isUpVote } });         // 28
            }                                                                                         //
                                                                                                      //
            Meteor.call('ideas.calcVotes', ideaId);                                                   // 31
        }                                                                                             //
                                                                                                      //
        return votesCast;                                                                             //
    }()                                                                                               //
});                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["../imports/api/ideas.js","../imports/api/votes.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// server/main.js                                                                                     //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
require('../imports/api/ideas.js');                                                                   // 1
                                                                                                      //
require('../imports/api/votes.js');                                                                   // 2
////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
