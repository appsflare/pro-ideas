(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var XMLHttpRequest, $__curScript, bestDetph;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/universe_modules/packages/universe_modules.js            //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe:modules/vendor/xhr2.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
XMLHttpRequest = Npm.require('xhr2');                                                                                  // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe:modules/vendor/system-polyfills.js                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/*                                                                                                                     // 1
 * SystemJS Polyfills for URL and Promise providing IE8+ Support                                                       // 2
 */                                                                                                                    // 3
// from https://gist.github.com/Yaffle/1088850                                                                         // 4
function URLPolyfill(url, baseURL) {                                                                                   // 5
    if (typeof url != 'string')                                                                                        // 6
        throw new TypeError('URL must be a string');                                                                   // 7
    var m = String(url).replace(/^\s+|\s+$/g, "").match(/^([^:\/?#]+:)?(?:\/\/(?:([^:@\/?#]*)(?::([^:@\/?#]*))?@)?(([^:\/?#]*)(?::(\d*))?))?([^?#]*)(\?[^#]*)?(#[\s\S]*)?/);
    if (!m) {                                                                                                          // 9
        throw new RangeError();                                                                                        // 10
    }                                                                                                                  // 11
    var protocol = m[1] || "";                                                                                         // 12
    var username = m[2] || "";                                                                                         // 13
    var password = m[3] || "";                                                                                         // 14
    var host = m[4] || "";                                                                                             // 15
    var hostname = m[5] || "";                                                                                         // 16
    var port = m[6] || "";                                                                                             // 17
    var pathname = m[7] || "";                                                                                         // 18
    var search = m[8] || "";                                                                                           // 19
    var hash = m[9] || "";                                                                                             // 20
    if (baseURL !== undefined) {                                                                                       // 21
        var base = baseURL instanceof URLPolyfill ? baseURL : new URLPolyfill(baseURL);                                // 22
        var flag = protocol === "" && host === "" && username === "";                                                  // 23
        if (flag && pathname === "" && search === "") {                                                                // 24
            search = base.search;                                                                                      // 25
        }                                                                                                              // 26
        if (flag && pathname.charAt(0) !== "/") {                                                                      // 27
            pathname = (pathname !== "" ? (((base.host !== "" || base.username !== "") && base.pathname === "" ? "/" : "") + base.pathname.slice(0, base.pathname.lastIndexOf("/") + 1) + pathname) : base.pathname);
        }                                                                                                              // 29
        // dot segments removal                                                                                        // 30
        var output = [];                                                                                               // 31
        pathname.replace(/^(\.\.?(\/|$))+/, "")                                                                        // 32
            .replace(/\/(\.(\/|$))+/g, "/")                                                                            // 33
            .replace(/\/\.\.$/, "/../")                                                                                // 34
            .replace(/\/?[^\/]*/g, function (p) {                                                                      // 35
                if (p === "/..") {                                                                                     // 36
                    output.pop();                                                                                      // 37
                } else {                                                                                               // 38
                    output.push(p);                                                                                    // 39
                }                                                                                                      // 40
            });                                                                                                        // 41
        pathname = output.join("").replace(/^\//, pathname.charAt(0) === "/" ? "/" : "");                              // 42
        if (flag) {                                                                                                    // 43
            port = base.port;                                                                                          // 44
            hostname = base.hostname;                                                                                  // 45
            host = base.host;                                                                                          // 46
            password = base.password;                                                                                  // 47
            username = base.username;                                                                                  // 48
        }                                                                                                              // 49
        if (protocol === "") {                                                                                         // 50
            protocol = base.protocol;                                                                                  // 51
        }                                                                                                              // 52
    }                                                                                                                  // 53
                                                                                                                       // 54
    // convert windows file URLs to use /                                                                              // 55
    if (protocol == 'file:')                                                                                           // 56
        pathname = pathname.replace(/\\/g, '/');                                                                       // 57
                                                                                                                       // 58
    this.origin = protocol + (protocol !== "" || host !== "" ? "//" : "") + host;                                      // 59
    this.href = protocol + (protocol !== "" || host !== "" ? "//" : "") + (username !== "" ? username + (password !== "" ? ":" + password : "") + "@" : "") + host + pathname + search + hash;
    this.protocol = protocol;                                                                                          // 61
    this.username = username;                                                                                          // 62
    this.password = password;                                                                                          // 63
    this.host = host;                                                                                                  // 64
    this.hostname = hostname;                                                                                          // 65
    this.port = port;                                                                                                  // 66
    this.pathname = pathname;                                                                                          // 67
    this.search = search;                                                                                              // 68
    this.hash = hash;                                                                                                  // 69
}                                                                                                                      // 70
(typeof self != 'undefined' ? self : global).URLPolyfill = URLPolyfill;!function(e){"object"==typeof exports?module.exports=e():"function"==typeof define&&define.amd?define(e):"undefined"!=typeof window?window.Promise=e():"undefined"!=typeof global?global.Promise=e():"undefined"!=typeof self&&(self.Promise=e())}(function(){var define,module,exports;return (function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
    /** @license MIT License (c) copyright 2010-2014 original author or authors */                                     // 72
    /** @author Brian Cavalier */                                                                                      // 73
    /** @author John Hann */                                                                                           // 74
                                                                                                                       // 75
    /**                                                                                                                // 76
     * ES6 global Promise shim                                                                                         // 77
     */                                                                                                                // 78
    var unhandledRejections = require('../lib/decorators/unhandledRejection');                                         // 79
    var PromiseConstructor = unhandledRejections(require('../lib/Promise'));                                           // 80
                                                                                                                       // 81
    module.exports = typeof global != 'undefined' ? (global.Promise = PromiseConstructor)                              // 82
        : typeof self   != 'undefined' ? (self.Promise   = PromiseConstructor)                                         // 83
        : PromiseConstructor;                                                                                          // 84
                                                                                                                       // 85
},{"../lib/Promise":2,"../lib/decorators/unhandledRejection":4}],2:[function(require,module,exports){                  // 86
    /** @license MIT License (c) copyright 2010-2014 original author or authors */                                     // 87
    /** @author Brian Cavalier */                                                                                      // 88
    /** @author John Hann */                                                                                           // 89
                                                                                                                       // 90
    (function(define) { 'use strict';                                                                                  // 91
        define(function (require) {                                                                                    // 92
                                                                                                                       // 93
            var makePromise = require('./makePromise');                                                                // 94
            var Scheduler = require('./Scheduler');                                                                    // 95
            var async = require('./env').asap;                                                                         // 96
                                                                                                                       // 97
            return makePromise({                                                                                       // 98
                scheduler: new Scheduler(async)                                                                        // 99
            });                                                                                                        // 100
                                                                                                                       // 101
        });                                                                                                            // 102
    })(typeof define === 'function' && define.amd ? define : function (factory) { module.exports = factory(require); });
                                                                                                                       // 104
},{"./Scheduler":3,"./env":5,"./makePromise":7}],3:[function(require,module,exports){                                  // 105
    /** @license MIT License (c) copyright 2010-2014 original author or authors */                                     // 106
    /** @author Brian Cavalier */                                                                                      // 107
    /** @author John Hann */                                                                                           // 108
                                                                                                                       // 109
    (function(define) { 'use strict';                                                                                  // 110
        define(function() {                                                                                            // 111
                                                                                                                       // 112
            // Credit to Twisol (https://github.com/Twisol) for suggesting                                             // 113
            // this type of extensible queue + trampoline approach for next-tick conflation.                           // 114
                                                                                                                       // 115
            /**                                                                                                        // 116
             * Async task scheduler                                                                                    // 117
             * @param {function} async function to schedule a single async function                                    // 118
             * @constructor                                                                                            // 119
             */                                                                                                        // 120
            function Scheduler(async) {                                                                                // 121
                this._async = async;                                                                                   // 122
                this._running = false;                                                                                 // 123
                                                                                                                       // 124
                this._queue = this;                                                                                    // 125
                this._queueLen = 0;                                                                                    // 126
                this._afterQueue = {};                                                                                 // 127
                this._afterQueueLen = 0;                                                                               // 128
                                                                                                                       // 129
                var self = this;                                                                                       // 130
                this.drain = function() {                                                                              // 131
                    self._drain();                                                                                     // 132
                };                                                                                                     // 133
            }                                                                                                          // 134
                                                                                                                       // 135
            /**                                                                                                        // 136
             * Enqueue a task                                                                                          // 137
             * @param {{ run:function }} task                                                                          // 138
             */                                                                                                        // 139
            Scheduler.prototype.enqueue = function(task) {                                                             // 140
                this._queue[this._queueLen++] = task;                                                                  // 141
                this.run();                                                                                            // 142
            };                                                                                                         // 143
                                                                                                                       // 144
            /**                                                                                                        // 145
             * Enqueue a task to run after the main task queue                                                         // 146
             * @param {{ run:function }} task                                                                          // 147
             */                                                                                                        // 148
            Scheduler.prototype.afterQueue = function(task) {                                                          // 149
                this._afterQueue[this._afterQueueLen++] = task;                                                        // 150
                this.run();                                                                                            // 151
            };                                                                                                         // 152
                                                                                                                       // 153
            Scheduler.prototype.run = function() {                                                                     // 154
                if (!this._running) {                                                                                  // 155
                    this._running = true;                                                                              // 156
                    this._async(this.drain);                                                                           // 157
                }                                                                                                      // 158
            };                                                                                                         // 159
                                                                                                                       // 160
            /**                                                                                                        // 161
             * Drain the handler queue entirely, and then the after queue                                              // 162
             */                                                                                                        // 163
            Scheduler.prototype._drain = function() {                                                                  // 164
                var i = 0;                                                                                             // 165
                for (; i < this._queueLen; ++i) {                                                                      // 166
                    this._queue[i].run();                                                                              // 167
                    this._queue[i] = void 0;                                                                           // 168
                }                                                                                                      // 169
                                                                                                                       // 170
                this._queueLen = 0;                                                                                    // 171
                this._running = false;                                                                                 // 172
                                                                                                                       // 173
                for (i = 0; i < this._afterQueueLen; ++i) {                                                            // 174
                    this._afterQueue[i].run();                                                                         // 175
                    this._afterQueue[i] = void 0;                                                                      // 176
                }                                                                                                      // 177
                                                                                                                       // 178
                this._afterQueueLen = 0;                                                                               // 179
            };                                                                                                         // 180
                                                                                                                       // 181
            return Scheduler;                                                                                          // 182
                                                                                                                       // 183
        });                                                                                                            // 184
    }(typeof define === 'function' && define.amd ? define : function(factory) { module.exports = factory(); }));       // 185
                                                                                                                       // 186
},{}],4:[function(require,module,exports){                                                                             // 187
    /** @license MIT License (c) copyright 2010-2014 original author or authors */                                     // 188
    /** @author Brian Cavalier */                                                                                      // 189
    /** @author John Hann */                                                                                           // 190
                                                                                                                       // 191
    (function(define) { 'use strict';                                                                                  // 192
        define(function(require) {                                                                                     // 193
                                                                                                                       // 194
            var setTimer = require('../env').setTimer;                                                                 // 195
            var format = require('../format');                                                                         // 196
                                                                                                                       // 197
            return function unhandledRejection(Promise) {                                                              // 198
                                                                                                                       // 199
                var logError = noop;                                                                                   // 200
                var logInfo = noop;                                                                                    // 201
                var localConsole;                                                                                      // 202
                                                                                                                       // 203
                if(typeof console !== 'undefined') {                                                                   // 204
                    // Alias console to prevent things like uglify's drop_console option from                          // 205
                    // removing console.log/error. Unhandled rejections fall into the same                             // 206
                    // category as uncaught exceptions, and build tools shouldn't silence them.                        // 207
                    localConsole = console;                                                                            // 208
                    logError = typeof localConsole.error !== 'undefined'                                               // 209
                        ? function (e) { localConsole.error(e); }                                                      // 210
                        : function (e) { localConsole.log(e); };                                                       // 211
                                                                                                                       // 212
                    logInfo = typeof localConsole.info !== 'undefined'                                                 // 213
                        ? function (e) { localConsole.info(e); }                                                       // 214
                        : function (e) { localConsole.log(e); };                                                       // 215
                }                                                                                                      // 216
                                                                                                                       // 217
                Promise.onPotentiallyUnhandledRejection = function(rejection) {                                        // 218
                    enqueue(report, rejection);                                                                        // 219
                };                                                                                                     // 220
                                                                                                                       // 221
                Promise.onPotentiallyUnhandledRejectionHandled = function(rejection) {                                 // 222
                    enqueue(unreport, rejection);                                                                      // 223
                };                                                                                                     // 224
                                                                                                                       // 225
                Promise.onFatalRejection = function(rejection) {                                                       // 226
                    enqueue(throwit, rejection.value);                                                                 // 227
                };                                                                                                     // 228
                                                                                                                       // 229
                var tasks = [];                                                                                        // 230
                var reported = [];                                                                                     // 231
                var running = null;                                                                                    // 232
                                                                                                                       // 233
                function report(r) {                                                                                   // 234
                    if(!r.handled) {                                                                                   // 235
                        reported.push(r);                                                                              // 236
                        logError('Potentially unhandled rejection [' + r.id + '] ' + format.formatError(r.value));     // 237
                    }                                                                                                  // 238
                }                                                                                                      // 239
                                                                                                                       // 240
                function unreport(r) {                                                                                 // 241
                    var i = reported.indexOf(r);                                                                       // 242
                    if(i >= 0) {                                                                                       // 243
                        reported.splice(i, 1);                                                                         // 244
                        logInfo('Handled previous rejection [' + r.id + '] ' + format.formatObject(r.value));          // 245
                    }                                                                                                  // 246
                }                                                                                                      // 247
                                                                                                                       // 248
                function enqueue(f, x) {                                                                               // 249
                    tasks.push(f, x);                                                                                  // 250
                    if(running === null) {                                                                             // 251
                        running = setTimer(flush, 0);                                                                  // 252
                    }                                                                                                  // 253
                }                                                                                                      // 254
                                                                                                                       // 255
                function flush() {                                                                                     // 256
                    running = null;                                                                                    // 257
                    while(tasks.length > 0) {                                                                          // 258
                        tasks.shift()(tasks.shift());                                                                  // 259
                    }                                                                                                  // 260
                }                                                                                                      // 261
                                                                                                                       // 262
                return Promise;                                                                                        // 263
            };                                                                                                         // 264
                                                                                                                       // 265
            function throwit(e) {                                                                                      // 266
                throw e;                                                                                               // 267
            }                                                                                                          // 268
                                                                                                                       // 269
            function noop() {}                                                                                         // 270
                                                                                                                       // 271
        });                                                                                                            // 272
    }(typeof define === 'function' && define.amd ? define : function(factory) { module.exports = factory(require); }));
                                                                                                                       // 274
},{"../env":5,"../format":6}],5:[function(require,module,exports){                                                     // 275
    /** @license MIT License (c) copyright 2010-2014 original author or authors */                                     // 276
    /** @author Brian Cavalier */                                                                                      // 277
    /** @author John Hann */                                                                                           // 278
                                                                                                                       // 279
    /*global process,document,setTimeout,clearTimeout,MutationObserver,WebKitMutationObserver*/                        // 280
    (function(define) { 'use strict';                                                                                  // 281
        define(function(require) {                                                                                     // 282
            /*jshint maxcomplexity:6*/                                                                                 // 283
                                                                                                                       // 284
            // Sniff "best" async scheduling option                                                                    // 285
            // Prefer process.nextTick or MutationObserver, then check for                                             // 286
            // setTimeout, and finally vertx, since its the only env that doesn't                                      // 287
            // have setTimeout                                                                                         // 288
                                                                                                                       // 289
            var MutationObs;                                                                                           // 290
            var capturedSetTimeout = typeof setTimeout !== 'undefined' && setTimeout;                                  // 291
                                                                                                                       // 292
            // Default env                                                                                             // 293
            var setTimer = function(f, ms) { return setTimeout(f, ms); };                                              // 294
            var clearTimer = function(t) { return clearTimeout(t); };                                                  // 295
            var asap = function (f) { return capturedSetTimeout(f, 0); };                                              // 296
                                                                                                                       // 297
            // Detect specific env                                                                                     // 298
            if (isNode()) { // Node                                                                                    // 299
                asap = function (f) { return process.nextTick(f); };                                                   // 300
                                                                                                                       // 301
            } else if (MutationObs = hasMutationObserver()) { // Modern browser                                        // 302
                asap = initMutationObserver(MutationObs);                                                              // 303
                                                                                                                       // 304
            } else if (!capturedSetTimeout) { // vert.x                                                                // 305
                var vertxRequire = require;                                                                            // 306
                var vertx = vertxRequire('vertx');                                                                     // 307
                setTimer = function (f, ms) { return vertx.setTimer(ms, f); };                                         // 308
                clearTimer = vertx.cancelTimer;                                                                        // 309
                asap = vertx.runOnLoop || vertx.runOnContext;                                                          // 310
            }                                                                                                          // 311
                                                                                                                       // 312
            return {                                                                                                   // 313
                setTimer: setTimer,                                                                                    // 314
                clearTimer: clearTimer,                                                                                // 315
                asap: asap                                                                                             // 316
            };                                                                                                         // 317
                                                                                                                       // 318
            function isNode () {                                                                                       // 319
                return typeof process !== 'undefined' && process !== null &&                                           // 320
                    typeof process.nextTick === 'function';                                                            // 321
            }                                                                                                          // 322
                                                                                                                       // 323
            function hasMutationObserver () {                                                                          // 324
                return (typeof MutationObserver === 'function' && MutationObserver) ||                                 // 325
                    (typeof WebKitMutationObserver === 'function' && WebKitMutationObserver);                          // 326
            }                                                                                                          // 327
                                                                                                                       // 328
            function initMutationObserver(MutationObserver) {                                                          // 329
                var scheduled;                                                                                         // 330
                var node = document.createTextNode('');                                                                // 331
                var o = new MutationObserver(run);                                                                     // 332
                o.observe(node, { characterData: true });                                                              // 333
                                                                                                                       // 334
                function run() {                                                                                       // 335
                    var f = scheduled;                                                                                 // 336
                    scheduled = void 0;                                                                                // 337
                    f();                                                                                               // 338
                }                                                                                                      // 339
                                                                                                                       // 340
                var i = 0;                                                                                             // 341
                return function (f) {                                                                                  // 342
                    scheduled = f;                                                                                     // 343
                    node.data = (i ^= 1);                                                                              // 344
                };                                                                                                     // 345
            }                                                                                                          // 346
        });                                                                                                            // 347
    }(typeof define === 'function' && define.amd ? define : function(factory) { module.exports = factory(require); }));
                                                                                                                       // 349
},{}],6:[function(require,module,exports){                                                                             // 350
    /** @license MIT License (c) copyright 2010-2014 original author or authors */                                     // 351
    /** @author Brian Cavalier */                                                                                      // 352
    /** @author John Hann */                                                                                           // 353
                                                                                                                       // 354
    (function(define) { 'use strict';                                                                                  // 355
        define(function() {                                                                                            // 356
                                                                                                                       // 357
            return {                                                                                                   // 358
                formatError: formatError,                                                                              // 359
                formatObject: formatObject,                                                                            // 360
                tryStringify: tryStringify                                                                             // 361
            };                                                                                                         // 362
                                                                                                                       // 363
            /**                                                                                                        // 364
             * Format an error into a string.  If e is an Error and has a stack property,                              // 365
             * it's returned.  Otherwise, e is formatted using formatObject, with a                                    // 366
             * warning added about e not being a proper Error.                                                         // 367
             * @param {*} e                                                                                            // 368
             * @returns {String} formatted string, suitable for output to developers                                   // 369
             */                                                                                                        // 370
            function formatError(e) {                                                                                  // 371
                var s = typeof e === 'object' && e !== null && e.stack ? e.stack : formatObject(e);                    // 372
                return e instanceof Error ? s : s + ' (WARNING: non-Error used)';                                      // 373
            }                                                                                                          // 374
                                                                                                                       // 375
            /**                                                                                                        // 376
             * Format an object, detecting "plain" objects and running them through                                    // 377
             * JSON.stringify if possible.                                                                             // 378
             * @param {Object} o                                                                                       // 379
             * @returns {string}                                                                                       // 380
             */                                                                                                        // 381
            function formatObject(o) {                                                                                 // 382
                var s = String(o);                                                                                     // 383
                if(s === '[object Object]' && typeof JSON !== 'undefined') {                                           // 384
                    s = tryStringify(o, s);                                                                            // 385
                }                                                                                                      // 386
                return s;                                                                                              // 387
            }                                                                                                          // 388
                                                                                                                       // 389
            /**                                                                                                        // 390
             * Try to return the result of JSON.stringify(x).  If that fails, return                                   // 391
             * defaultValue                                                                                            // 392
             * @param {*} x                                                                                            // 393
             * @param {*} defaultValue                                                                                 // 394
             * @returns {String|*} JSON.stringify(x) or defaultValue                                                   // 395
             */                                                                                                        // 396
            function tryStringify(x, defaultValue) {                                                                   // 397
                try {                                                                                                  // 398
                    return JSON.stringify(x);                                                                          // 399
                } catch(e) {                                                                                           // 400
                    return defaultValue;                                                                               // 401
                }                                                                                                      // 402
            }                                                                                                          // 403
                                                                                                                       // 404
        });                                                                                                            // 405
    }(typeof define === 'function' && define.amd ? define : function(factory) { module.exports = factory(); }));       // 406
                                                                                                                       // 407
},{}],7:[function(require,module,exports){                                                                             // 408
    /** @license MIT License (c) copyright 2010-2014 original author or authors */                                     // 409
    /** @author Brian Cavalier */                                                                                      // 410
    /** @author John Hann */                                                                                           // 411
                                                                                                                       // 412
    (function(define) { 'use strict';                                                                                  // 413
        define(function() {                                                                                            // 414
                                                                                                                       // 415
            return function makePromise(environment) {                                                                 // 416
                                                                                                                       // 417
                var tasks = environment.scheduler;                                                                     // 418
                var emitRejection = initEmitRejection();                                                               // 419
                                                                                                                       // 420
                var objectCreate = Object.create ||                                                                    // 421
                    function(proto) {                                                                                  // 422
                        function Child() {}                                                                            // 423
                        Child.prototype = proto;                                                                       // 424
                        return new Child();                                                                            // 425
                    };                                                                                                 // 426
                                                                                                                       // 427
                /**                                                                                                    // 428
                 * Create a promise whose fate is determined by resolver                                               // 429
                 * @constructor                                                                                        // 430
                 * @returns {Promise} promise                                                                          // 431
                 * @name Promise                                                                                       // 432
                 */                                                                                                    // 433
                function Promise(resolver, handler) {                                                                  // 434
                    this._handler = resolver === Handler ? handler : init(resolver);                                   // 435
                }                                                                                                      // 436
                                                                                                                       // 437
                /**                                                                                                    // 438
                 * Run the supplied resolver                                                                           // 439
                 * @param resolver                                                                                     // 440
                 * @returns {Pending}                                                                                  // 441
                 */                                                                                                    // 442
                function init(resolver) {                                                                              // 443
                    var handler = new Pending();                                                                       // 444
                                                                                                                       // 445
                    try {                                                                                              // 446
                        resolver(promiseResolve, promiseReject, promiseNotify);                                        // 447
                    } catch (e) {                                                                                      // 448
                        promiseReject(e);                                                                              // 449
                    }                                                                                                  // 450
                                                                                                                       // 451
                    return handler;                                                                                    // 452
                                                                                                                       // 453
                    /**                                                                                                // 454
                     * Transition from pre-resolution state to post-resolution state, notifying                        // 455
                     * all listeners of the ultimate fulfillment or rejection                                          // 456
                     * @param {*} x resolution value                                                                   // 457
                     */                                                                                                // 458
                    function promiseResolve (x) {                                                                      // 459
                        handler.resolve(x);                                                                            // 460
                    }                                                                                                  // 461
                    /**                                                                                                // 462
                     * Reject this promise with reason, which will be used verbatim                                    // 463
                     * @param {Error|*} reason rejection reason, strongly suggested                                    // 464
                     *   to be an Error type                                                                           // 465
                     */                                                                                                // 466
                    function promiseReject (reason) {                                                                  // 467
                        handler.reject(reason);                                                                        // 468
                    }                                                                                                  // 469
                                                                                                                       // 470
                    /**                                                                                                // 471
                     * @deprecated                                                                                     // 472
                     * Issue a progress event, notifying all progress listeners                                        // 473
                     * @param {*} x progress event payload to pass to all listeners                                    // 474
                     */                                                                                                // 475
                    function promiseNotify (x) {                                                                       // 476
                        handler.notify(x);                                                                             // 477
                    }                                                                                                  // 478
                }                                                                                                      // 479
                                                                                                                       // 480
                // Creation                                                                                            // 481
                                                                                                                       // 482
                Promise.resolve = resolve;                                                                             // 483
                Promise.reject = reject;                                                                               // 484
                Promise.never = never;                                                                                 // 485
                                                                                                                       // 486
                Promise._defer = defer;                                                                                // 487
                Promise._handler = getHandler;                                                                         // 488
                                                                                                                       // 489
                /**                                                                                                    // 490
                 * Returns a trusted promise. If x is already a trusted promise, it is                                 // 491
                 * returned, otherwise returns a new trusted Promise which follows x.                                  // 492
                 * @param  {*} x                                                                                       // 493
                 * @return {Promise} promise                                                                           // 494
                 */                                                                                                    // 495
                function resolve(x) {                                                                                  // 496
                    return isPromise(x) ? x                                                                            // 497
                        : new Promise(Handler, new Async(getHandler(x)));                                              // 498
                }                                                                                                      // 499
                                                                                                                       // 500
                /**                                                                                                    // 501
                 * Return a reject promise with x as its reason (x is used verbatim)                                   // 502
                 * @param {*} x                                                                                        // 503
                 * @returns {Promise} rejected promise                                                                 // 504
                 */                                                                                                    // 505
                function reject(x) {                                                                                   // 506
                    return new Promise(Handler, new Async(new Rejected(x)));                                           // 507
                }                                                                                                      // 508
                                                                                                                       // 509
                /**                                                                                                    // 510
                 * Return a promise that remains pending forever                                                       // 511
                 * @returns {Promise} forever-pending promise.                                                         // 512
                 */                                                                                                    // 513
                function never() {                                                                                     // 514
                    return foreverPendingPromise; // Should be frozen                                                  // 515
                }                                                                                                      // 516
                                                                                                                       // 517
                /**                                                                                                    // 518
                 * Creates an internal {promise, resolver} pair                                                        // 519
                 * @private                                                                                            // 520
                 * @returns {Promise}                                                                                  // 521
                 */                                                                                                    // 522
                function defer() {                                                                                     // 523
                    return new Promise(Handler, new Pending());                                                        // 524
                }                                                                                                      // 525
                                                                                                                       // 526
                // Transformation and flow control                                                                     // 527
                                                                                                                       // 528
                /**                                                                                                    // 529
                 * Transform this promise's fulfillment value, returning a new Promise                                 // 530
                 * for the transformed result.  If the promise cannot be fulfilled, onRejected                         // 531
                 * is called with the reason.  onProgress *may* be called with updates toward                          // 532
                 * this promise's fulfillment.                                                                         // 533
                 * @param {function=} onFulfilled fulfillment handler                                                  // 534
                 * @param {function=} onRejected rejection handler                                                     // 535
                 * @param {function=} onProgress @deprecated progress handler                                          // 536
                 * @return {Promise} new promise                                                                       // 537
                 */                                                                                                    // 538
                Promise.prototype.then = function(onFulfilled, onRejected, onProgress) {                               // 539
                    var parent = this._handler;                                                                        // 540
                    var state = parent.join().state();                                                                 // 541
                                                                                                                       // 542
                    if ((typeof onFulfilled !== 'function' && state > 0) ||                                            // 543
                        (typeof onRejected !== 'function' && state < 0)) {                                             // 544
                        // Short circuit: value will not change, simply share handler                                  // 545
                        return new this.constructor(Handler, parent);                                                  // 546
                    }                                                                                                  // 547
                                                                                                                       // 548
                    var p = this._beget();                                                                             // 549
                    var child = p._handler;                                                                            // 550
                                                                                                                       // 551
                    parent.chain(child, parent.receiver, onFulfilled, onRejected, onProgress);                         // 552
                                                                                                                       // 553
                    return p;                                                                                          // 554
                };                                                                                                     // 555
                                                                                                                       // 556
                /**                                                                                                    // 557
                 * If this promise cannot be fulfilled due to an error, call onRejected to                             // 558
                 * handle the error. Shortcut for .then(undefined, onRejected)                                         // 559
                 * @param {function?} onRejected                                                                       // 560
                 * @return {Promise}                                                                                   // 561
                 */                                                                                                    // 562
                Promise.prototype['catch'] = function(onRejected) {                                                    // 563
                    return this.then(void 0, onRejected);                                                              // 564
                };                                                                                                     // 565
                                                                                                                       // 566
                /**                                                                                                    // 567
                 * Creates a new, pending promise of the same type as this promise                                     // 568
                 * @private                                                                                            // 569
                 * @returns {Promise}                                                                                  // 570
                 */                                                                                                    // 571
                Promise.prototype._beget = function() {                                                                // 572
                    return begetFrom(this._handler, this.constructor);                                                 // 573
                };                                                                                                     // 574
                                                                                                                       // 575
                function begetFrom(parent, Promise) {                                                                  // 576
                    var child = new Pending(parent.receiver, parent.join().context);                                   // 577
                    return new Promise(Handler, child);                                                                // 578
                }                                                                                                      // 579
                                                                                                                       // 580
                // Array combinators                                                                                   // 581
                                                                                                                       // 582
                Promise.all = all;                                                                                     // 583
                Promise.race = race;                                                                                   // 584
                Promise._traverse = traverse;                                                                          // 585
                                                                                                                       // 586
                /**                                                                                                    // 587
                 * Return a promise that will fulfill when all promises in the                                         // 588
                 * input array have fulfilled, or will reject when one of the                                          // 589
                 * promises rejects.                                                                                   // 590
                 * @param {array} promises array of promises                                                           // 591
                 * @returns {Promise} promise for array of fulfillment values                                          // 592
                 */                                                                                                    // 593
                function all(promises) {                                                                               // 594
                    return traverseWith(snd, null, promises);                                                          // 595
                }                                                                                                      // 596
                                                                                                                       // 597
                /**                                                                                                    // 598
                 * Array<Promise<X>> -> Promise<Array<f(X)>>                                                           // 599
                 * @private                                                                                            // 600
                 * @param {function} f function to apply to each promise's value                                       // 601
                 * @param {Array} promises array of promises                                                           // 602
                 * @returns {Promise} promise for transformed values                                                   // 603
                 */                                                                                                    // 604
                function traverse(f, promises) {                                                                       // 605
                    return traverseWith(tryCatch2, f, promises);                                                       // 606
                }                                                                                                      // 607
                                                                                                                       // 608
                function traverseWith(tryMap, f, promises) {                                                           // 609
                    var handler = typeof f === 'function' ? mapAt : settleAt;                                          // 610
                                                                                                                       // 611
                    var resolver = new Pending();                                                                      // 612
                    var pending = promises.length >>> 0;                                                               // 613
                    var results = new Array(pending);                                                                  // 614
                                                                                                                       // 615
                    for (var i = 0, x; i < promises.length && !resolver.resolved; ++i) {                               // 616
                        x = promises[i];                                                                               // 617
                                                                                                                       // 618
                        if (x === void 0 && !(i in promises)) {                                                        // 619
                            --pending;                                                                                 // 620
                            continue;                                                                                  // 621
                        }                                                                                              // 622
                                                                                                                       // 623
                        traverseAt(promises, handler, i, x, resolver);                                                 // 624
                    }                                                                                                  // 625
                                                                                                                       // 626
                    if(pending === 0) {                                                                                // 627
                        resolver.become(new Fulfilled(results));                                                       // 628
                    }                                                                                                  // 629
                                                                                                                       // 630
                    return new Promise(Handler, resolver);                                                             // 631
                                                                                                                       // 632
                    function mapAt(i, x, resolver) {                                                                   // 633
                        if(!resolver.resolved) {                                                                       // 634
                            traverseAt(promises, settleAt, i, tryMap(f, x, i), resolver);                              // 635
                        }                                                                                              // 636
                    }                                                                                                  // 637
                                                                                                                       // 638
                    function settleAt(i, x, resolver) {                                                                // 639
                        results[i] = x;                                                                                // 640
                        if(--pending === 0) {                                                                          // 641
                            resolver.become(new Fulfilled(results));                                                   // 642
                        }                                                                                              // 643
                    }                                                                                                  // 644
                }                                                                                                      // 645
                                                                                                                       // 646
                function traverseAt(promises, handler, i, x, resolver) {                                               // 647
                    if (maybeThenable(x)) {                                                                            // 648
                        var h = getHandlerMaybeThenable(x);                                                            // 649
                        var s = h.state();                                                                             // 650
                                                                                                                       // 651
                        if (s === 0) {                                                                                 // 652
                            h.fold(handler, i, void 0, resolver);                                                      // 653
                        } else if (s > 0) {                                                                            // 654
                            handler(i, h.value, resolver);                                                             // 655
                        } else {                                                                                       // 656
                            resolver.become(h);                                                                        // 657
                            visitRemaining(promises, i+1, h);                                                          // 658
                        }                                                                                              // 659
                    } else {                                                                                           // 660
                        handler(i, x, resolver);                                                                       // 661
                    }                                                                                                  // 662
                }                                                                                                      // 663
                                                                                                                       // 664
                Promise._visitRemaining = visitRemaining;                                                              // 665
                function visitRemaining(promises, start, handler) {                                                    // 666
                    for(var i=start; i<promises.length; ++i) {                                                         // 667
                        markAsHandled(getHandler(promises[i]), handler);                                               // 668
                    }                                                                                                  // 669
                }                                                                                                      // 670
                                                                                                                       // 671
                function markAsHandled(h, handler) {                                                                   // 672
                    if(h === handler) {                                                                                // 673
                        return;                                                                                        // 674
                    }                                                                                                  // 675
                                                                                                                       // 676
                    var s = h.state();                                                                                 // 677
                    if(s === 0) {                                                                                      // 678
                        h.visit(h, void 0, h._unreport);                                                               // 679
                    } else if(s < 0) {                                                                                 // 680
                        h._unreport();                                                                                 // 681
                    }                                                                                                  // 682
                }                                                                                                      // 683
                                                                                                                       // 684
                /**                                                                                                    // 685
                 * Fulfill-reject competitive race. Return a promise that will settle                                  // 686
                 * to the same state as the earliest input promise to settle.                                          // 687
                 *                                                                                                     // 688
                 * WARNING: The ES6 Promise spec requires that race()ing an empty array                                // 689
                 * must return a promise that is pending forever.  This implementation                                 // 690
                 * returns a singleton forever-pending promise, the same singleton that is                             // 691
                 * returned by Promise.never(), thus can be checked with ===                                           // 692
                 *                                                                                                     // 693
                 * @param {array} promises array of promises to race                                                   // 694
                 * @returns {Promise} if input is non-empty, a promise that will settle                                // 695
                 * to the same outcome as the earliest input promise to settle. if empty                               // 696
                 * is empty, returns a promise that will never settle.                                                 // 697
                 */                                                                                                    // 698
                function race(promises) {                                                                              // 699
                    if(typeof promises !== 'object' || promises === null) {                                            // 700
                        return reject(new TypeError('non-iterable passed to race()'));                                 // 701
                    }                                                                                                  // 702
                                                                                                                       // 703
                    // Sigh, race([]) is untestable unless we return *something*                                       // 704
                    // that is recognizable without calling .then() on it.                                             // 705
                    return promises.length === 0 ? never()                                                             // 706
                        : promises.length === 1 ? resolve(promises[0])                                                 // 707
                        : runRace(promises);                                                                           // 708
                }                                                                                                      // 709
                                                                                                                       // 710
                function runRace(promises) {                                                                           // 711
                    var resolver = new Pending();                                                                      // 712
                    var i, x, h;                                                                                       // 713
                    for(i=0; i<promises.length; ++i) {                                                                 // 714
                        x = promises[i];                                                                               // 715
                        if (x === void 0 && !(i in promises)) {                                                        // 716
                            continue;                                                                                  // 717
                        }                                                                                              // 718
                                                                                                                       // 719
                        h = getHandler(x);                                                                             // 720
                        if(h.state() !== 0) {                                                                          // 721
                            resolver.become(h);                                                                        // 722
                            visitRemaining(promises, i+1, h);                                                          // 723
                            break;                                                                                     // 724
                        } else {                                                                                       // 725
                            h.visit(resolver, resolver.resolve, resolver.reject);                                      // 726
                        }                                                                                              // 727
                    }                                                                                                  // 728
                    return new Promise(Handler, resolver);                                                             // 729
                }                                                                                                      // 730
                                                                                                                       // 731
                // Promise internals                                                                                   // 732
                // Below this, everything is @private                                                                  // 733
                                                                                                                       // 734
                /**                                                                                                    // 735
                 * Get an appropriate handler for x, without checking for cycles                                       // 736
                 * @param {*} x                                                                                        // 737
                 * @returns {object} handler                                                                           // 738
                 */                                                                                                    // 739
                function getHandler(x) {                                                                               // 740
                    if(isPromise(x)) {                                                                                 // 741
                        return x._handler.join();                                                                      // 742
                    }                                                                                                  // 743
                    return maybeThenable(x) ? getHandlerUntrusted(x) : new Fulfilled(x);                               // 744
                }                                                                                                      // 745
                                                                                                                       // 746
                /**                                                                                                    // 747
                 * Get a handler for thenable x.                                                                       // 748
                 * NOTE: You must only call this if maybeThenable(x) == true                                           // 749
                 * @param {object|function|Promise} x                                                                  // 750
                 * @returns {object} handler                                                                           // 751
                 */                                                                                                    // 752
                function getHandlerMaybeThenable(x) {                                                                  // 753
                    return isPromise(x) ? x._handler.join() : getHandlerUntrusted(x);                                  // 754
                }                                                                                                      // 755
                                                                                                                       // 756
                /**                                                                                                    // 757
                 * Get a handler for potentially untrusted thenable x                                                  // 758
                 * @param {*} x                                                                                        // 759
                 * @returns {object} handler                                                                           // 760
                 */                                                                                                    // 761
                function getHandlerUntrusted(x) {                                                                      // 762
                    try {                                                                                              // 763
                        var untrustedThen = x.then;                                                                    // 764
                        return typeof untrustedThen === 'function'                                                     // 765
                            ? new Thenable(untrustedThen, x)                                                           // 766
                            : new Fulfilled(x);                                                                        // 767
                    } catch(e) {                                                                                       // 768
                        return new Rejected(e);                                                                        // 769
                    }                                                                                                  // 770
                }                                                                                                      // 771
                                                                                                                       // 772
                /**                                                                                                    // 773
                 * Handler for a promise that is pending forever                                                       // 774
                 * @constructor                                                                                        // 775
                 */                                                                                                    // 776
                function Handler() {}                                                                                  // 777
                                                                                                                       // 778
                Handler.prototype.when                                                                                 // 779
                    = Handler.prototype.become                                                                         // 780
                    = Handler.prototype.notify // deprecated                                                           // 781
                    = Handler.prototype.fail                                                                           // 782
                    = Handler.prototype._unreport                                                                      // 783
                    = Handler.prototype._report                                                                        // 784
                    = noop;                                                                                            // 785
                                                                                                                       // 786
                Handler.prototype._state = 0;                                                                          // 787
                                                                                                                       // 788
                Handler.prototype.state = function() {                                                                 // 789
                    return this._state;                                                                                // 790
                };                                                                                                     // 791
                                                                                                                       // 792
                /**                                                                                                    // 793
                 * Recursively collapse handler chain to find the handler                                              // 794
                 * nearest to the fully resolved value.                                                                // 795
                 * @returns {object} handler nearest the fully resolved value                                          // 796
                 */                                                                                                    // 797
                Handler.prototype.join = function() {                                                                  // 798
                    var h = this;                                                                                      // 799
                    while(h.handler !== void 0) {                                                                      // 800
                        h = h.handler;                                                                                 // 801
                    }                                                                                                  // 802
                    return h;                                                                                          // 803
                };                                                                                                     // 804
                                                                                                                       // 805
                Handler.prototype.chain = function(to, receiver, fulfilled, rejected, progress) {                      // 806
                    this.when({                                                                                        // 807
                        resolver: to,                                                                                  // 808
                        receiver: receiver,                                                                            // 809
                        fulfilled: fulfilled,                                                                          // 810
                        rejected: rejected,                                                                            // 811
                        progress: progress                                                                             // 812
                    });                                                                                                // 813
                };                                                                                                     // 814
                                                                                                                       // 815
                Handler.prototype.visit = function(receiver, fulfilled, rejected, progress) {                          // 816
                    this.chain(failIfRejected, receiver, fulfilled, rejected, progress);                               // 817
                };                                                                                                     // 818
                                                                                                                       // 819
                Handler.prototype.fold = function(f, z, c, to) {                                                       // 820
                    this.when(new Fold(f, z, c, to));                                                                  // 821
                };                                                                                                     // 822
                                                                                                                       // 823
                /**                                                                                                    // 824
                 * Handler that invokes fail() on any handler it becomes                                               // 825
                 * @constructor                                                                                        // 826
                 */                                                                                                    // 827
                function FailIfRejected() {}                                                                           // 828
                                                                                                                       // 829
                inherit(Handler, FailIfRejected);                                                                      // 830
                                                                                                                       // 831
                FailIfRejected.prototype.become = function(h) {                                                        // 832
                    h.fail();                                                                                          // 833
                };                                                                                                     // 834
                                                                                                                       // 835
                var failIfRejected = new FailIfRejected();                                                             // 836
                                                                                                                       // 837
                /**                                                                                                    // 838
                 * Handler that manages a queue of consumers waiting on a pending promise                              // 839
                 * @constructor                                                                                        // 840
                 */                                                                                                    // 841
                function Pending(receiver, inheritedContext) {                                                         // 842
                    Promise.createContext(this, inheritedContext);                                                     // 843
                                                                                                                       // 844
                    this.consumers = void 0;                                                                           // 845
                    this.receiver = receiver;                                                                          // 846
                    this.handler = void 0;                                                                             // 847
                    this.resolved = false;                                                                             // 848
                }                                                                                                      // 849
                                                                                                                       // 850
                inherit(Handler, Pending);                                                                             // 851
                                                                                                                       // 852
                Pending.prototype._state = 0;                                                                          // 853
                                                                                                                       // 854
                Pending.prototype.resolve = function(x) {                                                              // 855
                    this.become(getHandler(x));                                                                        // 856
                };                                                                                                     // 857
                                                                                                                       // 858
                Pending.prototype.reject = function(x) {                                                               // 859
                    if(this.resolved) {                                                                                // 860
                        return;                                                                                        // 861
                    }                                                                                                  // 862
                                                                                                                       // 863
                    this.become(new Rejected(x));                                                                      // 864
                };                                                                                                     // 865
                                                                                                                       // 866
                Pending.prototype.join = function() {                                                                  // 867
                    if (!this.resolved) {                                                                              // 868
                        return this;                                                                                   // 869
                    }                                                                                                  // 870
                                                                                                                       // 871
                    var h = this;                                                                                      // 872
                                                                                                                       // 873
                    while (h.handler !== void 0) {                                                                     // 874
                        h = h.handler;                                                                                 // 875
                        if (h === this) {                                                                              // 876
                            return this.handler = cycle();                                                             // 877
                        }                                                                                              // 878
                    }                                                                                                  // 879
                                                                                                                       // 880
                    return h;                                                                                          // 881
                };                                                                                                     // 882
                                                                                                                       // 883
                Pending.prototype.run = function() {                                                                   // 884
                    var q = this.consumers;                                                                            // 885
                    var handler = this.handler;                                                                        // 886
                    this.handler = this.handler.join();                                                                // 887
                    this.consumers = void 0;                                                                           // 888
                                                                                                                       // 889
                    for (var i = 0; i < q.length; ++i) {                                                               // 890
                        handler.when(q[i]);                                                                            // 891
                    }                                                                                                  // 892
                };                                                                                                     // 893
                                                                                                                       // 894
                Pending.prototype.become = function(handler) {                                                         // 895
                    if(this.resolved) {                                                                                // 896
                        return;                                                                                        // 897
                    }                                                                                                  // 898
                                                                                                                       // 899
                    this.resolved = true;                                                                              // 900
                    this.handler = handler;                                                                            // 901
                    if(this.consumers !== void 0) {                                                                    // 902
                        tasks.enqueue(this);                                                                           // 903
                    }                                                                                                  // 904
                                                                                                                       // 905
                    if(this.context !== void 0) {                                                                      // 906
                        handler._report(this.context);                                                                 // 907
                    }                                                                                                  // 908
                };                                                                                                     // 909
                                                                                                                       // 910
                Pending.prototype.when = function(continuation) {                                                      // 911
                    if(this.resolved) {                                                                                // 912
                        tasks.enqueue(new ContinuationTask(continuation, this.handler));                               // 913
                    } else {                                                                                           // 914
                        if(this.consumers === void 0) {                                                                // 915
                            this.consumers = [continuation];                                                           // 916
                        } else {                                                                                       // 917
                            this.consumers.push(continuation);                                                         // 918
                        }                                                                                              // 919
                    }                                                                                                  // 920
                };                                                                                                     // 921
                                                                                                                       // 922
                /**                                                                                                    // 923
                 * @deprecated                                                                                         // 924
                 */                                                                                                    // 925
                Pending.prototype.notify = function(x) {                                                               // 926
                    if(!this.resolved) {                                                                               // 927
                        tasks.enqueue(new ProgressTask(x, this));                                                      // 928
                    }                                                                                                  // 929
                };                                                                                                     // 930
                                                                                                                       // 931
                Pending.prototype.fail = function(context) {                                                           // 932
                    var c = typeof context === 'undefined' ? this.context : context;                                   // 933
                    this.resolved && this.handler.join().fail(c);                                                      // 934
                };                                                                                                     // 935
                                                                                                                       // 936
                Pending.prototype._report = function(context) {                                                        // 937
                    this.resolved && this.handler.join()._report(context);                                             // 938
                };                                                                                                     // 939
                                                                                                                       // 940
                Pending.prototype._unreport = function() {                                                             // 941
                    this.resolved && this.handler.join()._unreport();                                                  // 942
                };                                                                                                     // 943
                                                                                                                       // 944
                /**                                                                                                    // 945
                 * Wrap another handler and force it into a future stack                                               // 946
                 * @param {object} handler                                                                             // 947
                 * @constructor                                                                                        // 948
                 */                                                                                                    // 949
                function Async(handler) {                                                                              // 950
                    this.handler = handler;                                                                            // 951
                }                                                                                                      // 952
                                                                                                                       // 953
                inherit(Handler, Async);                                                                               // 954
                                                                                                                       // 955
                Async.prototype.when = function(continuation) {                                                        // 956
                    tasks.enqueue(new ContinuationTask(continuation, this));                                           // 957
                };                                                                                                     // 958
                                                                                                                       // 959
                Async.prototype._report = function(context) {                                                          // 960
                    this.join()._report(context);                                                                      // 961
                };                                                                                                     // 962
                                                                                                                       // 963
                Async.prototype._unreport = function() {                                                               // 964
                    this.join()._unreport();                                                                           // 965
                };                                                                                                     // 966
                                                                                                                       // 967
                /**                                                                                                    // 968
                 * Handler that wraps an untrusted thenable and assimilates it in a future stack                       // 969
                 * @param {function} then                                                                              // 970
                 * @param {{then: function}} thenable                                                                  // 971
                 * @constructor                                                                                        // 972
                 */                                                                                                    // 973
                function Thenable(then, thenable) {                                                                    // 974
                    Pending.call(this);                                                                                // 975
                    tasks.enqueue(new AssimilateTask(then, thenable, this));                                           // 976
                }                                                                                                      // 977
                                                                                                                       // 978
                inherit(Pending, Thenable);                                                                            // 979
                                                                                                                       // 980
                /**                                                                                                    // 981
                 * Handler for a fulfilled promise                                                                     // 982
                 * @param {*} x fulfillment value                                                                      // 983
                 * @constructor                                                                                        // 984
                 */                                                                                                    // 985
                function Fulfilled(x) {                                                                                // 986
                    Promise.createContext(this);                                                                       // 987
                    this.value = x;                                                                                    // 988
                }                                                                                                      // 989
                                                                                                                       // 990
                inherit(Handler, Fulfilled);                                                                           // 991
                                                                                                                       // 992
                Fulfilled.prototype._state = 1;                                                                        // 993
                                                                                                                       // 994
                Fulfilled.prototype.fold = function(f, z, c, to) {                                                     // 995
                    runContinuation3(f, z, this, c, to);                                                               // 996
                };                                                                                                     // 997
                                                                                                                       // 998
                Fulfilled.prototype.when = function(cont) {                                                            // 999
                    runContinuation1(cont.fulfilled, this, cont.receiver, cont.resolver);                              // 1000
                };                                                                                                     // 1001
                                                                                                                       // 1002
                var errorId = 0;                                                                                       // 1003
                                                                                                                       // 1004
                /**                                                                                                    // 1005
                 * Handler for a rejected promise                                                                      // 1006
                 * @param {*} x rejection reason                                                                       // 1007
                 * @constructor                                                                                        // 1008
                 */                                                                                                    // 1009
                function Rejected(x) {                                                                                 // 1010
                    Promise.createContext(this);                                                                       // 1011
                                                                                                                       // 1012
                    this.id = ++errorId;                                                                               // 1013
                    this.value = x;                                                                                    // 1014
                    this.handled = false;                                                                              // 1015
                    this.reported = false;                                                                             // 1016
                                                                                                                       // 1017
                    this._report();                                                                                    // 1018
                }                                                                                                      // 1019
                                                                                                                       // 1020
                inherit(Handler, Rejected);                                                                            // 1021
                                                                                                                       // 1022
                Rejected.prototype._state = -1;                                                                        // 1023
                                                                                                                       // 1024
                Rejected.prototype.fold = function(f, z, c, to) {                                                      // 1025
                    to.become(this);                                                                                   // 1026
                };                                                                                                     // 1027
                                                                                                                       // 1028
                Rejected.prototype.when = function(cont) {                                                             // 1029
                    if(typeof cont.rejected === 'function') {                                                          // 1030
                        this._unreport();                                                                              // 1031
                    }                                                                                                  // 1032
                    runContinuation1(cont.rejected, this, cont.receiver, cont.resolver);                               // 1033
                };                                                                                                     // 1034
                                                                                                                       // 1035
                Rejected.prototype._report = function(context) {                                                       // 1036
                    tasks.afterQueue(new ReportTask(this, context));                                                   // 1037
                };                                                                                                     // 1038
                                                                                                                       // 1039
                Rejected.prototype._unreport = function() {                                                            // 1040
                    if(this.handled) {                                                                                 // 1041
                        return;                                                                                        // 1042
                    }                                                                                                  // 1043
                    this.handled = true;                                                                               // 1044
                    tasks.afterQueue(new UnreportTask(this));                                                          // 1045
                };                                                                                                     // 1046
                                                                                                                       // 1047
                Rejected.prototype.fail = function(context) {                                                          // 1048
                    this.reported = true;                                                                              // 1049
                    emitRejection('unhandledRejection', this);                                                         // 1050
                    Promise.onFatalRejection(this, context === void 0 ? this.context : context);                       // 1051
                };                                                                                                     // 1052
                                                                                                                       // 1053
                function ReportTask(rejection, context) {                                                              // 1054
                    this.rejection = rejection;                                                                        // 1055
                    this.context = context;                                                                            // 1056
                }                                                                                                      // 1057
                                                                                                                       // 1058
                ReportTask.prototype.run = function() {                                                                // 1059
                    if(!this.rejection.handled && !this.rejection.reported) {                                          // 1060
                        this.rejection.reported = true;                                                                // 1061
                        emitRejection('unhandledRejection', this.rejection) ||                                         // 1062
                        Promise.onPotentiallyUnhandledRejection(this.rejection, this.context);                         // 1063
                    }                                                                                                  // 1064
                };                                                                                                     // 1065
                                                                                                                       // 1066
                function UnreportTask(rejection) {                                                                     // 1067
                    this.rejection = rejection;                                                                        // 1068
                }                                                                                                      // 1069
                                                                                                                       // 1070
                UnreportTask.prototype.run = function() {                                                              // 1071
                    if(this.rejection.reported) {                                                                      // 1072
                        emitRejection('rejectionHandled', this.rejection) ||                                           // 1073
                        Promise.onPotentiallyUnhandledRejectionHandled(this.rejection);                                // 1074
                    }                                                                                                  // 1075
                };                                                                                                     // 1076
                                                                                                                       // 1077
                // Unhandled rejection hooks                                                                           // 1078
                // By default, everything is a noop                                                                    // 1079
                                                                                                                       // 1080
                Promise.createContext                                                                                  // 1081
                    = Promise.enterContext                                                                             // 1082
                    = Promise.exitContext                                                                              // 1083
                    = Promise.onPotentiallyUnhandledRejection                                                          // 1084
                    = Promise.onPotentiallyUnhandledRejectionHandled                                                   // 1085
                    = Promise.onFatalRejection                                                                         // 1086
                    = noop;                                                                                            // 1087
                                                                                                                       // 1088
                // Errors and singletons                                                                               // 1089
                                                                                                                       // 1090
                var foreverPendingHandler = new Handler();                                                             // 1091
                var foreverPendingPromise = new Promise(Handler, foreverPendingHandler);                               // 1092
                                                                                                                       // 1093
                function cycle() {                                                                                     // 1094
                    return new Rejected(new TypeError('Promise cycle'));                                               // 1095
                }                                                                                                      // 1096
                                                                                                                       // 1097
                // Task runners                                                                                        // 1098
                                                                                                                       // 1099
                /**                                                                                                    // 1100
                 * Run a single consumer                                                                               // 1101
                 * @constructor                                                                                        // 1102
                 */                                                                                                    // 1103
                function ContinuationTask(continuation, handler) {                                                     // 1104
                    this.continuation = continuation;                                                                  // 1105
                    this.handler = handler;                                                                            // 1106
                }                                                                                                      // 1107
                                                                                                                       // 1108
                ContinuationTask.prototype.run = function() {                                                          // 1109
                    this.handler.join().when(this.continuation);                                                       // 1110
                };                                                                                                     // 1111
                                                                                                                       // 1112
                /**                                                                                                    // 1113
                 * Run a queue of progress handlers                                                                    // 1114
                 * @constructor                                                                                        // 1115
                 */                                                                                                    // 1116
                function ProgressTask(value, handler) {                                                                // 1117
                    this.handler = handler;                                                                            // 1118
                    this.value = value;                                                                                // 1119
                }                                                                                                      // 1120
                                                                                                                       // 1121
                ProgressTask.prototype.run = function() {                                                              // 1122
                    var q = this.handler.consumers;                                                                    // 1123
                    if(q === void 0) {                                                                                 // 1124
                        return;                                                                                        // 1125
                    }                                                                                                  // 1126
                                                                                                                       // 1127
                    for (var c, i = 0; i < q.length; ++i) {                                                            // 1128
                        c = q[i];                                                                                      // 1129
                        runNotify(c.progress, this.value, this.handler, c.receiver, c.resolver);                       // 1130
                    }                                                                                                  // 1131
                };                                                                                                     // 1132
                                                                                                                       // 1133
                /**                                                                                                    // 1134
                 * Assimilate a thenable, sending it's value to resolver                                               // 1135
                 * @param {function} then                                                                              // 1136
                 * @param {object|function} thenable                                                                   // 1137
                 * @param {object} resolver                                                                            // 1138
                 * @constructor                                                                                        // 1139
                 */                                                                                                    // 1140
                function AssimilateTask(then, thenable, resolver) {                                                    // 1141
                    this._then = then;                                                                                 // 1142
                    this.thenable = thenable;                                                                          // 1143
                    this.resolver = resolver;                                                                          // 1144
                }                                                                                                      // 1145
                                                                                                                       // 1146
                AssimilateTask.prototype.run = function() {                                                            // 1147
                    var h = this.resolver;                                                                             // 1148
                    tryAssimilate(this._then, this.thenable, _resolve, _reject, _notify);                              // 1149
                                                                                                                       // 1150
                    function _resolve(x) { h.resolve(x); }                                                             // 1151
                    function _reject(x)  { h.reject(x); }                                                              // 1152
                    function _notify(x)  { h.notify(x); }                                                              // 1153
                };                                                                                                     // 1154
                                                                                                                       // 1155
                function tryAssimilate(then, thenable, resolve, reject, notify) {                                      // 1156
                    try {                                                                                              // 1157
                        then.call(thenable, resolve, reject, notify);                                                  // 1158
                    } catch (e) {                                                                                      // 1159
                        reject(e);                                                                                     // 1160
                    }                                                                                                  // 1161
                }                                                                                                      // 1162
                                                                                                                       // 1163
                /**                                                                                                    // 1164
                 * Fold a handler value with z                                                                         // 1165
                 * @constructor                                                                                        // 1166
                 */                                                                                                    // 1167
                function Fold(f, z, c, to) {                                                                           // 1168
                    this.f = f; this.z = z; this.c = c; this.to = to;                                                  // 1169
                    this.resolver = failIfRejected;                                                                    // 1170
                    this.receiver = this;                                                                              // 1171
                }                                                                                                      // 1172
                                                                                                                       // 1173
                Fold.prototype.fulfilled = function(x) {                                                               // 1174
                    this.f.call(this.c, this.z, x, this.to);                                                           // 1175
                };                                                                                                     // 1176
                                                                                                                       // 1177
                Fold.prototype.rejected = function(x) {                                                                // 1178
                    this.to.reject(x);                                                                                 // 1179
                };                                                                                                     // 1180
                                                                                                                       // 1181
                Fold.prototype.progress = function(x) {                                                                // 1182
                    this.to.notify(x);                                                                                 // 1183
                };                                                                                                     // 1184
                                                                                                                       // 1185
                // Other helpers                                                                                       // 1186
                                                                                                                       // 1187
                /**                                                                                                    // 1188
                 * @param {*} x                                                                                        // 1189
                 * @returns {boolean} true iff x is a trusted Promise                                                  // 1190
                 */                                                                                                    // 1191
                function isPromise(x) {                                                                                // 1192
                    return x instanceof Promise;                                                                       // 1193
                }                                                                                                      // 1194
                                                                                                                       // 1195
                /**                                                                                                    // 1196
                 * Test just enough to rule out primitives, in order to take faster                                    // 1197
                 * paths in some code                                                                                  // 1198
                 * @param {*} x                                                                                        // 1199
                 * @returns {boolean} false iff x is guaranteed *not* to be a thenable                                 // 1200
                 */                                                                                                    // 1201
                function maybeThenable(x) {                                                                            // 1202
                    return (typeof x === 'object' || typeof x === 'function') && x !== null;                           // 1203
                }                                                                                                      // 1204
                                                                                                                       // 1205
                function runContinuation1(f, h, receiver, next) {                                                      // 1206
                    if(typeof f !== 'function') {                                                                      // 1207
                        return next.become(h);                                                                         // 1208
                    }                                                                                                  // 1209
                                                                                                                       // 1210
                    Promise.enterContext(h);                                                                           // 1211
                    tryCatchReject(f, h.value, receiver, next);                                                        // 1212
                    Promise.exitContext();                                                                             // 1213
                }                                                                                                      // 1214
                                                                                                                       // 1215
                function runContinuation3(f, x, h, receiver, next) {                                                   // 1216
                    if(typeof f !== 'function') {                                                                      // 1217
                        return next.become(h);                                                                         // 1218
                    }                                                                                                  // 1219
                                                                                                                       // 1220
                    Promise.enterContext(h);                                                                           // 1221
                    tryCatchReject3(f, x, h.value, receiver, next);                                                    // 1222
                    Promise.exitContext();                                                                             // 1223
                }                                                                                                      // 1224
                                                                                                                       // 1225
                /**                                                                                                    // 1226
                 * @deprecated                                                                                         // 1227
                 */                                                                                                    // 1228
                function runNotify(f, x, h, receiver, next) {                                                          // 1229
                    if(typeof f !== 'function') {                                                                      // 1230
                        return next.notify(x);                                                                         // 1231
                    }                                                                                                  // 1232
                                                                                                                       // 1233
                    Promise.enterContext(h);                                                                           // 1234
                    tryCatchReturn(f, x, receiver, next);                                                              // 1235
                    Promise.exitContext();                                                                             // 1236
                }                                                                                                      // 1237
                                                                                                                       // 1238
                function tryCatch2(f, a, b) {                                                                          // 1239
                    try {                                                                                              // 1240
                        return f(a, b);                                                                                // 1241
                    } catch(e) {                                                                                       // 1242
                        return reject(e);                                                                              // 1243
                    }                                                                                                  // 1244
                }                                                                                                      // 1245
                                                                                                                       // 1246
                /**                                                                                                    // 1247
                 * Return f.call(thisArg, x), or if it throws return a rejected promise for                            // 1248
                 * the thrown exception                                                                                // 1249
                 */                                                                                                    // 1250
                function tryCatchReject(f, x, thisArg, next) {                                                         // 1251
                    try {                                                                                              // 1252
                        next.become(getHandler(f.call(thisArg, x)));                                                   // 1253
                    } catch(e) {                                                                                       // 1254
                        next.become(new Rejected(e));                                                                  // 1255
                    }                                                                                                  // 1256
                }                                                                                                      // 1257
                                                                                                                       // 1258
                /**                                                                                                    // 1259
                 * Same as above, but includes the extra argument parameter.                                           // 1260
                 */                                                                                                    // 1261
                function tryCatchReject3(f, x, y, thisArg, next) {                                                     // 1262
                    try {                                                                                              // 1263
                        f.call(thisArg, x, y, next);                                                                   // 1264
                    } catch(e) {                                                                                       // 1265
                        next.become(new Rejected(e));                                                                  // 1266
                    }                                                                                                  // 1267
                }                                                                                                      // 1268
                                                                                                                       // 1269
                /**                                                                                                    // 1270
                 * @deprecated                                                                                         // 1271
                 * Return f.call(thisArg, x), or if it throws, *return* the exception                                  // 1272
                 */                                                                                                    // 1273
                function tryCatchReturn(f, x, thisArg, next) {                                                         // 1274
                    try {                                                                                              // 1275
                        next.notify(f.call(thisArg, x));                                                               // 1276
                    } catch(e) {                                                                                       // 1277
                        next.notify(e);                                                                                // 1278
                    }                                                                                                  // 1279
                }                                                                                                      // 1280
                                                                                                                       // 1281
                function inherit(Parent, Child) {                                                                      // 1282
                    Child.prototype = objectCreate(Parent.prototype);                                                  // 1283
                    Child.prototype.constructor = Child;                                                               // 1284
                }                                                                                                      // 1285
                                                                                                                       // 1286
                function snd(x, y) {                                                                                   // 1287
                    return y;                                                                                          // 1288
                }                                                                                                      // 1289
                                                                                                                       // 1290
                function noop() {}                                                                                     // 1291
                                                                                                                       // 1292
                function initEmitRejection() {                                                                         // 1293
                    /*global process, self, CustomEvent*/                                                              // 1294
                    if(typeof process !== 'undefined' && process !== null                                              // 1295
                        && typeof process.emit === 'function') {                                                       // 1296
                        // Returning falsy here means to call the default                                              // 1297
                        // onPotentiallyUnhandledRejection API.  This is safe even in                                  // 1298
                        // browserify since process.emit always returns falsy in browserify:                           // 1299
                        // https://github.com/defunctzombie/node-process/blob/master/browser.js#L40-L46                // 1300
                        return function(type, rejection) {                                                             // 1301
                            return type === 'unhandledRejection'                                                       // 1302
                                ? process.emit(type, rejection.value, rejection)                                       // 1303
                                : process.emit(type, rejection);                                                       // 1304
                        };                                                                                             // 1305
                    } else if(typeof self !== 'undefined' && typeof CustomEvent === 'function') {                      // 1306
                        return (function(noop, self, CustomEvent) {                                                    // 1307
                            var hasCustomEvent = false;                                                                // 1308
                            try {                                                                                      // 1309
                                var ev = new CustomEvent('unhandledRejection');                                        // 1310
                                hasCustomEvent = ev instanceof CustomEvent;                                            // 1311
                            } catch (e) {}                                                                             // 1312
                                                                                                                       // 1313
                            return !hasCustomEvent ? noop : function(type, rejection) {                                // 1314
                                var ev = new CustomEvent(type, {                                                       // 1315
                                    detail: {                                                                          // 1316
                                        reason: rejection.value,                                                       // 1317
                                        key: rejection                                                                 // 1318
                                    },                                                                                 // 1319
                                    bubbles: false,                                                                    // 1320
                                    cancelable: true                                                                   // 1321
                                });                                                                                    // 1322
                                                                                                                       // 1323
                                return !self.dispatchEvent(ev);                                                        // 1324
                            };                                                                                         // 1325
                        }(noop, self, CustomEvent));                                                                   // 1326
                    }                                                                                                  // 1327
                                                                                                                       // 1328
                    return noop;                                                                                       // 1329
                }                                                                                                      // 1330
                                                                                                                       // 1331
                return Promise;                                                                                        // 1332
            };                                                                                                         // 1333
        });                                                                                                            // 1334
    }(typeof define === 'function' && define.amd ? define : function(factory) { module.exports = factory(); }));       // 1335
                                                                                                                       // 1336
},{}]},{},[1])                                                                                                         // 1337
(1)                                                                                                                    // 1338
});                                                                                                                    // 1339
;if (typeof systemJSBootstrap !== 'undefined')                                                                         // 1340
    systemJSBootstrap();                                                                                               // 1341
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe:modules/vendor/system.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/*                                                                                                                     // 1
 * SystemJS v0.18.1                                                                                                    // 2
 */                                                                                                                    // 3
(function() {                                                                                                          // 4
    function bootstrap() {(function(__global) {                                                                        // 5
                                                                                                                       // 6
        var isWorker = typeof window == 'undefined' && typeof self != 'undefined' && typeof importScripts != 'undefined';
        var isBrowser = typeof window != 'undefined' && typeof document != 'undefined';                                // 8
        var isWindows = typeof process != 'undefined' && !!process.platform.match(/^win/);                             // 9
                                                                                                                       // 10
        if (!__global.console)                                                                                         // 11
            __global.console = { assert: function() {} };                                                              // 12
                                                                                                                       // 13
        // IE8 support                                                                                                 // 14
        var indexOf = Array.prototype.indexOf || function(item) {                                                      // 15
                for (var i = 0, thisLen = this.length; i < thisLen; i++) {                                             // 16
                    if (this[i] === item) {                                                                            // 17
                        return i;                                                                                      // 18
                    }                                                                                                  // 19
                }                                                                                                      // 20
                return -1;                                                                                             // 21
            };                                                                                                         // 22
                                                                                                                       // 23
        var defineProperty;                                                                                            // 24
        (function () {                                                                                                 // 25
            try {                                                                                                      // 26
                if (!!Object.defineProperty({}, 'a', {}))                                                              // 27
                    defineProperty = Object.defineProperty;                                                            // 28
            }                                                                                                          // 29
            catch (e) {                                                                                                // 30
                defineProperty = function(obj, prop, opt) {                                                            // 31
                    try {                                                                                              // 32
                        obj[prop] = opt.value || opt.get.call(obj);                                                    // 33
                    }                                                                                                  // 34
                    catch(e) {}                                                                                        // 35
                }                                                                                                      // 36
            }                                                                                                          // 37
        })();                                                                                                          // 38
                                                                                                                       // 39
        function addToError(err, msg) {                                                                                // 40
            var newErr;                                                                                                // 41
            if (err instanceof Error) {                                                                                // 42
                var newErr = new Error(err.message, err.fileName, err.lineNumber);                                     // 43
                newErr.message = err.message + '\n\t' + msg;                                                           // 44
                newErr.stack = err.stack;                                                                              // 45
            }                                                                                                          // 46
            else {                                                                                                     // 47
                newErr = err + '\n\t' + msg;                                                                           // 48
            }                                                                                                          // 49
                                                                                                                       // 50
            return newErr;                                                                                             // 51
        }                                                                                                              // 52
                                                                                                                       // 53
        function __eval(source, debugName, context) {                                                                  // 54
            try {                                                                                                      // 55
                new Function(source).call(context);                                                                    // 56
            }                                                                                                          // 57
            catch(e) {                                                                                                 // 58
                throw addToError(e, 'Evaluating ' + debugName);                                                        // 59
            }                                                                                                          // 60
        }                                                                                                              // 61
                                                                                                                       // 62
        var baseURI;                                                                                                   // 63
        // environent baseURI detection                                                                                // 64
        if (typeof document != 'undefined' && document.getElementsByTagName) {                                         // 65
            baseURI = document.baseURI;                                                                                // 66
                                                                                                                       // 67
            if (!baseURI) {                                                                                            // 68
                var bases = document.getElementsByTagName('base');                                                     // 69
                baseURI = bases[0] && bases[0].href || window.location.href;                                           // 70
            }                                                                                                          // 71
                                                                                                                       // 72
            // sanitize out the hash and querystring                                                                   // 73
            baseURI = baseURI.split('#')[0].split('?')[0];                                                             // 74
            baseURI = baseURI.substr(0, baseURI.lastIndexOf('/') + 1);                                                 // 75
        }                                                                                                              // 76
        else if (typeof process != 'undefined' && process.cwd) {                                                       // 77
            baseURI = 'file://' + (isWindows ? '/' : '') + process.cwd() + '/';                                        // 78
            if (isWindows)                                                                                             // 79
                baseURI = baseURI.replace(/\\/g, '/');                                                                 // 80
        }                                                                                                              // 81
        else if (typeof location != 'undefined') {                                                                     // 82
            baseURI = __global.location.href;                                                                          // 83
        }                                                                                                              // 84
        else {                                                                                                         // 85
            throw new TypeError('No environment baseURI');                                                             // 86
        }                                                                                                              // 87
                                                                                                                       // 88
        var URL = __global.URL;                                                                                        // 89
        try {                                                                                                          // 90
            new URL('test:///').protocol == 'test:';                                                                   // 91
        }                                                                                                              // 92
        catch(e) {                                                                                                     // 93
            URL = URLPolyfill;                                                                                         // 94
        }                                                                                                              // 95
        /*                                                                                                             // 96
         *********************************************************************************************                 // 97
                                                                                                                       // 98
         Dynamic Module Loader Polyfill                                                                                // 99
                                                                                                                       // 100
         - Implemented exactly to the former 2014-08-24 ES6 Specification Draft Rev 27, Section 15                     // 101
         http://wiki.ecmascript.org/doku.php?id=harmony:specification_drafts#august_24_2014_draft_rev_27               // 102
                                                                                                                       // 103
         - Functions are commented with their spec numbers, with spec differences commented.                           // 104
                                                                                                                       // 105
         - Spec bugs are commented in this code with links.                                                            // 106
                                                                                                                       // 107
         - Abstract functions have been combined where possible, and their associated functions                        // 108
         commented.                                                                                                    // 109
                                                                                                                       // 110
         - Realm implementation is entirely omitted.                                                                   // 111
                                                                                                                       // 112
         *********************************************************************************************                 // 113
         */                                                                                                            // 114
                                                                                                                       // 115
        function Module() {}                                                                                           // 116
        function Loader(options) {                                                                                     // 117
            this._loader = {                                                                                           // 118
                loaderObj: this,                                                                                       // 119
                loads: [],                                                                                             // 120
                modules: {},                                                                                           // 121
                importPromises: {},                                                                                    // 122
                moduleRecords: {}                                                                                      // 123
            };                                                                                                         // 124
                                                                                                                       // 125
            // 26.3.3.6                                                                                                // 126
            defineProperty(this, 'global', {                                                                           // 127
                get: function() {                                                                                      // 128
                    return __global;                                                                                   // 129
                }                                                                                                      // 130
            });                                                                                                        // 131
                                                                                                                       // 132
            // 26.3.3.13 realm not implemented                                                                         // 133
        }                                                                                                              // 134
                                                                                                                       // 135
        (function() {                                                                                                  // 136
                                                                                                                       // 137
// Some Helpers                                                                                                        // 138
                                                                                                                       // 139
// logs a linkset snapshot for debugging                                                                               // 140
            /* function snapshot(loader) {                                                                             // 141
             console.log('---Snapshot---');                                                                            // 142
             for (var i = 0; i < loader.loads.length; i++) {                                                           // 143
             var load = loader.loads[i];                                                                               // 144
             var linkSetLog = '  ' + load.name + ' (' + load.status + '): ';                                           // 145
                                                                                                                       // 146
             for (var j = 0; j < load.linkSets.length; j++) {                                                          // 147
             linkSetLog += '{' + logloads(load.linkSets[j].loads) + '} ';                                              // 148
             }                                                                                                         // 149
             console.log(linkSetLog);                                                                                  // 150
             }                                                                                                         // 151
             console.log('');                                                                                          // 152
             }                                                                                                         // 153
             function logloads(loads) {                                                                                // 154
             var log = '';                                                                                             // 155
             for (var k = 0; k < loads.length; k++)                                                                    // 156
             log += loads[k].name + (k != loads.length - 1 ? ' ' : '');                                                // 157
             return log;                                                                                               // 158
             } */                                                                                                      // 159
                                                                                                                       // 160
                                                                                                                       // 161
            /* function checkInvariants() {                                                                            // 162
             // see https://bugs.ecmascript.org/show_bug.cgi?id=2603#c1                                                // 163
                                                                                                                       // 164
             var loads = System._loader.loads;                                                                         // 165
             var linkSets = [];                                                                                        // 166
                                                                                                                       // 167
             for (var i = 0; i < loads.length; i++) {                                                                  // 168
             var load = loads[i];                                                                                      // 169
             console.assert(load.status == 'loading' || load.status == 'loaded', 'Each load is loading or loaded');    // 170
                                                                                                                       // 171
             for (var j = 0; j < load.linkSets.length; j++) {                                                          // 172
             var linkSet = load.linkSets[j];                                                                           // 173
                                                                                                                       // 174
             for (var k = 0; k < linkSet.loads.length; k++)                                                            // 175
             console.assert(loads.indexOf(linkSet.loads[k]) != -1, 'linkSet loads are a subset of loader loads');      // 176
                                                                                                                       // 177
             if (linkSets.indexOf(linkSet) == -1)                                                                      // 178
             linkSets.push(linkSet);                                                                                   // 179
             }                                                                                                         // 180
             }                                                                                                         // 181
                                                                                                                       // 182
             for (var i = 0; i < loads.length; i++) {                                                                  // 183
             var load = loads[i];                                                                                      // 184
             for (var j = 0; j < linkSets.length; j++) {                                                               // 185
             var linkSet = linkSets[j];                                                                                // 186
                                                                                                                       // 187
             if (linkSet.loads.indexOf(load) != -1)                                                                    // 188
             console.assert(load.linkSets.indexOf(linkSet) != -1, 'linkSet contains load -> load contains linkSet');   // 189
                                                                                                                       // 190
             if (load.linkSets.indexOf(linkSet) != -1)                                                                 // 191
             console.assert(linkSet.loads.indexOf(load) != -1, 'load contains linkSet -> linkSet contains load');      // 192
             }                                                                                                         // 193
             }                                                                                                         // 194
                                                                                                                       // 195
             for (var i = 0; i < linkSets.length; i++) {                                                               // 196
             var linkSet = linkSets[i];                                                                                // 197
             for (var j = 0; j < linkSet.loads.length; j++) {                                                          // 198
             var load = linkSet.loads[j];                                                                              // 199
                                                                                                                       // 200
             for (var k = 0; k < load.dependencies.length; k++) {                                                      // 201
             var depName = load.dependencies[k].value;                                                                 // 202
             var depLoad;                                                                                              // 203
             for (var l = 0; l < loads.length; l++) {                                                                  // 204
             if (loads[l].name != depName)                                                                             // 205
             continue;                                                                                                 // 206
             depLoad = loads[l];                                                                                       // 207
             break;                                                                                                    // 208
             }                                                                                                         // 209
                                                                                                                       // 210
             // loading records are allowed not to have their dependencies yet                                         // 211
             // if (load.status != 'loading')                                                                          // 212
             //  console.assert(depLoad, 'depLoad found');                                                             // 213
                                                                                                                       // 214
             // console.assert(linkSet.loads.indexOf(depLoad) != -1, 'linkset contains all dependencies');             // 215
             }                                                                                                         // 216
             }                                                                                                         // 217
             }                                                                                                         // 218
             } */                                                                                                      // 219
                                                                                                                       // 220
            // 15.2.3 - Runtime Semantics: Loader State                                                                // 221
                                                                                                                       // 222
            // 15.2.3.11                                                                                               // 223
            function createLoaderLoad(object) {                                                                        // 224
                return {                                                                                               // 225
                    // modules is an object for ES5 implementation                                                     // 226
                    modules: {},                                                                                       // 227
                    loads: [],                                                                                         // 228
                    loaderObj: object                                                                                  // 229
                };                                                                                                     // 230
            }                                                                                                          // 231
                                                                                                                       // 232
            // 15.2.3.2 Load Records and LoadRequest Objects                                                           // 233
                                                                                                                       // 234
            // 15.2.3.2.1                                                                                              // 235
            function createLoad(name) {                                                                                // 236
                return {                                                                                               // 237
                    status: 'loading',                                                                                 // 238
                    name: name,                                                                                        // 239
                    linkSets: [],                                                                                      // 240
                    dependencies: [],                                                                                  // 241
                    metadata: {}                                                                                       // 242
                };                                                                                                     // 243
            }                                                                                                          // 244
                                                                                                                       // 245
            // 15.2.3.2.2 createLoadRequestObject, absorbed into calling functions                                     // 246
                                                                                                                       // 247
            // 15.2.4                                                                                                  // 248
                                                                                                                       // 249
            // 15.2.4.1                                                                                                // 250
            function loadModule(loader, name, options) {                                                               // 251
                return new Promise(asyncStartLoadPartwayThrough({                                                      // 252
                    step: options.address ? 'fetch' : 'locate',                                                        // 253
                    loader: loader,                                                                                    // 254
                    moduleName: name,                                                                                  // 255
                    // allow metadata for import https://bugs.ecmascript.org/show_bug.cgi?id=3091                      // 256
                    moduleMetadata: options && options.metadata || {},                                                 // 257
                    moduleSource: options.source,                                                                      // 258
                    moduleAddress: options.address                                                                     // 259
                }));                                                                                                   // 260
            }                                                                                                          // 261
                                                                                                                       // 262
            // 15.2.4.2                                                                                                // 263
            function requestLoad(loader, request, refererName, refererAddress) {                                       // 264
                // 15.2.4.2.1 CallNormalize                                                                            // 265
                return new Promise(function(resolve, reject) {                                                         // 266
                    resolve(loader.loaderObj.normalize(request, refererName, refererAddress));                         // 267
                })                                                                                                     // 268
                    // 15.2.4.2.2 GetOrCreateLoad                                                                      // 269
                    .then(function(name) {                                                                             // 270
                        var load;                                                                                      // 271
                        if (loader.modules[name]) {                                                                    // 272
                            load = createLoad(name);                                                                   // 273
                            load.status = 'linked';                                                                    // 274
                            // https://bugs.ecmascript.org/show_bug.cgi?id=2795                                        // 275
                            load.module = loader.modules[name];                                                        // 276
                            return load;                                                                               // 277
                        }                                                                                              // 278
                                                                                                                       // 279
                        for (var i = 0, l = loader.loads.length; i < l; i++) {                                         // 280
                            load = loader.loads[i];                                                                    // 281
                            if (load.name != name)                                                                     // 282
                                continue;                                                                              // 283
                            console.assert(load.status == 'loading' || load.status == 'loaded', 'loading or loaded');  // 284
                            return load;                                                                               // 285
                        }                                                                                              // 286
                                                                                                                       // 287
                        load = createLoad(name);                                                                       // 288
                        loader.loads.push(load);                                                                       // 289
                                                                                                                       // 290
                        proceedToLocate(loader, load);                                                                 // 291
                                                                                                                       // 292
                        return load;                                                                                   // 293
                    });                                                                                                // 294
            }                                                                                                          // 295
                                                                                                                       // 296
            // 15.2.4.3                                                                                                // 297
            function proceedToLocate(loader, load) {                                                                   // 298
                proceedToFetch(loader, load,                                                                           // 299
                    Promise.resolve()                                                                                  // 300
                        // 15.2.4.3.1 CallLocate                                                                       // 301
                        .then(function() {                                                                             // 302
                            return loader.loaderObj.locate({ name: load.name, metadata: load.metadata });              // 303
                        })                                                                                             // 304
                );                                                                                                     // 305
            }                                                                                                          // 306
                                                                                                                       // 307
            // 15.2.4.4                                                                                                // 308
            function proceedToFetch(loader, load, p) {                                                                 // 309
                proceedToTranslate(loader, load,                                                                       // 310
                    p                                                                                                  // 311
                        // 15.2.4.4.1 CallFetch                                                                        // 312
                        .then(function(address) {                                                                      // 313
                            // adjusted, see https://bugs.ecmascript.org/show_bug.cgi?id=2602                          // 314
                            if (load.status != 'loading')                                                              // 315
                                return;                                                                                // 316
                            load.address = address;                                                                    // 317
                                                                                                                       // 318
                            return loader.loaderObj.fetch({ name: load.name, metadata: load.metadata, address: address });
                        })                                                                                             // 320
                );                                                                                                     // 321
            }                                                                                                          // 322
                                                                                                                       // 323
            var anonCnt = 0;                                                                                           // 324
                                                                                                                       // 325
            // 15.2.4.5                                                                                                // 326
            function proceedToTranslate(loader, load, p) {                                                             // 327
                p                                                                                                      // 328
                    // 15.2.4.5.1 CallTranslate                                                                        // 329
                    .then(function(source) {                                                                           // 330
                        if (load.status != 'loading')                                                                  // 331
                            return;                                                                                    // 332
                                                                                                                       // 333
                        return Promise.resolve(loader.loaderObj.translate({ name: load.name, metadata: load.metadata, address: load.address, source: source }))
                                                                                                                       // 335
                            // 15.2.4.5.2 CallInstantiate                                                              // 336
                            .then(function(source) {                                                                   // 337
                                load.source = source;                                                                  // 338
                                return loader.loaderObj.instantiate({ name: load.name, metadata: load.metadata, address: load.address, source: source });
                            })                                                                                         // 340
                                                                                                                       // 341
                            // 15.2.4.5.3 InstantiateSucceeded                                                         // 342
                            .then(function(instantiateResult) {                                                        // 343
                                if (instantiateResult === undefined) {                                                 // 344
                                    load.address = load.address || '<Anonymous Module ' + ++anonCnt + '>';             // 345
                                                                                                                       // 346
                                    // instead of load.kind, use load.isDeclarative                                    // 347
                                    load.isDeclarative = true;                                                         // 348
                                    return transpile.call(loader.loaderObj, load)                                      // 349
                                        .then(function(transpiled) {                                                   // 350
                                            // Hijack System.register to set declare function                          // 351
                                            var curSystem = __global.System;                                           // 352
                                            var curRegister = curSystem.register;                                      // 353
                                            curSystem.register = function(name, deps, declare) {                       // 354
                                                if (typeof name != 'string') {                                         // 355
                                                    declare = deps;                                                    // 356
                                                    deps = name;                                                       // 357
                                                }                                                                      // 358
                                                // store the registered declaration as load.declare                    // 359
                                                // store the deps as load.deps                                         // 360
                                                load.declare = declare;                                                // 361
                                                load.depsList = deps;                                                  // 362
                                            }                                                                          // 363
                                            // empty {} context is closest to undefined 'this' we can get              // 364
                                            __eval(transpiled, load.address, {});                                      // 365
                                            curSystem.register = curRegister;                                          // 366
                                        });                                                                            // 367
                                }                                                                                      // 368
                                else if (typeof instantiateResult == 'object') {                                       // 369
                                    load.depsList = instantiateResult.deps || [];                                      // 370
                                    load.execute = instantiateResult.execute;                                          // 371
                                    load.isDeclarative = false;                                                        // 372
                                }                                                                                      // 373
                                else                                                                                   // 374
                                    throw TypeError('Invalid instantiate return value');                               // 375
                            })                                                                                         // 376
                            // 15.2.4.6 ProcessLoadDependencies                                                        // 377
                            .then(function() {                                                                         // 378
                                load.dependencies = [];                                                                // 379
                                var depsList = load.depsList;                                                          // 380
                                                                                                                       // 381
                                var loadPromises = [];                                                                 // 382
                                for (var i = 0, l = depsList.length; i < l; i++) (function(request, index) {           // 383
                                    loadPromises.push(                                                                 // 384
                                        requestLoad(loader, request, load.name, load.address)                          // 385
                                                                                                                       // 386
                                            // 15.2.4.6.1 AddDependencyLoad (load is parentLoad)                       // 387
                                            .then(function(depLoad) {                                                  // 388
                                                                                                                       // 389
                                                // adjusted from spec to maintain dependency order                     // 390
                                                // this is due to the System.register internal implementation needs    // 391
                                                load.dependencies[index] = {                                           // 392
                                                    key: request,                                                      // 393
                                                    value: depLoad.name                                                // 394
                                                };                                                                     // 395
                                                                                                                       // 396
                                                if (depLoad.status != 'linked') {                                      // 397
                                                    var linkSets = load.linkSets.concat([]);                           // 398
                                                    for (var i = 0, l = linkSets.length; i < l; i++)                   // 399
                                                        addLoadToLinkSet(linkSets[i], depLoad);                        // 400
                                                }                                                                      // 401
                                                                                                                       // 402
                                                // console.log('AddDependencyLoad ' + depLoad.name + ' for ' + load.name);
                                                // snapshot(loader);                                                   // 404
                                            })                                                                         // 405
                                    );                                                                                 // 406
                                })(depsList[i], i);                                                                    // 407
                                                                                                                       // 408
                                return Promise.all(loadPromises);                                                      // 409
                            })                                                                                         // 410
                                                                                                                       // 411
                            // 15.2.4.6.2 LoadSucceeded                                                                // 412
                            .then(function() {                                                                         // 413
                                // console.log('LoadSucceeded ' + load.name);                                          // 414
                                // snapshot(loader);                                                                   // 415
                                                                                                                       // 416
                                console.assert(load.status == 'loading', 'is loading');                                // 417
                                                                                                                       // 418
                                load.status = 'loaded';                                                                // 419
                                                                                                                       // 420
                                var linkSets = load.linkSets.concat([]);                                               // 421
                                for (var i = 0, l = linkSets.length; i < l; i++)                                       // 422
                                    updateLinkSetOnLoad(linkSets[i], load);                                            // 423
                            });                                                                                        // 424
                    })                                                                                                 // 425
                    // 15.2.4.5.4 LoadFailed                                                                           // 426
                    ['catch'](function(exc) {                                                                          // 427
                    load.status = 'failed';                                                                            // 428
                    load.exception = exc;                                                                              // 429
                                                                                                                       // 430
                    var linkSets = load.linkSets.concat([]);                                                           // 431
                    for (var i = 0, l = linkSets.length; i < l; i++) {                                                 // 432
                        linkSetFailed(linkSets[i], load, exc);                                                         // 433
                    }                                                                                                  // 434
                                                                                                                       // 435
                    console.assert(load.linkSets.length == 0, 'linkSets not removed');                                 // 436
                });                                                                                                    // 437
            }                                                                                                          // 438
                                                                                                                       // 439
            // 15.2.4.7 PromiseOfStartLoadPartwayThrough absorbed into calling functions                               // 440
                                                                                                                       // 441
            // 15.2.4.7.1                                                                                              // 442
            function asyncStartLoadPartwayThrough(stepState) {                                                         // 443
                return function(resolve, reject) {                                                                     // 444
                    var loader = stepState.loader;                                                                     // 445
                    var name = stepState.moduleName;                                                                   // 446
                    var step = stepState.step;                                                                         // 447
                                                                                                                       // 448
                    if (loader.modules[name])                                                                          // 449
                        throw new TypeError('"' + name + '" already exists in the module table');                      // 450
                                                                                                                       // 451
                    // adjusted to pick up existing loads                                                              // 452
                    var existingLoad;                                                                                  // 453
                    for (var i = 0, l = loader.loads.length; i < l; i++) {                                             // 454
                        if (loader.loads[i].name == name) {                                                            // 455
                            existingLoad = loader.loads[i];                                                            // 456
                                                                                                                       // 457
                            if(step == 'translate' && !existingLoad.source) {                                          // 458
                                existingLoad.address = stepState.moduleAddress;                                        // 459
                                proceedToTranslate(loader, existingLoad, Promise.resolve(stepState.moduleSource));     // 460
                            }                                                                                          // 461
                                                                                                                       // 462
                            return existingLoad.linkSets[0].done.then(function() {                                     // 463
                                resolve(existingLoad);                                                                 // 464
                            });                                                                                        // 465
                        }                                                                                              // 466
                    }                                                                                                  // 467
                                                                                                                       // 468
                    var load = createLoad(name);                                                                       // 469
                                                                                                                       // 470
                    load.metadata = stepState.moduleMetadata;                                                          // 471
                                                                                                                       // 472
                    var linkSet = createLinkSet(loader, load);                                                         // 473
                                                                                                                       // 474
                    loader.loads.push(load);                                                                           // 475
                                                                                                                       // 476
                    resolve(linkSet.done);                                                                             // 477
                                                                                                                       // 478
                    if (step == 'locate')                                                                              // 479
                        proceedToLocate(loader, load);                                                                 // 480
                                                                                                                       // 481
                    else if (step == 'fetch')                                                                          // 482
                        proceedToFetch(loader, load, Promise.resolve(stepState.moduleAddress));                        // 483
                                                                                                                       // 484
                    else {                                                                                             // 485
                        console.assert(step == 'translate', 'translate step');                                         // 486
                        load.address = stepState.moduleAddress;                                                        // 487
                        proceedToTranslate(loader, load, Promise.resolve(stepState.moduleSource));                     // 488
                    }                                                                                                  // 489
                }                                                                                                      // 490
            }                                                                                                          // 491
                                                                                                                       // 492
            // Declarative linking functions run through alternative implementation:                                   // 493
            // 15.2.5.1.1 CreateModuleLinkageRecord not implemented                                                    // 494
            // 15.2.5.1.2 LookupExport not implemented                                                                 // 495
            // 15.2.5.1.3 LookupModuleDependency not implemented                                                       // 496
                                                                                                                       // 497
            // 15.2.5.2.1                                                                                              // 498
            function createLinkSet(loader, startingLoad) {                                                             // 499
                var linkSet = {                                                                                        // 500
                    loader: loader,                                                                                    // 501
                    loads: [],                                                                                         // 502
                    startingLoad: startingLoad, // added see spec bug https://bugs.ecmascript.org/show_bug.cgi?id=2995 // 503
                    loadingCount: 0                                                                                    // 504
                };                                                                                                     // 505
                linkSet.done = new Promise(function(resolve, reject) {                                                 // 506
                    linkSet.resolve = resolve;                                                                         // 507
                    linkSet.reject = reject;                                                                           // 508
                });                                                                                                    // 509
                addLoadToLinkSet(linkSet, startingLoad);                                                               // 510
                return linkSet;                                                                                        // 511
            }                                                                                                          // 512
            // 15.2.5.2.2                                                                                              // 513
            function addLoadToLinkSet(linkSet, load) {                                                                 // 514
                console.assert(load.status == 'loading' || load.status == 'loaded', 'loading or loaded on link set');  // 515
                                                                                                                       // 516
                for (var i = 0, l = linkSet.loads.length; i < l; i++)                                                  // 517
                    if (linkSet.loads[i] == load)                                                                      // 518
                        return;                                                                                        // 519
                                                                                                                       // 520
                linkSet.loads.push(load);                                                                              // 521
                load.linkSets.push(linkSet);                                                                           // 522
                                                                                                                       // 523
                // adjustment, see https://bugs.ecmascript.org/show_bug.cgi?id=2603                                    // 524
                if (load.status != 'loaded') {                                                                         // 525
                    linkSet.loadingCount++;                                                                            // 526
                }                                                                                                      // 527
                                                                                                                       // 528
                var loader = linkSet.loader;                                                                           // 529
                                                                                                                       // 530
                for (var i = 0, l = load.dependencies.length; i < l; i++) {                                            // 531
                    var name = load.dependencies[i].value;                                                             // 532
                                                                                                                       // 533
                    if (loader.modules[name])                                                                          // 534
                        continue;                                                                                      // 535
                                                                                                                       // 536
                    for (var j = 0, d = loader.loads.length; j < d; j++) {                                             // 537
                        if (loader.loads[j].name != name)                                                              // 538
                            continue;                                                                                  // 539
                                                                                                                       // 540
                        addLoadToLinkSet(linkSet, loader.loads[j]);                                                    // 541
                        break;                                                                                         // 542
                    }                                                                                                  // 543
                }                                                                                                      // 544
                // console.log('add to linkset ' + load.name);                                                         // 545
                // snapshot(linkSet.loader);                                                                           // 546
            }                                                                                                          // 547
                                                                                                                       // 548
            // linking errors can be generic or load-specific                                                          // 549
            // this is necessary for debugging info                                                                    // 550
            function doLink(linkSet) {                                                                                 // 551
                var error = false;                                                                                     // 552
                try {                                                                                                  // 553
                    link(linkSet, function(load, exc) {                                                                // 554
                        linkSetFailed(linkSet, load, exc);                                                             // 555
                        error = true;                                                                                  // 556
                    });                                                                                                // 557
                }                                                                                                      // 558
                catch(e) {                                                                                             // 559
                    linkSetFailed(linkSet, null, e);                                                                   // 560
                    error = true;                                                                                      // 561
                }                                                                                                      // 562
                return error;                                                                                          // 563
            }                                                                                                          // 564
                                                                                                                       // 565
            // 15.2.5.2.3                                                                                              // 566
            function updateLinkSetOnLoad(linkSet, load) {                                                              // 567
                // console.log('update linkset on load ' + load.name);                                                 // 568
                // snapshot(linkSet.loader);                                                                           // 569
                                                                                                                       // 570
                console.assert(load.status == 'loaded' || load.status == 'linked', 'loaded or linked');                // 571
                                                                                                                       // 572
                linkSet.loadingCount--;                                                                                // 573
                                                                                                                       // 574
                if (linkSet.loadingCount > 0)                                                                          // 575
                    return;                                                                                            // 576
                                                                                                                       // 577
                // adjusted for spec bug https://bugs.ecmascript.org/show_bug.cgi?id=2995                              // 578
                var startingLoad = linkSet.startingLoad;                                                               // 579
                                                                                                                       // 580
                // non-executing link variation for loader tracing                                                     // 581
                // on the server. Not in spec.                                                                         // 582
                /***/                                                                                                  // 583
                if (linkSet.loader.loaderObj.execute === false) {                                                      // 584
                    var loads = [].concat(linkSet.loads);                                                              // 585
                    for (var i = 0, l = loads.length; i < l; i++) {                                                    // 586
                        var load = loads[i];                                                                           // 587
                        load.module = !load.isDeclarative ? {                                                          // 588
                            module: _newModule({})                                                                     // 589
                        } : {                                                                                          // 590
                            name: load.name,                                                                           // 591
                            module: _newModule({}),                                                                    // 592
                            evaluated: true                                                                            // 593
                        };                                                                                             // 594
                        load.status = 'linked';                                                                        // 595
                        finishLoad(linkSet.loader, load);                                                              // 596
                    }                                                                                                  // 597
                    return linkSet.resolve(startingLoad);                                                              // 598
                }                                                                                                      // 599
                /***/                                                                                                  // 600
                                                                                                                       // 601
                var abrupt = doLink(linkSet);                                                                          // 602
                                                                                                                       // 603
                if (abrupt)                                                                                            // 604
                    return;                                                                                            // 605
                                                                                                                       // 606
                console.assert(linkSet.loads.length == 0, 'loads cleared');                                            // 607
                                                                                                                       // 608
                linkSet.resolve(startingLoad);                                                                         // 609
            }                                                                                                          // 610
                                                                                                                       // 611
            // 15.2.5.2.4                                                                                              // 612
            function linkSetFailed(linkSet, load, exc) {                                                               // 613
                var loader = linkSet.loader;                                                                           // 614
                                                                                                                       // 615
                if (load) {                                                                                            // 616
                    if (load && linkSet.loads[0].name != load.name)                                                    // 617
                        exc = addToError(exc, 'Error loading ' + load.name + ' from ' + linkSet.loads[0].name);        // 618
                                                                                                                       // 619
                    if (load)                                                                                          // 620
                        exc = addToError(exc, 'Error loading ' + load.name);                                           // 621
                }                                                                                                      // 622
                else {                                                                                                 // 623
                    exc = addToError(exc, 'Error linking ' + linkSet.loads[0].name);                                   // 624
                }                                                                                                      // 625
                                                                                                                       // 626
                                                                                                                       // 627
                var loads = linkSet.loads.concat([]);                                                                  // 628
                for (var i = 0, l = loads.length; i < l; i++) {                                                        // 629
                    var load = loads[i];                                                                               // 630
                                                                                                                       // 631
                    // store all failed load records                                                                   // 632
                    loader.loaderObj.failed = loader.loaderObj.failed || [];                                           // 633
                    if (indexOf.call(loader.loaderObj.failed, load) == -1)                                             // 634
                        loader.loaderObj.failed.push(load);                                                            // 635
                                                                                                                       // 636
                    var linkIndex = indexOf.call(load.linkSets, linkSet);                                              // 637
                    console.assert(linkIndex != -1, 'link not present');                                               // 638
                    load.linkSets.splice(linkIndex, 1);                                                                // 639
                    if (load.linkSets.length == 0) {                                                                   // 640
                        var globalLoadsIndex = indexOf.call(linkSet.loader.loads, load);                               // 641
                        if (globalLoadsIndex != -1)                                                                    // 642
                            linkSet.loader.loads.splice(globalLoadsIndex, 1);                                          // 643
                    }                                                                                                  // 644
                }                                                                                                      // 645
                linkSet.reject(exc);                                                                                   // 646
            }                                                                                                          // 647
                                                                                                                       // 648
            // 15.2.5.2.5                                                                                              // 649
            function finishLoad(loader, load) {                                                                        // 650
                // add to global trace if tracing                                                                      // 651
                if (loader.loaderObj.trace) {                                                                          // 652
                    if (!loader.loaderObj.loads)                                                                       // 653
                        loader.loaderObj.loads = {};                                                                   // 654
                    var depMap = {};                                                                                   // 655
                    load.dependencies.forEach(function(dep) {                                                          // 656
                        depMap[dep.key] = dep.value;                                                                   // 657
                    });                                                                                                // 658
                    loader.loaderObj.loads[load.name] = {                                                              // 659
                        name: load.name,                                                                               // 660
                        deps: load.dependencies.map(function(dep){ return dep.key }),                                  // 661
                        depMap: depMap,                                                                                // 662
                        address: load.address,                                                                         // 663
                        metadata: load.metadata,                                                                       // 664
                        source: load.source,                                                                           // 665
                        kind: load.isDeclarative ? 'declarative' : 'dynamic'                                           // 666
                    };                                                                                                 // 667
                }                                                                                                      // 668
                // if not anonymous, add to the module table                                                           // 669
                if (load.name) {                                                                                       // 670
                    console.assert(!loader.modules[load.name], 'load not in module table');                            // 671
                    loader.modules[load.name] = load.module;                                                           // 672
                }                                                                                                      // 673
                var loadIndex = indexOf.call(loader.loads, load);                                                      // 674
                if (loadIndex != -1)                                                                                   // 675
                    loader.loads.splice(loadIndex, 1);                                                                 // 676
                for (var i = 0, l = load.linkSets.length; i < l; i++) {                                                // 677
                    loadIndex = indexOf.call(load.linkSets[i].loads, load);                                            // 678
                    if (loadIndex != -1)                                                                               // 679
                        load.linkSets[i].loads.splice(loadIndex, 1);                                                   // 680
                }                                                                                                      // 681
                load.linkSets.splice(0, load.linkSets.length);                                                         // 682
            }                                                                                                          // 683
                                                                                                                       // 684
            function doDynamicExecute(linkSet, load, linkError) {                                                      // 685
                try {                                                                                                  // 686
                    var module = load.execute();                                                                       // 687
                }                                                                                                      // 688
                catch(e) {                                                                                             // 689
                    linkError(load, e);                                                                                // 690
                    return;                                                                                            // 691
                }                                                                                                      // 692
                if (!module || !(module instanceof Module))                                                            // 693
                    linkError(load, new TypeError('Execution must define a Module instance'));                         // 694
                else                                                                                                   // 695
                    return module;                                                                                     // 696
            }                                                                                                          // 697
                                                                                                                       // 698
            // 26.3 Loader                                                                                             // 699
                                                                                                                       // 700
            // 26.3.1.1                                                                                                // 701
            // defined at top                                                                                          // 702
                                                                                                                       // 703
            // importPromises adds ability to import a module twice without error - https://bugs.ecmascript.org/show_bug.cgi?id=2601
            function createImportPromise(loader, name, promise) {                                                      // 705
                var importPromises = loader._loader.importPromises;                                                    // 706
                return importPromises[name] = promise.then(function(m) {                                               // 707
                    importPromises[name] = undefined;                                                                  // 708
                    return m;                                                                                          // 709
                }, function(e) {                                                                                       // 710
                    importPromises[name] = undefined;                                                                  // 711
                    throw e;                                                                                           // 712
                });                                                                                                    // 713
            }                                                                                                          // 714
                                                                                                                       // 715
            Loader.prototype = {                                                                                       // 716
                // 26.3.3.1                                                                                            // 717
                constructor: Loader,                                                                                   // 718
                // 26.3.3.2                                                                                            // 719
                define: function(name, source, options) {                                                              // 720
                    // check if already defined                                                                        // 721
                    if (this._loader.importPromises[name])                                                             // 722
                        throw new TypeError('Module is already loading.');                                             // 723
                    return createImportPromise(this, name, new Promise(asyncStartLoadPartwayThrough({                  // 724
                        step: 'translate',                                                                             // 725
                        loader: this._loader,                                                                          // 726
                        moduleName: name,                                                                              // 727
                        moduleMetadata: options && options.metadata || {},                                             // 728
                        moduleSource: source,                                                                          // 729
                        moduleAddress: options && options.address                                                      // 730
                    })));                                                                                              // 731
                },                                                                                                     // 732
                // 26.3.3.3                                                                                            // 733
                'delete': function(name) {                                                                             // 734
                    var loader = this._loader;                                                                         // 735
                    delete loader.importPromises[name];                                                                // 736
                    delete loader.moduleRecords[name];                                                                 // 737
                    return loader.modules[name] ? delete loader.modules[name] : false;                                 // 738
                },                                                                                                     // 739
                // 26.3.3.4 entries not implemented                                                                    // 740
                // 26.3.3.5                                                                                            // 741
                get: function(key) {                                                                                   // 742
                    if (!this._loader.modules[key])                                                                    // 743
                        return;                                                                                        // 744
                    doEnsureEvaluated(this._loader.modules[key], [], this);                                            // 745
                    return this._loader.modules[key].module;                                                           // 746
                },                                                                                                     // 747
                // 26.3.3.7                                                                                            // 748
                has: function(name) {                                                                                  // 749
                    return !!this._loader.modules[name];                                                               // 750
                },                                                                                                     // 751
                // 26.3.3.8                                                                                            // 752
                'import': function(name, parentName, parentAddress) {                                                  // 753
                    if (typeof parentName == 'object')                                                                 // 754
                        parentName = parentName.name;                                                                  // 755
                                                                                                                       // 756
                    // run normalize first                                                                             // 757
                    var loaderObj = this;                                                                              // 758
                                                                                                                       // 759
                    // added, see https://bugs.ecmascript.org/show_bug.cgi?id=2659                                     // 760
                    return Promise.resolve(loaderObj.normalize(name, parentName))                                      // 761
                        .then(function(name) {                                                                         // 762
                            var loader = loaderObj._loader;                                                            // 763
                                                                                                                       // 764
                            if (loader.modules[name]) {                                                                // 765
                                doEnsureEvaluated(loader.modules[name], [], loader._loader);                           // 766
                                return loader.modules[name].module;                                                    // 767
                            }                                                                                          // 768
                                                                                                                       // 769
                            return loader.importPromises[name] || createImportPromise(loaderObj, name,                 // 770
                                    loadModule(loader, name, {})                                                       // 771
                                        .then(function(load) {                                                         // 772
                                            delete loader.importPromises[name];                                        // 773
                                            return evaluateLoadedModule(loader, load);                                 // 774
                                        }));                                                                           // 775
                        });                                                                                            // 776
                },                                                                                                     // 777
                // 26.3.3.9 keys not implemented                                                                       // 778
                // 26.3.3.10                                                                                           // 779
                load: function(name, options) {                                                                        // 780
                    if (this._loader.modules[name]) {                                                                  // 781
                        doEnsureEvaluated(this._loader.modules[name], [], this._loader);                               // 782
                        return Promise.resolve(this._loader.modules[name].module);                                     // 783
                    }                                                                                                  // 784
                    return this._loader.importPromises[name] || createImportPromise(this, name, loadModule(this._loader, name, {}));
                },                                                                                                     // 786
                // 26.3.3.11                                                                                           // 787
                module: function(source, options) {                                                                    // 788
                    var load = createLoad();                                                                           // 789
                    load.address = options && options.address;                                                         // 790
                    var linkSet = createLinkSet(this._loader, load);                                                   // 791
                    var sourcePromise = Promise.resolve(source);                                                       // 792
                    var loader = this._loader;                                                                         // 793
                    var p = linkSet.done.then(function() {                                                             // 794
                        return evaluateLoadedModule(loader, load);                                                     // 795
                    });                                                                                                // 796
                    proceedToTranslate(loader, load, sourcePromise);                                                   // 797
                    return p;                                                                                          // 798
                },                                                                                                     // 799
                // 26.3.3.12                                                                                           // 800
                newModule: function (obj) {                                                                            // 801
                    if (typeof obj != 'object')                                                                        // 802
                        throw new TypeError('Expected object');                                                        // 803
                                                                                                                       // 804
                    // we do this to be able to tell if a module is a module privately in ES5                          // 805
                    // by doing m instanceof Module                                                                    // 806
                    var m = new Module();                                                                              // 807
                                                                                                                       // 808
                    var pNames;                                                                                        // 809
                    if (Object.getOwnPropertyNames && obj != null) {                                                   // 810
                        pNames = Object.getOwnPropertyNames(obj);                                                      // 811
                    }                                                                                                  // 812
                    else {                                                                                             // 813
                        pNames = [];                                                                                   // 814
                        for (var key in obj)                                                                           // 815
                            pNames.push(key);                                                                          // 816
                    }                                                                                                  // 817
                                                                                                                       // 818
                    for (var i = 0; i < pNames.length; i++) (function(key) {                                           // 819
                        defineProperty(m, key, {                                                                       // 820
                            configurable: false,                                                                       // 821
                            enumerable: true,                                                                          // 822
                            get: function () {                                                                         // 823
                                return obj[key];                                                                       // 824
                            }                                                                                          // 825
                        });                                                                                            // 826
                    })(pNames[i]);                                                                                     // 827
                                                                                                                       // 828
                    if (Object.preventExtensions)                                                                      // 829
                        Object.preventExtensions(m);                                                                   // 830
                                                                                                                       // 831
                    return m;                                                                                          // 832
                },                                                                                                     // 833
                // 26.3.3.14                                                                                           // 834
                set: function(name, module) {                                                                          // 835
                    if (!(module instanceof Module))                                                                   // 836
                        throw new TypeError('Loader.set(' + name + ', module) must be a module');                      // 837
                    this._loader.modules[name] = {                                                                     // 838
                        module: module                                                                                 // 839
                    };                                                                                                 // 840
                },                                                                                                     // 841
                // 26.3.3.15 values not implemented                                                                    // 842
                // 26.3.3.16 @@iterator not implemented                                                                // 843
                // 26.3.3.17 @@toStringTag not implemented                                                             // 844
                                                                                                                       // 845
                // 26.3.3.18.1                                                                                         // 846
                normalize: function(name, referrerName, referrerAddress) {                                             // 847
                    return name;                                                                                       // 848
                },                                                                                                     // 849
                // 26.3.3.18.2                                                                                         // 850
                locate: function(load) {                                                                               // 851
                    return load.name;                                                                                  // 852
                },                                                                                                     // 853
                // 26.3.3.18.3                                                                                         // 854
                fetch: function(load) {                                                                                // 855
                },                                                                                                     // 856
                // 26.3.3.18.4                                                                                         // 857
                translate: function(load) {                                                                            // 858
                    return load.source;                                                                                // 859
                },                                                                                                     // 860
                // 26.3.3.18.5                                                                                         // 861
                instantiate: function(load) {                                                                          // 862
                }                                                                                                      // 863
            };                                                                                                         // 864
                                                                                                                       // 865
            var _newModule = Loader.prototype.newModule;                                                               // 866
            /*                                                                                                         // 867
             * ES6 Module Declarative Linking Code - Dev Build Only                                                    // 868
             */                                                                                                        // 869
            function link(linkSet, linkError) {                                                                        // 870
                                                                                                                       // 871
                var loader = linkSet.loader;                                                                           // 872
                                                                                                                       // 873
                if (!linkSet.loads.length)                                                                             // 874
                    return;                                                                                            // 875
                                                                                                                       // 876
                var loads = linkSet.loads.concat([]);                                                                  // 877
                                                                                                                       // 878
                for (var i = 0; i < loads.length; i++) {                                                               // 879
                    var load = loads[i];                                                                               // 880
                                                                                                                       // 881
                    var module = doDynamicExecute(linkSet, load, linkError);                                           // 882
                    if (!module)                                                                                       // 883
                        return;                                                                                        // 884
                    load.module = {                                                                                    // 885
                        name: load.name,                                                                               // 886
                        module: module                                                                                 // 887
                    };                                                                                                 // 888
                    load.status = 'linked';                                                                            // 889
                                                                                                                       // 890
                    finishLoad(loader, load);                                                                          // 891
                }                                                                                                      // 892
            }                                                                                                          // 893
                                                                                                                       // 894
            function evaluateLoadedModule(loader, load) {                                                              // 895
                console.assert(load.status == 'linked', 'is linked ' + load.name);                                     // 896
                return load.module.module;                                                                             // 897
            }                                                                                                          // 898
                                                                                                                       // 899
            function doEnsureEvaluated() {}                                                                            // 900
                                                                                                                       // 901
            function transpile() {                                                                                     // 902
                throw new TypeError('ES6 transpilation is only provided in the dev module loader build.');             // 903
            }                                                                                                          // 904
        })();/*                                                                                                        // 905
         *********************************************************************************************                 // 906
                                                                                                                       // 907
         System Loader Implementation                                                                                  // 908
                                                                                                                       // 909
         - Implemented to https://github.com/jorendorff/js-loaders/blob/master/browser-loader.js                       // 910
                                                                                                                       // 911
         - <script type="module"> supported                                                                            // 912
                                                                                                                       // 913
         *********************************************************************************************                 // 914
         */                                                                                                            // 915
                                                                                                                       // 916
        var System;                                                                                                    // 917
                                                                                                                       // 918
        function SystemLoader() {                                                                                      // 919
            Loader.call(this);                                                                                         // 920
            this.paths = {};                                                                                           // 921
        }                                                                                                              // 922
                                                                                                                       // 923
// NB no specification provided for System.paths, used ideas discussed in https://github.com/jorendorff/js-loaders/issues/25
        function applyPaths(paths, name) {                                                                             // 925
            // most specific (most number of slashes in path) match wins                                               // 926
            var pathMatch = '', wildcard, maxSlashCount = 0;                                                           // 927
                                                                                                                       // 928
            // check to see if we have a paths entry                                                                   // 929
            for (var p in paths) {                                                                                     // 930
                var pathParts = p.split('*');                                                                          // 931
                if (pathParts.length > 2)                                                                              // 932
                    throw new TypeError('Only one wildcard in a path is permitted');                                   // 933
                                                                                                                       // 934
                // exact path match                                                                                    // 935
                if (pathParts.length == 1) {                                                                           // 936
                    if (name == p) {                                                                                   // 937
                        pathMatch = p;                                                                                 // 938
                        break;                                                                                         // 939
                    }                                                                                                  // 940
                }                                                                                                      // 941
                // wildcard path match                                                                                 // 942
                else {                                                                                                 // 943
                    var slashCount = p.split('/').length;                                                              // 944
                    if (slashCount >= maxSlashCount &&                                                                 // 945
                        name.substr(0, pathParts[0].length) == pathParts[0] &&                                         // 946
                        name.substr(name.length - pathParts[1].length) == pathParts[1]) {                              // 947
                        maxSlashCount = slashCount;                                                                    // 948
                        pathMatch = p;                                                                                 // 949
                        wildcard = name.substr(pathParts[0].length, name.length - pathParts[1].length - pathParts[0].length);
                    }                                                                                                  // 951
                }                                                                                                      // 952
            }                                                                                                          // 953
                                                                                                                       // 954
            var outPath = paths[pathMatch] || name;                                                                    // 955
            if (wildcard)                                                                                              // 956
                outPath = outPath.replace('*', wildcard);                                                              // 957
                                                                                                                       // 958
            return outPath;                                                                                            // 959
        }                                                                                                              // 960
                                                                                                                       // 961
// inline Object.create-style class extension                                                                          // 962
        function LoaderProto() {}                                                                                      // 963
        LoaderProto.prototype = Loader.prototype;                                                                      // 964
        SystemLoader.prototype = new LoaderProto();                                                                    // 965
        var fetchTextFromURL;                                                                                          // 966
        if (typeof XMLHttpRequest != 'undefined') {                                                                    // 967
            fetchTextFromURL = function(url, fulfill, reject) {                                                        // 968
                // percent encode just '#' in urls                                                                     // 969
                // according to https://github.com/jorendorff/js-loaders/blob/master/browser-loader.js#L238            // 970
                // we should encode everything, but it breaks for servers that don't expect it                         // 971
                // like in (https://github.com/systemjs/systemjs/issues/168)                                           // 972
                if (isBrowser)                                                                                         // 973
                    url = url.replace(/#/g, '%23');                                                                    // 974
                                                                                                                       // 975
                var xhr = new XMLHttpRequest();                                                                        // 976
                var sameDomain = true;                                                                                 // 977
                var doTimeout = false;                                                                                 // 978
                if (!('withCredentials' in xhr)) {                                                                     // 979
                    // check if same domain                                                                            // 980
                    var domainCheck = /^(\w+:)?\/\/([^\/]+)/.exec(url);                                                // 981
                    if (domainCheck) {                                                                                 // 982
                        sameDomain = domainCheck[2] === window.location.host;                                          // 983
                        if (domainCheck[1])                                                                            // 984
                            sameDomain &= domainCheck[1] === window.location.protocol;                                 // 985
                    }                                                                                                  // 986
                }                                                                                                      // 987
                if (!sameDomain && typeof XDomainRequest != 'undefined') {                                             // 988
                    xhr = new XDomainRequest();                                                                        // 989
                    xhr.onload = load;                                                                                 // 990
                    xhr.onerror = error;                                                                               // 991
                    xhr.ontimeout = error;                                                                             // 992
                    xhr.onprogress = function() {};                                                                    // 993
                    xhr.timeout = 0;                                                                                   // 994
                    doTimeout = true;                                                                                  // 995
                }                                                                                                      // 996
                function load() {                                                                                      // 997
                    fulfill(xhr.responseText);                                                                         // 998
                }                                                                                                      // 999
                function error() {                                                                                     // 1000
                    reject(xhr.statusText + ': ' + url || 'XHR error');                                                // 1001
                }                                                                                                      // 1002
                                                                                                                       // 1003
                xhr.onreadystatechange = function () {                                                                 // 1004
                    if (xhr.readyState === 4) {                                                                        // 1005
                        if (xhr.status === 200 || (xhr.status == 0 && xhr.responseText)) {                             // 1006
                            load();                                                                                    // 1007
                        } else {                                                                                       // 1008
                            error();                                                                                   // 1009
                        }                                                                                              // 1010
                    }                                                                                                  // 1011
                };                                                                                                     // 1012
                xhr.open("GET", url, true);                                                                            // 1013
                                                                                                                       // 1014
                if (doTimeout)                                                                                         // 1015
                    setTimeout(function() {                                                                            // 1016
                        xhr.send();                                                                                    // 1017
                    }, 0);                                                                                             // 1018
                                                                                                                       // 1019
                xhr.send(null);                                                                                        // 1020
            };                                                                                                         // 1021
        }                                                                                                              // 1022
        else if (typeof require != 'undefined') {                                                                      // 1023
            var fs;                                                                                                    // 1024
            fetchTextFromURL = function(url, fulfill, reject) {                                                        // 1025
                if (url.substr(0, 8) != 'file:///')                                                                    // 1026
                    throw 'Only file URLs of the form file:/// allowed running in Node.';                              // 1027
                fs = fs || require('fs');                                                                              // 1028
                if (isWindows)                                                                                         // 1029
                    url = url.replace(/\//g, '\\').substr(8);                                                          // 1030
                else                                                                                                   // 1031
                    url = url.substr(7);                                                                               // 1032
                return fs.readFile(url, function(err, data) {                                                          // 1033
                    if (err)                                                                                           // 1034
                        return reject(err);                                                                            // 1035
                    else {                                                                                             // 1036
                        // Strip Byte Order Mark out if it's the leading char                                          // 1037
                        var dataString = data + '';                                                                    // 1038
                        if (dataString[0] === '\ufeff')                                                                // 1039
                            dataString = dataString.substr(1);                                                         // 1040
                                                                                                                       // 1041
                        fulfill(dataString);                                                                           // 1042
                    }                                                                                                  // 1043
                });                                                                                                    // 1044
            };                                                                                                         // 1045
        }                                                                                                              // 1046
        else {                                                                                                         // 1047
            throw new TypeError('No environment fetch API available.');                                                // 1048
        }                                                                                                              // 1049
                                                                                                                       // 1050
        SystemLoader.prototype.fetch = function(load) {                                                                // 1051
            return new Promise(function(resolve, reject) {                                                             // 1052
                fetchTextFromURL(load.address, resolve, reject);                                                       // 1053
            });                                                                                                        // 1054
        };/*                                                                                                           // 1055
         * Traceur, Babel and TypeScript transpile hook for Loader                                                     // 1056
         */                                                                                                            // 1057
        var transpile = (function() {                                                                                  // 1058
                                                                                                                       // 1059
            // use Traceur by default                                                                                  // 1060
            Loader.prototype.transpiler = 'traceur';                                                                   // 1061
                                                                                                                       // 1062
            function transpile(load) {                                                                                 // 1063
                var self = this;                                                                                       // 1064
                                                                                                                       // 1065
                return Promise.resolve(__global[self.transpiler == 'typescript' ? 'ts' : self.transpiler]              // 1066
                    || (self.pluginLoader || self)['import'](self.transpiler))                                         // 1067
                    .then(function(transpiler) {                                                                       // 1068
                        if (transpiler.__useDefault)                                                                   // 1069
                            transpiler = transpiler['default'];                                                        // 1070
                                                                                                                       // 1071
                        var transpileFunction;                                                                         // 1072
                        if (transpiler.Compiler)                                                                       // 1073
                            transpileFunction = traceurTranspile;                                                      // 1074
                        else if (transpiler.createLanguageService)                                                     // 1075
                            transpileFunction = typescriptTranspile;                                                   // 1076
                        else                                                                                           // 1077
                            transpileFunction = babelTranspile;                                                        // 1078
                                                                                                                       // 1079
                        // note __moduleName will be part of the transformer meta in future when we have the spec for this
                        return 'var __moduleName = "' + load.name + '";' + transpileFunction.call(self, load, transpiler) + '\n//# sourceURL=' + load.address + '!transpiled';
                    });                                                                                                // 1082
            };                                                                                                         // 1083
                                                                                                                       // 1084
            function traceurTranspile(load, traceur) {                                                                 // 1085
                var options = this.traceurOptions || {};                                                               // 1086
                options.modules = 'instantiate';                                                                       // 1087
                options.script = false;                                                                                // 1088
                options.sourceMaps = 'inline';                                                                         // 1089
                options.filename = load.address;                                                                       // 1090
                options.inputSourceMap = load.metadata.sourceMap;                                                      // 1091
                options.moduleName = false;                                                                            // 1092
                                                                                                                       // 1093
                var compiler = new traceur.Compiler(options);                                                          // 1094
                                                                                                                       // 1095
                return doTraceurCompile(load.source, compiler, options.filename);                                      // 1096
            }                                                                                                          // 1097
            function doTraceurCompile(source, compiler, filename) {                                                    // 1098
                try {                                                                                                  // 1099
                    return compiler.compile(source, filename);                                                         // 1100
                }                                                                                                      // 1101
                catch(e) {                                                                                             // 1102
                    // traceur throws an error array                                                                   // 1103
                    throw e[0];                                                                                        // 1104
                }                                                                                                      // 1105
            }                                                                                                          // 1106
                                                                                                                       // 1107
            function babelTranspile(load, babel) {                                                                     // 1108
                var options = this.babelOptions || {};                                                                 // 1109
                options.modules = 'system';                                                                            // 1110
                options.sourceMap = 'inline';                                                                          // 1111
                options.inputSourceMap = load.metadata.sourceMap;                                                      // 1112
                options.filename = load.address;                                                                       // 1113
                options.code = true;                                                                                   // 1114
                options.ast = false;                                                                                   // 1115
                                                                                                                       // 1116
                return babel.transform(load.source, options).code;                                                     // 1117
            }                                                                                                          // 1118
                                                                                                                       // 1119
            function typescriptTranspile(load, ts) {                                                                   // 1120
                var options = this.typescriptOptions || {};                                                            // 1121
                if (options.target === undefined) {                                                                    // 1122
                    options.target = ts.ScriptTarget.ES5;                                                              // 1123
                }                                                                                                      // 1124
                options.module = ts.ModuleKind.System;                                                                 // 1125
                options.inlineSourceMap = true;                                                                        // 1126
                                                                                                                       // 1127
                return ts.transpile(load.source, options, load.address);                                               // 1128
            }                                                                                                          // 1129
                                                                                                                       // 1130
            return transpile;                                                                                          // 1131
        })();                                                                                                          // 1132
// we define a __exec for globally-scoped execution                                                                    // 1133
// used by module format implementations                                                                               // 1134
        var __exec;                                                                                                    // 1135
                                                                                                                       // 1136
        (function() {                                                                                                  // 1137
                                                                                                                       // 1138
            // System clobbering protection (mostly for Traceur)                                                       // 1139
            var curSystem;                                                                                             // 1140
            function preExec(loader) {                                                                                 // 1141
                curSystem = __global.System;                                                                           // 1142
                __global.System = loader;                                                                              // 1143
            }                                                                                                          // 1144
            function postExec() {                                                                                      // 1145
                __global.System = curSystem;                                                                           // 1146
            }                                                                                                          // 1147
                                                                                                                       // 1148
            var hasBtoa = typeof btoa != 'undefined';                                                                  // 1149
                                                                                                                       // 1150
            function getSource(load) {                                                                                 // 1151
                var lastLineIndex = load.source.lastIndexOf('\n');                                                     // 1152
                                                                                                                       // 1153
                return load.source                                                                                     // 1154
                        // adds the sourceURL comment if not already present                                           // 1155
                    + (load.source.substr(lastLineIndex, 15) != '\n//# sourceURL='                                     // 1156
                        ? '\n//# sourceURL=' + load.address + (load.metadata.sourceMap ? '!transpiled' : '') : '')     // 1157
                        // add sourceMappingURL if load.metadata.sourceMap is set                                      // 1158
                    + (load.metadata.sourceMap && hasBtoa &&                                                           // 1159
                    '\n//# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(load.metadata.sourceMap))) || '')
            }                                                                                                          // 1161
                                                                                                                       // 1162
            // use script injection eval to get identical global script behaviour                                      // 1163
            if (typeof document != 'undefined') {                                                                      // 1164
                var head;                                                                                              // 1165
                                                                                                                       // 1166
                var scripts = document.getElementsByTagName('script');                                                 // 1167
                $__curScript = scripts[scripts.length - 1];                                                            // 1168
                                                                                                                       // 1169
                __exec = function(load) {                                                                              // 1170
                    if (!head)                                                                                         // 1171
                        head = document.head || document.body || document.documentElement;                             // 1172
                                                                                                                       // 1173
                    var script = document.createElement('script');                                                     // 1174
                    script.text = getSource(load);                                                                     // 1175
                    var onerror = window.onerror;                                                                      // 1176
                    var e;                                                                                             // 1177
                    window.onerror = function(_e) {                                                                    // 1178
                        e = addToError(_e, 'Evaluating ' + load.address);                                              // 1179
                    }                                                                                                  // 1180
                    preExec(this);                                                                                     // 1181
                    head.appendChild(script);                                                                          // 1182
                    head.removeChild(script);                                                                          // 1183
                    postExec();                                                                                        // 1184
                    window.onerror = onerror;                                                                          // 1185
                    if (e)                                                                                             // 1186
                        throw e;                                                                                       // 1187
                }                                                                                                      // 1188
            }                                                                                                          // 1189
            // Web Worker uses original ESML eval                                                                      // 1190
            // this may lead to some global module execution differences (eg var not defining onto global)             // 1191
            else if (isWorker) {                                                                                       // 1192
                __exec = function(load) {                                                                              // 1193
                    try {                                                                                              // 1194
                        preExec(this);                                                                                 // 1195
                        new Function(getSource(load)).call(__global);                                                  // 1196
                        postExec();                                                                                    // 1197
                    }                                                                                                  // 1198
                    catch(e) {                                                                                         // 1199
                        throw addToError(e, 'Evaluating ' + load.address);                                             // 1200
                    }                                                                                                  // 1201
                };                                                                                                     // 1202
            }                                                                                                          // 1203
            else {                                                                                                     // 1204
                // global scoped eval for node                                                                         // 1205
                var vmModule = 'vm';                                                                                   // 1206
                /* --- Core change to support Meteor --- */                                                            // 1207
                var vm = Npm.require(vmModule);                                                                        // 1208
                /* --- end of core change --- */                                                                       // 1209
                __exec = function(load) {                                                                              // 1210
                    try {                                                                                              // 1211
                        preExec(this);                                                                                 // 1212
                        vm.runInThisContext(getSource(load));                                                          // 1213
                        postExec();                                                                                    // 1214
                    }                                                                                                  // 1215
                    catch(e) {                                                                                         // 1216
                        throw addToError(e.toString(), 'Evaluating ' + load.address);                                  // 1217
                    }                                                                                                  // 1218
                };                                                                                                     // 1219
            }                                                                                                          // 1220
                                                                                                                       // 1221
        })();// SystemJS Loader Class and Extension helpers                                                            // 1222
                                                                                                                       // 1223
        function SystemJSLoader() {                                                                                    // 1224
            SystemLoader.call(this);                                                                                   // 1225
                                                                                                                       // 1226
            systemJSConstructor.call(this);                                                                            // 1227
        }                                                                                                              // 1228
                                                                                                                       // 1229
// inline Object.create-style class extension                                                                          // 1230
        function SystemProto() {};                                                                                     // 1231
        SystemProto.prototype = SystemLoader.prototype;                                                                // 1232
        SystemJSLoader.prototype = new SystemProto();                                                                  // 1233
                                                                                                                       // 1234
        var systemJSConstructor;                                                                                       // 1235
                                                                                                                       // 1236
        function hook(name, hook) {                                                                                    // 1237
            SystemJSLoader.prototype[name] = hook(SystemJSLoader.prototype[name]);                                     // 1238
        }                                                                                                              // 1239
        function hookConstructor(hook) {                                                                               // 1240
            systemJSConstructor = hook(systemJSConstructor || function() {});                                          // 1241
        }                                                                                                              // 1242
                                                                                                                       // 1243
        function dedupe(deps) {                                                                                        // 1244
            var newDeps = [];                                                                                          // 1245
            for (var i = 0, l = deps.length; i < l; i++)                                                               // 1246
                if (indexOf.call(newDeps, deps[i]) == -1)                                                              // 1247
                    newDeps.push(deps[i])                                                                              // 1248
            return newDeps;                                                                                            // 1249
        }                                                                                                              // 1250
                                                                                                                       // 1251
        function extend(a, b, underwrite) {                                                                            // 1252
            for (var p in b) {                                                                                         // 1253
                if (!underwrite || !(p in a))                                                                          // 1254
                    a[p] = b[p];                                                                                       // 1255
            }                                                                                                          // 1256
        }var absURLRegEx = /^[^\/]+:\/\//;                                                                             // 1257
                                                                                                                       // 1258
        function readMemberExpression(p, value) {                                                                      // 1259
            var pParts = p.split('.');                                                                                 // 1260
            while (pParts.length)                                                                                      // 1261
                value = value[pParts.shift()];                                                                         // 1262
            return value;                                                                                              // 1263
        }                                                                                                              // 1264
                                                                                                                       // 1265
        var baseURLCache = {};                                                                                         // 1266
        function getBaseURLObj() {                                                                                     // 1267
            if (baseURLCache[this.baseURL])                                                                            // 1268
                return baseURLCache[this.baseURL];                                                                     // 1269
                                                                                                                       // 1270
            // normalize baseURL if not already                                                                        // 1271
            if (this.baseURL[this.baseURL.length - 1] != '/')                                                          // 1272
                this.baseURL += '/';                                                                                   // 1273
                                                                                                                       // 1274
            var baseURL = new URL(this.baseURL, baseURI);                                                              // 1275
                                                                                                                       // 1276
            this.baseURL = baseURL.href;                                                                               // 1277
                                                                                                                       // 1278
            return (baseURLCache[this.baseURL] = baseURL);                                                             // 1279
        }                                                                                                              // 1280
                                                                                                                       // 1281
        var baseURIObj = new URL(baseURI);                                                                             // 1282
                                                                                                                       // 1283
        (function() {                                                                                                  // 1284
                                                                                                                       // 1285
            hookConstructor(function(constructor) {                                                                    // 1286
                return function() {                                                                                    // 1287
                    constructor.call(this);                                                                            // 1288
                                                                                                                       // 1289
                    // support baseURL                                                                                 // 1290
                    this.baseURL = baseURI.substr(0, baseURI.lastIndexOf('/') + 1);                                    // 1291
                                                                                                                       // 1292
                    // support the empty module, as a concept                                                          // 1293
                    this.set('@empty', this.newModule({}));                                                            // 1294
                };                                                                                                     // 1295
            });                                                                                                        // 1296
                                                                                                                       // 1297
            /*                                                                                                         // 1298
             Normalization                                                                                             // 1299
                                                                                                                       // 1300
             If a name is relative, we apply URL normalization to the page                                             // 1301
             If a name is an absolute URL, we leave it as-is                                                           // 1302
                                                                                                                       // 1303
             Plain names (neither of the above) run through the map and package                                        // 1304
             normalization phases (applying before and after this one).                                                // 1305
                                                                                                                       // 1306
             The paths normalization phase applies last (paths extension), which                                       // 1307
             defines the `normalizeSync` function and normalizes everything into                                       // 1308
             a URL.                                                                                                    // 1309
                                                                                                                       // 1310
             The final normalization                                                                                   // 1311
             */                                                                                                        // 1312
            hook('normalize', function() {                                                                             // 1313
                return function(name, parentName) {                                                                    // 1314
                    // relative URL-normalization                                                                      // 1315
                    if (name[0] == '.' || name[0] == '/')                                                              // 1316
                        return new URL(name, parentName || baseURIObj).href;                                           // 1317
                    return name;                                                                                       // 1318
                };                                                                                                     // 1319
            });                                                                                                        // 1320
                                                                                                                       // 1321
            /*                                                                                                         // 1322
             __useDefault                                                                                              // 1323
                                                                                                                       // 1324
             When a module object looks like:                                                                          // 1325
             newModule(                                                                                                // 1326
             __useDefault: true,                                                                                       // 1327
             default: 'some-module'                                                                                    // 1328
             })                                                                                                        // 1329
                                                                                                                       // 1330
             Then importing that module provides the 'some-module'                                                     // 1331
             result directly instead of the full module.                                                               // 1332
                                                                                                                       // 1333
             Useful for eg module.exports = function() {}                                                              // 1334
             */                                                                                                        // 1335
            hook('import', function(systemImport) {                                                                    // 1336
                return function(name, parentName, parentAddress) {                                                     // 1337
                    return systemImport.call(this, name, parentName, parentAddress).then(function(module) {            // 1338
                        return module.__useDefault ? module['default'] : module;                                       // 1339
                    });                                                                                                // 1340
                };                                                                                                     // 1341
            });                                                                                                        // 1342
                                                                                                                       // 1343
            /*                                                                                                         // 1344
             Extend config merging one deep only                                                                       // 1345
                                                                                                                       // 1346
             loader.config({                                                                                           // 1347
             some: 'random',                                                                                           // 1348
             config: 'here',                                                                                           // 1349
             deep: {                                                                                                   // 1350
             config: { too: 'too' }                                                                                    // 1351
             }                                                                                                         // 1352
             });                                                                                                       // 1353
                                                                                                                       // 1354
             <=>                                                                                                       // 1355
                                                                                                                       // 1356
             loader.some = 'random';                                                                                   // 1357
             loader.config = 'here'                                                                                    // 1358
             loader.deep = loader.deep || {};                                                                          // 1359
             loader.deep.config = { too: 'too' };                                                                      // 1360
                                                                                                                       // 1361
                                                                                                                       // 1362
             Normalizes meta and package configs allowing for:                                                         // 1363
                                                                                                                       // 1364
             System.config({                                                                                           // 1365
             meta: {                                                                                                   // 1366
             './index.js': {}                                                                                          // 1367
             }                                                                                                         // 1368
             });                                                                                                       // 1369
                                                                                                                       // 1370
             To become                                                                                                 // 1371
                                                                                                                       // 1372
             System.meta['https://thissite.com/index.js'] = {};                                                        // 1373
                                                                                                                       // 1374
             For easy normalization canonicalization with latest URL support.                                          // 1375
                                                                                                                       // 1376
             */                                                                                                        // 1377
            SystemJSLoader.prototype.config = function(cfg) {                                                          // 1378
                                                                                                                       // 1379
                // always configure baseURL first                                                                      // 1380
                if (cfg.baseURL) {                                                                                     // 1381
                    var hasConfig = false;                                                                             // 1382
                    function checkHasConfig(obj) {                                                                     // 1383
                        for (var p in obj)                                                                             // 1384
                            return true;                                                                               // 1385
                    }                                                                                                  // 1386
                    if (checkHasConfig(this.packages) || checkHasConfig(this.meta) || checkHasConfig(this.depCache) || checkHasConfig(this.bundles))
                        throw new TypeError('baseURL should only be configured once and must be configured first.');   // 1388
                                                                                                                       // 1389
                    this.baseURL = cfg.baseURL;                                                                        // 1390
                                                                                                                       // 1391
                    // sanitize baseURL                                                                                // 1392
                    getBaseURLObj.call(this);                                                                          // 1393
                }                                                                                                      // 1394
                                                                                                                       // 1395
                if (cfg.paths) {                                                                                       // 1396
                    for (var p in cfg.paths)                                                                           // 1397
                        this.paths[p] = cfg.paths[p];                                                                  // 1398
                }                                                                                                      // 1399
                                                                                                                       // 1400
                if (cfg.map) {                                                                                         // 1401
                    for (var p in cfg.map) {                                                                           // 1402
                        var v = cfg.map[p];                                                                            // 1403
                                                                                                                       // 1404
                        // object map backwards-compat into packages configuration                                     // 1405
                        if (typeof v !== 'string') {                                                                   // 1406
                            var normalized = this.normalizeSync(p);                                                    // 1407
                                                                                                                       // 1408
                            // if doing default js extensions, undo to get package name                                // 1409
                            if (this.defaultJSExtensions && p.substr(p.length - 3, 3) != '.js')                        // 1410
                                normalized = normalized.substr(0, normalized.length - 3);                              // 1411
                                                                                                                       // 1412
                            // if a package main, revert it                                                            // 1413
                            var pkgMatch = '';                                                                         // 1414
                            for (var pkg in this.packages) {                                                           // 1415
                                if (normalized.substr(0, pkg.length) == pkg                                            // 1416
                                    && (!normalized[pkg.length] || normalized[pkg.length] == '/')                      // 1417
                                    && pkgMatch.split('/').length < pkg.split('/').length)                             // 1418
                                    pkgMatch = pkg;                                                                    // 1419
                            }                                                                                          // 1420
                            if (pkgMatch && this.packages[pkgMatch].main)                                              // 1421
                                normalized = normalized.substr(0, normalized.length - this.packages[pkgMatch].main.length - 1);
                                                                                                                       // 1423
                            var pkg = this.packages[normalized] = this.packages[normalized] || {};                     // 1424
                            pkg.map = v;                                                                               // 1425
                        }                                                                                              // 1426
                        else {                                                                                         // 1427
                            this.map[p] = v;                                                                           // 1428
                        }                                                                                              // 1429
                    }                                                                                                  // 1430
                }                                                                                                      // 1431
                                                                                                                       // 1432
                if (cfg.packages) {                                                                                    // 1433
                    for (var p in cfg.packages) {                                                                      // 1434
                        var prop = this.normalizeSync(p);                                                              // 1435
                                                                                                                       // 1436
                        // if doing default js extensions, undo to get package name                                    // 1437
                        if (this.defaultJSExtensions && p.substr(p.length - 3, 3) != '.js')                            // 1438
                            prop = prop.substr(0, prop.length - 3);                                                    // 1439
                                                                                                                       // 1440
                        this.packages[prop]= this.packages[prop] || {};                                                // 1441
                        for (var q in cfg.packages[p])                                                                 // 1442
                            this.packages[prop][q] = cfg.packages[p][q];                                               // 1443
                    }                                                                                                  // 1444
                }                                                                                                      // 1445
                                                                                                                       // 1446
                if (cfg.bundles) {                                                                                     // 1447
                    for (var p in cfg.bundles) {                                                                       // 1448
                        var bundle = [];                                                                               // 1449
                        for (var i = 0; i < cfg.bundles[p].length; i++)                                                // 1450
                            bundle.push(this.normalizeSync(cfg.bundles[p][i]));                                        // 1451
                        this.bundles[p] = bundle;                                                                      // 1452
                    }                                                                                                  // 1453
                }                                                                                                      // 1454
                                                                                                                       // 1455
                for (var c in cfg) {                                                                                   // 1456
                    var v = cfg[c];                                                                                    // 1457
                    var normalizeProp = false, normalizeValArray = false;                                              // 1458
                                                                                                                       // 1459
                    if (c == 'baseURL' || c == 'map' || c == 'packages' || c == 'bundles' || c == 'paths')             // 1460
                        continue;                                                                                      // 1461
                                                                                                                       // 1462
                    if (typeof v != 'object' || v instanceof Array) {                                                  // 1463
                        this[c] = v;                                                                                   // 1464
                    }                                                                                                  // 1465
                    else {                                                                                             // 1466
                        this[c] = this[c] || {};                                                                       // 1467
                                                                                                                       // 1468
                        if (c == 'meta' || c == 'depCache')                                                            // 1469
                            normalizeProp = true;                                                                      // 1470
                                                                                                                       // 1471
                        for (var p in v) {                                                                             // 1472
                            if (normalizeProp)                                                                         // 1473
                                this[c][this.normalizeSync(p)] = v[p];                                                 // 1474
                            else                                                                                       // 1475
                                this[c][p] = v[p];                                                                     // 1476
                        }                                                                                              // 1477
                    }                                                                                                  // 1478
                }                                                                                                      // 1479
            };                                                                                                         // 1480
                                                                                                                       // 1481
        })();/*                                                                                                        // 1482
         * Script tag fetch                                                                                            // 1483
         *                                                                                                             // 1484
         * When load.metadata.scriptLoad is true, we load via script tag injection.                                    // 1485
         */                                                                                                            // 1486
        (function() {                                                                                                  // 1487
                                                                                                                       // 1488
            if (typeof document != 'undefined')                                                                        // 1489
                var head = document.getElementsByTagName('head')[0];                                                   // 1490
                                                                                                                       // 1491
            // call this functione everytime a wrapper executes                                                        // 1492
            var curSystem;                                                                                             // 1493
            // System clobbering protection for Traceur                                                                // 1494
            SystemJSLoader.prototype.onScriptLoad = function() {                                                       // 1495
                __global.System = curSystem;                                                                           // 1496
            };                                                                                                         // 1497
                                                                                                                       // 1498
            function webWorkerImport(loader, load) {                                                                   // 1499
                return new Promise(function(resolve, reject) {                                                         // 1500
                    try {                                                                                              // 1501
                        importScripts(load.address);                                                                   // 1502
                    }                                                                                                  // 1503
                    catch(e) {                                                                                         // 1504
                        reject(e);                                                                                     // 1505
                    }                                                                                                  // 1506
                                                                                                                       // 1507
                    loader.onScriptLoad(load);                                                                         // 1508
                    // if nothing registered, then something went wrong                                                // 1509
                    if (!load.metadata.registered)                                                                     // 1510
                        reject(load.address + ' did not call System.register or AMD define');                          // 1511
                                                                                                                       // 1512
                    resolve('');                                                                                       // 1513
                });                                                                                                    // 1514
            }                                                                                                          // 1515
                                                                                                                       // 1516
            // override fetch to use script injection                                                                  // 1517
            hook('fetch', function(fetch) {                                                                            // 1518
                return function(load) {                                                                                // 1519
                    var loader = this;                                                                                 // 1520
                                                                                                                       // 1521
                    if (!load.metadata.scriptLoad || (!isBrowser && !isWorker))                                        // 1522
                        return fetch.call(this, load);                                                                 // 1523
                                                                                                                       // 1524
                    if (isWorker)                                                                                      // 1525
                        return webWorkerImport(loader, load);                                                          // 1526
                                                                                                                       // 1527
                    return new Promise(function(resolve, reject) {                                                     // 1528
                        var s = document.createElement('script');                                                      // 1529
                        s.async = true;                                                                                // 1530
                                                                                                                       // 1531
                        function complete(evt) {                                                                       // 1532
                            if (s.readyState && s.readyState != 'loaded' && s.readyState != 'complete')                // 1533
                                return;                                                                                // 1534
                            cleanup();                                                                                 // 1535
                                                                                                                       // 1536
                            // this runs synchronously after execution                                                 // 1537
                            // we now need to tell the wrapper handlers that                                           // 1538
                            // this load record has just executed                                                      // 1539
                            loader.onScriptLoad(load);                                                                 // 1540
                                                                                                                       // 1541
                            // if nothing registered, then something went wrong                                        // 1542
                            if (!load.metadata.registered)                                                             // 1543
                                reject(load.address + ' did not call System.register or AMD define');                  // 1544
                                                                                                                       // 1545
                            resolve('');                                                                               // 1546
                        }                                                                                              // 1547
                                                                                                                       // 1548
                        function error(evt) {                                                                          // 1549
                            cleanup();                                                                                 // 1550
                            reject(new Error('Unable to load script ' + load.address));                                // 1551
                        }                                                                                              // 1552
                                                                                                                       // 1553
                        if (s.attachEvent) {                                                                           // 1554
                            s.attachEvent('onreadystatechange', complete);                                             // 1555
                        }                                                                                              // 1556
                        else {                                                                                         // 1557
                            s.addEventListener('load', complete, false);                                               // 1558
                            s.addEventListener('error', error, false);                                                 // 1559
                        }                                                                                              // 1560
                                                                                                                       // 1561
                        curSystem = __global.System;                                                                   // 1562
                        __global.System = loader;                                                                      // 1563
                        s.src = load.address;                                                                          // 1564
                        head.appendChild(s);                                                                           // 1565
                                                                                                                       // 1566
                        function cleanup() {                                                                           // 1567
                            if (s.detachEvent)                                                                         // 1568
                                s.detachEvent('onreadystatechange', complete);                                         // 1569
                            else {                                                                                     // 1570
                                s.removeEventListener('load', complete, false);                                        // 1571
                                s.removeEventListener('error', error, false);                                          // 1572
                            }                                                                                          // 1573
                            head.removeChild(s);                                                                       // 1574
                        }                                                                                              // 1575
                    });                                                                                                // 1576
                };                                                                                                     // 1577
            });                                                                                                        // 1578
        })();                                                                                                          // 1579
        /*                                                                                                             // 1580
         * Instantiate registry extension                                                                              // 1581
         *                                                                                                             // 1582
         * Supports Traceur System.register 'instantiate' output for loading ES6 as ES5.                               // 1583
         *                                                                                                             // 1584
         * - Creates the loader.register function                                                                      // 1585
         * - Also supports metadata.format = 'register' in instantiate for anonymous register modules                  // 1586
         * - Also supports metadata.deps, metadata.execute and metadata.executingRequire                               // 1587
         *     for handling dynamic modules alongside register-transformed ES6 modules                                 // 1588
         *                                                                                                             // 1589
         *                                                                                                             // 1590
         * The code here replicates the ES6 linking groups algorithm to ensure that                                    // 1591
         * circular ES6 compiled into System.register can work alongside circular AMD                                  // 1592
         * and CommonJS, identically to the actual ES6 loader.                                                         // 1593
         *                                                                                                             // 1594
         */                                                                                                            // 1595
        (function() {                                                                                                  // 1596
                                                                                                                       // 1597
            /*                                                                                                         // 1598
             * There are two variations of System.register:                                                            // 1599
             * 1. System.register for ES6 conversion (2-3 params) - System.register([name, ]deps, declare)             // 1600
             *    see https://github.com/ModuleLoader/es6-module-loader/wiki/System.register-Explained                 // 1601
             *                                                                                                         // 1602
             * 2. System.registerDynamic for dynamic modules (3-4 params) - System.registerDynamic([name, ]deps, executingRequire, execute)
             * the true or false statement                                                                             // 1604
             *                                                                                                         // 1605
             * this extension implements the linking algorithm for the two variations identical to the spec            // 1606
             * allowing compiled ES6 circular references to work alongside AMD and CJS circular references.            // 1607
             *                                                                                                         // 1608
             */                                                                                                        // 1609
            var anonRegister;                                                                                          // 1610
            var calledRegister;                                                                                        // 1611
            function doRegister(loader, name, register) {                                                              // 1612
                calledRegister = true;                                                                                 // 1613
                                                                                                                       // 1614
                // named register                                                                                      // 1615
                if (name) {                                                                                            // 1616
                    name = loader.normalizeSync(name);                                                                 // 1617
                    register.name = name;                                                                              // 1618
                    if (!(name in loader.defined))                                                                     // 1619
                        loader.defined[name] = register;                                                               // 1620
                }                                                                                                      // 1621
                // anonymous register                                                                                  // 1622
                else if (register.declarative) {                                                                       // 1623
                    if (anonRegister)                                                                                  // 1624
                        throw new TypeError('Multiple anonymous System.register calls in the same module file.');      // 1625
                    anonRegister = register;                                                                           // 1626
                }                                                                                                      // 1627
            }                                                                                                          // 1628
            SystemJSLoader.prototype.register = function(name, deps, declare) {                                        // 1629
                if (typeof name != 'string') {                                                                         // 1630
                    declare = deps;                                                                                    // 1631
                    deps = name;                                                                                       // 1632
                    name = null;                                                                                       // 1633
                }                                                                                                      // 1634
                                                                                                                       // 1635
                // dynamic backwards-compatibility                                                                     // 1636
                // can be deprecated eventually                                                                        // 1637
                if (typeof declare == 'boolean')                                                                       // 1638
                    return this.registerDynamic.apply(this, arguments);                                                // 1639
                                                                                                                       // 1640
                doRegister(this, name, {                                                                               // 1641
                    declarative: true,                                                                                 // 1642
                    deps: deps,                                                                                        // 1643
                    declare: declare                                                                                   // 1644
                });                                                                                                    // 1645
            };                                                                                                         // 1646
            SystemJSLoader.prototype.registerDynamic = function(name, deps, declare, execute) {                        // 1647
                if (typeof name != 'string') {                                                                         // 1648
                    execute = declare;                                                                                 // 1649
                    declare = deps;                                                                                    // 1650
                    deps = name;                                                                                       // 1651
                    name = null;                                                                                       // 1652
                }                                                                                                      // 1653
                                                                                                                       // 1654
                // dynamic                                                                                             // 1655
                doRegister(this, name, {                                                                               // 1656
                    declarative: false,                                                                                // 1657
                    deps: deps,                                                                                        // 1658
                    execute: execute,                                                                                  // 1659
                    executingRequire: declare                                                                          // 1660
                });                                                                                                    // 1661
            };                                                                                                         // 1662
            /*                                                                                                         // 1663
             * Registry side table - loader.defined                                                                    // 1664
             * Registry Entry Contains:                                                                                // 1665
             *    - name                                                                                               // 1666
             *    - deps                                                                                               // 1667
             *    - declare for declarative modules                                                                    // 1668
             *    - execute for dynamic modules, different to declarative execute on module                            // 1669
             *    - executingRequire indicates require drives execution for circularity of dynamic modules             // 1670
             *    - declarative optional boolean indicating which of the above                                         // 1671
             *                                                                                                         // 1672
             * Can preload modules directly on System.defined['my/module'] = { deps, execute, executingRequire }       // 1673
             *                                                                                                         // 1674
             * Then the entry gets populated with derived information during processing:                               // 1675
             *    - normalizedDeps derived from deps, created in instantiate                                           // 1676
             *    - groupIndex used by group linking algorithm                                                         // 1677
             *    - evaluated indicating whether evaluation has happend                                                // 1678
             *    - module the module record object, containing:                                                       // 1679
             *      - exports actual module exports                                                                    // 1680
             *                                                                                                         // 1681
             *    For dynamic we track the es module with:                                                             // 1682
             *    - esModule actual es module value                                                                    // 1683
             *                                                                                                         // 1684
             *    Then for declarative only we track dynamic bindings with the 'module' records:                       // 1685
             *      - name                                                                                             // 1686
             *      - exports                                                                                          // 1687
             *      - setters declarative setter functions                                                             // 1688
             *      - dependencies, module records of dependencies                                                     // 1689
             *      - importers, module records of dependents                                                          // 1690
             *                                                                                                         // 1691
             * After linked and evaluated, entries are removed, declarative module records remain in separate          // 1692
             * module binding table                                                                                    // 1693
             *                                                                                                         // 1694
             */                                                                                                        // 1695
            hookConstructor(function(constructor) {                                                                    // 1696
                return function() {                                                                                    // 1697
                    constructor.call(this);                                                                            // 1698
                                                                                                                       // 1699
                    this.defined = {};                                                                                 // 1700
                    this._loader.moduleRecords = {};                                                                   // 1701
                };                                                                                                     // 1702
            });                                                                                                        // 1703
                                                                                                                       // 1704
            // script injection mode calls this function synchronously on load                                         // 1705
            hook('onScriptLoad', function(onScriptLoad) {                                                              // 1706
                return function(load) {                                                                                // 1707
                    onScriptLoad.call(this, load);                                                                     // 1708
                                                                                                                       // 1709
                    // anonymous define                                                                                // 1710
                    if (anonRegister)                                                                                  // 1711
                        load.metadata.entry = anonRegister;                                                            // 1712
                                                                                                                       // 1713
                    if (calledRegister) {                                                                              // 1714
                        load.metadata.format = load.metadata.format || 'defined';                                      // 1715
                        load.metadata.registered = true;                                                               // 1716
                        calledRegister = false;                                                                        // 1717
                        anonRegister = null;                                                                           // 1718
                    }                                                                                                  // 1719
                };                                                                                                     // 1720
            });                                                                                                        // 1721
                                                                                                                       // 1722
            function buildGroups(entry, loader, groups) {                                                              // 1723
                groups[entry.groupIndex] = groups[entry.groupIndex] || [];                                             // 1724
                                                                                                                       // 1725
                if (indexOf.call(groups[entry.groupIndex], entry) != -1)                                               // 1726
                    return;                                                                                            // 1727
                                                                                                                       // 1728
                groups[entry.groupIndex].push(entry);                                                                  // 1729
                                                                                                                       // 1730
                for (var i = 0, l = entry.normalizedDeps.length; i < l; i++) {                                         // 1731
                    var depName = entry.normalizedDeps[i];                                                             // 1732
                    var depEntry = loader.defined[depName];                                                            // 1733
                                                                                                                       // 1734
                    // not in the registry means already linked / ES6                                                  // 1735
                    if (!depEntry || depEntry.evaluated)                                                               // 1736
                        continue;                                                                                      // 1737
                                                                                                                       // 1738
                    // now we know the entry is in our unlinked linkage group                                          // 1739
                    var depGroupIndex = entry.groupIndex + (depEntry.declarative != entry.declarative);                // 1740
                                                                                                                       // 1741
                    // the group index of an entry is always the maximum                                               // 1742
                    if (depEntry.groupIndex === undefined || depEntry.groupIndex < depGroupIndex) {                    // 1743
                                                                                                                       // 1744
                        // if already in a group, remove from the old group                                            // 1745
                        if (depEntry.groupIndex !== undefined) {                                                       // 1746
                            groups[depEntry.groupIndex].splice(indexOf.call(groups[depEntry.groupIndex], depEntry), 1);
                                                                                                                       // 1748
                            // if the old group is empty, then we have a mixed depndency cycle                         // 1749
                            if (groups[depEntry.groupIndex].length == 0)                                               // 1750
                                throw new TypeError("Mixed dependency cycle detected");                                // 1751
                        }                                                                                              // 1752
                                                                                                                       // 1753
                        depEntry.groupIndex = depGroupIndex;                                                           // 1754
                    }                                                                                                  // 1755
                                                                                                                       // 1756
                    buildGroups(depEntry, loader, groups);                                                             // 1757
                }                                                                                                      // 1758
            }                                                                                                          // 1759
                                                                                                                       // 1760
            function link(name, loader) {                                                                              // 1761
                var startEntry = loader.defined[name];                                                                 // 1762
                                                                                                                       // 1763
                // skip if already linked                                                                              // 1764
                if (startEntry.module)                                                                                 // 1765
                    return;                                                                                            // 1766
                                                                                                                       // 1767
                startEntry.groupIndex = 0;                                                                             // 1768
                                                                                                                       // 1769
                var groups = [];                                                                                       // 1770
                                                                                                                       // 1771
                buildGroups(startEntry, loader, groups);                                                               // 1772
                                                                                                                       // 1773
                var curGroupDeclarative = !!startEntry.declarative == groups.length % 2;                               // 1774
                for (var i = groups.length - 1; i >= 0; i--) {                                                         // 1775
                    var group = groups[i];                                                                             // 1776
                    for (var j = 0; j < group.length; j++) {                                                           // 1777
                        var entry = group[j];                                                                          // 1778
                                                                                                                       // 1779
                        // link each group                                                                             // 1780
                        if (curGroupDeclarative)                                                                       // 1781
                            linkDeclarativeModule(entry, loader);                                                      // 1782
                        else                                                                                           // 1783
                            linkDynamicModule(entry, loader);                                                          // 1784
                    }                                                                                                  // 1785
                    curGroupDeclarative = !curGroupDeclarative;                                                        // 1786
                }                                                                                                      // 1787
            }                                                                                                          // 1788
                                                                                                                       // 1789
            // module binding records                                                                                  // 1790
            function getOrCreateModuleRecord(name, moduleRecords) {                                                    // 1791
                return moduleRecords[name] || (moduleRecords[name] = {                                                 // 1792
                        name: name,                                                                                    // 1793
                        dependencies: [],                                                                              // 1794
                        exports: {}, // start from an empty module and extend                                          // 1795
                        importers: []                                                                                  // 1796
                    });                                                                                                // 1797
            }                                                                                                          // 1798
                                                                                                                       // 1799
            function linkDeclarativeModule(entry, loader) {                                                            // 1800
                // only link if already not already started linking (stops at circular)                                // 1801
                if (entry.module)                                                                                      // 1802
                    return;                                                                                            // 1803
                                                                                                                       // 1804
                var moduleRecords = loader._loader.moduleRecords;                                                      // 1805
                var module = entry.module = getOrCreateModuleRecord(entry.name, moduleRecords);                        // 1806
                var exports = entry.module.exports;                                                                    // 1807
                                                                                                                       // 1808
                var declaration = entry.declare.call(__global, function(name, value) {                                 // 1809
                    module.locked = true;                                                                              // 1810
                                                                                                                       // 1811
                    if (typeof name == 'object') {                                                                     // 1812
                        for (var p in name)                                                                            // 1813
                            exports[p] = name[p];                                                                      // 1814
                    }                                                                                                  // 1815
                    else {                                                                                             // 1816
                        exports[name] = value;                                                                         // 1817
                    }                                                                                                  // 1818
                                                                                                                       // 1819
                    for (var i = 0, l = module.importers.length; i < l; i++) {                                         // 1820
                        var importerModule = module.importers[i];                                                      // 1821
                        if (!importerModule.locked) {                                                                  // 1822
                            var importerIndex = indexOf.call(importerModule.dependencies, module);                     // 1823
                            importerModule.setters[importerIndex](exports);                                            // 1824
                        }                                                                                              // 1825
                    }                                                                                                  // 1826
                                                                                                                       // 1827
                    module.locked = false;                                                                             // 1828
                    return value;                                                                                      // 1829
                });                                                                                                    // 1830
                                                                                                                       // 1831
                module.setters = declaration.setters;                                                                  // 1832
                module.execute = declaration.execute;                                                                  // 1833
                                                                                                                       // 1834
                if (!module.setters || !module.execute) {                                                              // 1835
                    throw new TypeError('Invalid System.register form for ' + entry.name);                             // 1836
                }                                                                                                      // 1837
                                                                                                                       // 1838
                // now link all the module dependencies                                                                // 1839
                for (var i = 0, l = entry.normalizedDeps.length; i < l; i++) {                                         // 1840
                    var depName = entry.normalizedDeps[i];                                                             // 1841
                    var depEntry = loader.defined[depName];                                                            // 1842
                    var depModule = moduleRecords[depName];                                                            // 1843
                                                                                                                       // 1844
                    // work out how to set depExports based on scenarios...                                            // 1845
                    var depExports;                                                                                    // 1846
                                                                                                                       // 1847
                    if (depModule) {                                                                                   // 1848
                        depExports = depModule.exports;                                                                // 1849
                    }                                                                                                  // 1850
                    // dynamic, already linked in our registry                                                         // 1851
                    else if (depEntry && !depEntry.declarative) {                                                      // 1852
                        depExports = depEntry.esModule;                                                                // 1853
                    }                                                                                                  // 1854
                    // in the loader registry                                                                          // 1855
                    else if (!depEntry) {                                                                              // 1856
                        depExports = loader.get(depName);                                                              // 1857
                    }                                                                                                  // 1858
                    // we have an entry -> link                                                                        // 1859
                    else {                                                                                             // 1860
                        linkDeclarativeModule(depEntry, loader);                                                       // 1861
                        depModule = depEntry.module;                                                                   // 1862
                        depExports = depModule.exports;                                                                // 1863
                    }                                                                                                  // 1864
                                                                                                                       // 1865
                    // only declarative modules have dynamic bindings                                                  // 1866
                    if (depModule && depModule.importers) {                                                            // 1867
                        depModule.importers.push(module);                                                              // 1868
                        module.dependencies.push(depModule);                                                           // 1869
                    }                                                                                                  // 1870
                    else {                                                                                             // 1871
                        module.dependencies.push(null);                                                                // 1872
                    }                                                                                                  // 1873
                                                                                                                       // 1874
                    // run the setter for this dependency                                                              // 1875
                    if (module.setters[i])                                                                             // 1876
                        module.setters[i](depExports);                                                                 // 1877
                }                                                                                                      // 1878
            }                                                                                                          // 1879
                                                                                                                       // 1880
            // An analog to loader.get covering execution of all three layers (real declarative, simulated declarative, simulated dynamic)
            function getModule(name, loader) {                                                                         // 1882
                var exports;                                                                                           // 1883
                var entry = loader.defined[name];                                                                      // 1884
                                                                                                                       // 1885
                if (!entry) {                                                                                          // 1886
                    exports = loader.get(name);                                                                        // 1887
                    if (!exports)                                                                                      // 1888
                        throw new Error('Unable to load dependency ' + name + '.');                                    // 1889
                }                                                                                                      // 1890
                                                                                                                       // 1891
                else {                                                                                                 // 1892
                    if (entry.declarative)                                                                             // 1893
                        ensureEvaluated(name, [], loader);                                                             // 1894
                                                                                                                       // 1895
                    else if (!entry.evaluated)                                                                         // 1896
                        linkDynamicModule(entry, loader);                                                              // 1897
                                                                                                                       // 1898
                    exports = entry.module.exports;                                                                    // 1899
                }                                                                                                      // 1900
                                                                                                                       // 1901
                if ((!entry || entry.declarative) && exports && exports.__useDefault)                                  // 1902
                    return exports['default'];                                                                         // 1903
                                                                                                                       // 1904
                return exports;                                                                                        // 1905
            }                                                                                                          // 1906
                                                                                                                       // 1907
            function linkDynamicModule(entry, loader) {                                                                // 1908
                if (entry.module)                                                                                      // 1909
                    return;                                                                                            // 1910
                                                                                                                       // 1911
                var exports = {};                                                                                      // 1912
                                                                                                                       // 1913
                var module = entry.module = { exports: exports, id: entry.name };                                      // 1914
                                                                                                                       // 1915
                // AMD requires execute the tree first                                                                 // 1916
                if (!entry.executingRequire) {                                                                         // 1917
                    for (var i = 0, l = entry.normalizedDeps.length; i < l; i++) {                                     // 1918
                        var depName = entry.normalizedDeps[i];                                                         // 1919
                        // we know we only need to link dynamic due to linking algorithm                               // 1920
                        var depEntry = loader.defined[depName];                                                        // 1921
                        if (depEntry)                                                                                  // 1922
                            linkDynamicModule(depEntry, loader);                                                       // 1923
                    }                                                                                                  // 1924
                }                                                                                                      // 1925
                                                                                                                       // 1926
                // now execute                                                                                         // 1927
                entry.evaluated = true;                                                                                // 1928
                var output = entry.execute.call(__global, function(name) {                                             // 1929
                    for (var i = 0, l = entry.deps.length; i < l; i++) {                                               // 1930
                        if (entry.deps[i] != name)                                                                     // 1931
                            continue;                                                                                  // 1932
                        return getModule(entry.normalizedDeps[i], loader);                                             // 1933
                    }                                                                                                  // 1934
                    throw new TypeError('Module ' + name + ' not declared as a dependency.');                          // 1935
                }, exports, module);                                                                                   // 1936
                                                                                                                       // 1937
                if (output)                                                                                            // 1938
                    module.exports = output;                                                                           // 1939
                                                                                                                       // 1940
                // create the esModule object, which allows ES6 named imports of dynamics                              // 1941
                exports = module.exports;                                                                              // 1942
                                                                                                                       // 1943
                if (exports && exports.__esModule) {                                                                   // 1944
                    entry.esModule = exports;                                                                          // 1945
                }                                                                                                      // 1946
                else {                                                                                                 // 1947
                    var hasOwnProperty = exports && exports.hasOwnProperty;                                            // 1948
                    entry.esModule = {};                                                                               // 1949
                    for (var p in exports) {                                                                           // 1950
                        if (!hasOwnProperty || exports.hasOwnProperty(p))                                              // 1951
                            entry.esModule[p] = exports[p];                                                            // 1952
                    }                                                                                                  // 1953
                    entry.esModule['default'] = exports;                                                               // 1954
                    defineProperty(entry.esModule, '__useDefault', {                                                   // 1955
                        value: true                                                                                    // 1956
                    });                                                                                                // 1957
                }                                                                                                      // 1958
            }                                                                                                          // 1959
                                                                                                                       // 1960
            /*                                                                                                         // 1961
             * Given a module, and the list of modules for this current branch,                                        // 1962
             *  ensure that each of the dependencies of this module is evaluated                                       // 1963
             *  (unless one is a circular dependency already in the list of seen                                       // 1964
             *  modules, in which case we execute it)                                                                  // 1965
             *                                                                                                         // 1966
             * Then we evaluate the module itself depth-first left to right                                            // 1967
             * execution to match ES6 modules                                                                          // 1968
             */                                                                                                        // 1969
            function ensureEvaluated(moduleName, seen, loader) {                                                       // 1970
                var entry = loader.defined[moduleName];                                                                // 1971
                                                                                                                       // 1972
                // if already seen, that means it's an already-evaluated non circular dependency                       // 1973
                if (!entry || entry.evaluated || !entry.declarative)                                                   // 1974
                    return;                                                                                            // 1975
                                                                                                                       // 1976
                // this only applies to declarative modules which late-execute                                         // 1977
                                                                                                                       // 1978
                seen.push(moduleName);                                                                                 // 1979
                                                                                                                       // 1980
                for (var i = 0, l = entry.normalizedDeps.length; i < l; i++) {                                         // 1981
                    var depName = entry.normalizedDeps[i];                                                             // 1982
                    if (indexOf.call(seen, depName) == -1) {                                                           // 1983
                        if (!loader.defined[depName])                                                                  // 1984
                            loader.get(depName);                                                                       // 1985
                        else                                                                                           // 1986
                            ensureEvaluated(depName, seen, loader);                                                    // 1987
                    }                                                                                                  // 1988
                }                                                                                                      // 1989
                                                                                                                       // 1990
                if (entry.evaluated)                                                                                   // 1991
                    return;                                                                                            // 1992
                                                                                                                       // 1993
                entry.evaluated = true;                                                                                // 1994
                entry.module.execute.call(__global);                                                                   // 1995
            }                                                                                                          // 1996
                                                                                                                       // 1997
            // override the delete method to also clear the register caches                                            // 1998
            hook('delete', function(del) {                                                                             // 1999
                return function(name) {                                                                                // 2000
                    delete this._loader.moduleRecords[name];                                                           // 2001
                    delete this.defined[name];                                                                         // 2002
                    return del.call(this, name);                                                                       // 2003
                };                                                                                                     // 2004
            });                                                                                                        // 2005
                                                                                                                       // 2006
            var registerRegEx = /^\s*(\/\*.*\*\/\s*|\/\/[^\n]*\s*)*System\.register(Dyanmic)?\s*\(/;                   // 2007
                                                                                                                       // 2008
            hook('fetch', function(fetch) {                                                                            // 2009
                return function(load) {                                                                                // 2010
                    if (this.defined[load.name]) {                                                                     // 2011
                        load.metadata.format = 'defined';                                                              // 2012
                        return '';                                                                                     // 2013
                    }                                                                                                  // 2014
                                                                                                                       // 2015
                    // this is the synchronous chain for onScriptLoad                                                  // 2016
                    anonRegister = null;                                                                               // 2017
                    calledRegister = false;                                                                            // 2018
                                                                                                                       // 2019
                    if (load.metadata.format == 'register')                                                            // 2020
                        load.metadata.scriptLoad = true;                                                               // 2021
                                                                                                                       // 2022
                    // NB remove when "deps " is deprecated                                                            // 2023
                    load.metadata.deps = load.metadata.deps || [];                                                     // 2024
                                                                                                                       // 2025
                    return fetch.call(this, load);                                                                     // 2026
                };                                                                                                     // 2027
            });                                                                                                        // 2028
                                                                                                                       // 2029
            hook('translate', function(translate) {                                                                    // 2030
                // we run the meta detection here (register is after meta)                                             // 2031
                return function(load) {                                                                                // 2032
                    return Promise.resolve(translate.call(this, load)).then(function(source) {                         // 2033
                                                                                                                       // 2034
                        if (typeof load.metadata.deps === 'string')                                                    // 2035
                            load.metadata.deps = load.metadata.deps.split(',');                                        // 2036
                        load.metadata.deps = load.metadata.deps || [];                                                 // 2037
                                                                                                                       // 2038
                        // run detection for register format                                                           // 2039
                        if (load.metadata.format == 'register' || !load.metadata.format && load.source.match(registerRegEx))
                            load.metadata.format = 'register';                                                         // 2041
                        return source;                                                                                 // 2042
                    });                                                                                                // 2043
                };                                                                                                     // 2044
            });                                                                                                        // 2045
                                                                                                                       // 2046
            hook('instantiate', function(instantiate) {                                                                // 2047
                return function(load) {                                                                                // 2048
                    var loader = this;                                                                                 // 2049
                                                                                                                       // 2050
                    var entry;                                                                                         // 2051
                                                                                                                       // 2052
                    // first we check if this module has already been defined in the registry                          // 2053
                    if (loader.defined[load.name]) {                                                                   // 2054
                        entry = loader.defined[load.name];                                                             // 2055
                        entry.deps = entry.deps.concat(load.metadata.deps);                                            // 2056
                    }                                                                                                  // 2057
                                                                                                                       // 2058
                    // picked up already by a script injection                                                         // 2059
                    else if (load.metadata.entry)                                                                      // 2060
                        entry = load.metadata.entry;                                                                   // 2061
                                                                                                                       // 2062
                    // otherwise check if it is dynamic                                                                // 2063
                    else if (load.metadata.execute) {                                                                  // 2064
                        entry = {                                                                                      // 2065
                            declarative: false,                                                                        // 2066
                            deps: load.metadata.deps || [],                                                            // 2067
                            execute: load.metadata.execute,                                                            // 2068
                            executingRequire: load.metadata.executingRequire // NodeJS-style requires or not           // 2069
                        };                                                                                             // 2070
                    }                                                                                                  // 2071
                                                                                                                       // 2072
                    // Contains System.register calls                                                                  // 2073
                    else if (load.metadata.format == 'register' || load.metadata.format == 'esm' || load.metadata.format == 'es6') {
                        anonRegister = null;                                                                           // 2075
                        calledRegister = false;                                                                        // 2076
                                                                                                                       // 2077
                        __exec.call(loader, load);                                                                     // 2078
                                                                                                                       // 2079
                        if (anonRegister)                                                                              // 2080
                            entry = anonRegister;                                                                      // 2081
                        else                                                                                           // 2082
                            load.metadata.bundle = true;                                                               // 2083
                                                                                                                       // 2084
                        if (!entry && loader.defined[load.name])                                                       // 2085
                            entry = loader.defined[load.name];                                                         // 2086
                                                                                                                       // 2087
                        if (!calledRegister && !load.metadata.registered)                                              // 2088
                            throw new TypeError(load.name + ' detected as System.register but didn\'t execute.');      // 2089
                    }                                                                                                  // 2090
                                                                                                                       // 2091
                    // named bundles are just an empty module                                                          // 2092
                    if (!entry)                                                                                        // 2093
                        entry = {                                                                                      // 2094
                            declarative: false,                                                                        // 2095
                            deps: load.metadata.deps,                                                                  // 2096
                            execute: function() {                                                                      // 2097
                                return loader.newModule({});                                                           // 2098
                            }                                                                                          // 2099
                        };                                                                                             // 2100
                                                                                                                       // 2101
                    // place this module onto defined for circular references                                          // 2102
                    loader.defined[load.name] = entry;                                                                 // 2103
                                                                                                                       // 2104
                    entry.deps = dedupe(entry.deps);                                                                   // 2105
                    entry.name = load.name;                                                                            // 2106
                                                                                                                       // 2107
                    // first, normalize all dependencies                                                               // 2108
                    var normalizePromises = [];                                                                        // 2109
                    for (var i = 0, l = entry.deps.length; i < l; i++)                                                 // 2110
                        normalizePromises.push(Promise.resolve(loader.normalize(entry.deps[i], load.name)));           // 2111
                                                                                                                       // 2112
                    return Promise.all(normalizePromises).then(function(normalizedDeps) {                              // 2113
                                                                                                                       // 2114
                        entry.normalizedDeps = normalizedDeps;                                                         // 2115
                                                                                                                       // 2116
                        return {                                                                                       // 2117
                            deps: entry.deps,                                                                          // 2118
                            execute: function() {                                                                      // 2119
                                // recursively ensure that the module and all its                                      // 2120
                                // dependencies are linked (with dependency group handling)                            // 2121
                                link(load.name, loader);                                                               // 2122
                                                                                                                       // 2123
                                // now handle dependency execution in correct order                                    // 2124
                                ensureEvaluated(load.name, [], loader);                                                // 2125
                                                                                                                       // 2126
                                // remove from the registry                                                            // 2127
                                loader.defined[load.name] = undefined;                                                 // 2128
                                                                                                                       // 2129
                                // return the defined module object                                                    // 2130
                                return loader.newModule(entry.declarative ? entry.module.exports : entry.esModule);    // 2131
                            }                                                                                          // 2132
                        };                                                                                             // 2133
                    });                                                                                                // 2134
                };                                                                                                     // 2135
            });                                                                                                        // 2136
        })();                                                                                                          // 2137
        /*                                                                                                             // 2138
         * Extension to detect ES6 and auto-load Traceur or Babel for processing                                       // 2139
         */                                                                                                            // 2140
        (function() {                                                                                                  // 2141
            // good enough ES6 module detection regex - format detections not designed to be accurate, but to handle the 99% use case
            var esmRegEx = /(^\s*|[}\);\n]\s*)(import\s+(['"]|(\*\s+as\s+)?[^"'\(\)\n;]+\s+from\s+['"]|\{)|export\s+\*\s+from\s+["']|export\s+(\{|default|function|class|var|const|let|async\s+function))/;
                                                                                                                       // 2144
            var traceurRuntimeRegEx = /\$traceurRuntime\s*\./;                                                         // 2145
            var babelHelpersRegEx = /babelHelpers\s*\./;                                                               // 2146
                                                                                                                       // 2147
            hook('translate', function(translate) {                                                                    // 2148
                return function(load) {                                                                                // 2149
                    var loader = this;                                                                                 // 2150
                    return translate.call(loader, load)                                                                // 2151
                        .then(function(source) {                                                                       // 2152
                            // detect & transpile ES6                                                                  // 2153
                            if (load.metadata.format == 'esm' || load.metadata.format == 'es6' || !load.metadata.format && source.match(esmRegEx)) {
                                load.metadata.format = 'esm';                                                          // 2155
                                                                                                                       // 2156
                                // setting _loadedTranspiler = false tells the next block to                           // 2157
                                // do checks for setting transpiler metadata                                           // 2158
                                loader._loadedTranspiler = loader._loadedTranspiler || false;                          // 2159
                                if (loader.pluginLoader)                                                               // 2160
                                    loader.pluginLoader._loadedTranspiler = loader._loadedTranspiler || false;         // 2161
                                                                                                                       // 2162
                                // defined in es6-module-loader/src/transpile.js                                       // 2163
                                return transpile.call(loader, load)                                                    // 2164
                                    .then(function(source) {                                                           // 2165
                                        // clear sourceMap as transpiler embeds it                                     // 2166
                                        load.metadata.sourceMap = undefined;                                           // 2167
                                        return source;                                                                 // 2168
                                    });                                                                                // 2169
                            }                                                                                          // 2170
                                                                                                                       // 2171
                            // load the transpiler correctly                                                           // 2172
                            if (loader._loadedTranspiler === false && load.name == loader.normalizeSync(loader.transpiler)) {
                                // always load transpiler as a global                                                  // 2174
                                if (source.length > 100) {                                                             // 2175
                                    load.metadata.format = load.metadata.format || 'global';                           // 2176
                                                                                                                       // 2177
                                    if (loader.transpiler === 'traceur')                                               // 2178
                                        load.metadata.exports = 'traceur';                                             // 2179
                                    if (loader.transpiler === 'typescript')                                            // 2180
                                        load.metadata.exports = 'ts';                                                  // 2181
                                }                                                                                      // 2182
                                                                                                                       // 2183
                                loader._loadedTranspiler = true;                                                       // 2184
                            }                                                                                          // 2185
                                                                                                                       // 2186
                            // load the transpiler runtime correctly                                                   // 2187
                            if (loader._loadedTranspilerRuntime === false) {                                           // 2188
                                if (load.name == loader.normalizeSync('traceur-runtime')                               // 2189
                                    || load.name == loader.normalizeSync('babel/external-helpers*')) {                 // 2190
                                    if (source.length > 100)                                                           // 2191
                                        load.metadata.format = load.metadata.format || 'global';                       // 2192
                                                                                                                       // 2193
                                    loader._loadedTranspilerRuntime = true;                                            // 2194
                                }                                                                                      // 2195
                            }                                                                                          // 2196
                                                                                                                       // 2197
                            // detect transpiler runtime usage to load runtimes                                        // 2198
                            if (load.metadata.format == 'register' && loader._loadedTranspilerRuntime !== true) {      // 2199
                                if (!__global.$traceurRuntime && load.source.match(traceurRuntimeRegEx)) {             // 2200
                                    loader._loadedTranspilerRuntime = loader._loadedTranspilerRuntime || false;        // 2201
                                    return loader['import']('traceur-runtime').then(function() {                       // 2202
                                        return source;                                                                 // 2203
                                    });                                                                                // 2204
                                }                                                                                      // 2205
                                if (!__global.babelHelpers && load.source.match(babelHelpersRegEx)) {                  // 2206
                                    loader._loadedTranspilerRuntime = loader._loadedTranspilerRuntime || false;        // 2207
                                    return loader['import']('babel/external-helpers').then(function() {                // 2208
                                        return source;                                                                 // 2209
                                    });                                                                                // 2210
                                }                                                                                      // 2211
                            }                                                                                          // 2212
                                                                                                                       // 2213
                            return source;                                                                             // 2214
                        });                                                                                            // 2215
                };                                                                                                     // 2216
            });                                                                                                        // 2217
                                                                                                                       // 2218
        })();                                                                                                          // 2219
        /*                                                                                                             // 2220
         SystemJS Global Format                                                                                        // 2221
                                                                                                                       // 2222
         Supports                                                                                                      // 2223
         metadata.deps                                                                                                 // 2224
         metadata.globals                                                                                              // 2225
         metadata.exports                                                                                              // 2226
                                                                                                                       // 2227
         Without metadata.exports, detects writes to the global object.                                                // 2228
         */                                                                                                            // 2229
        var __globalName = typeof self != 'undefined' ? 'self' : 'global';                                             // 2230
                                                                                                                       // 2231
        hook('onScriptLoad', function(onScriptLoad) {                                                                  // 2232
            return function(load) {                                                                                    // 2233
                if (load.metadata.format == 'global') {                                                                // 2234
                    load.metadata.registered = true;                                                                   // 2235
                    var globalValue = readMemberExpression(load.metadata.exports, __global);                           // 2236
                    load.metadata.execute = function() {                                                               // 2237
                        return globalValue;                                                                            // 2238
                    }                                                                                                  // 2239
                }                                                                                                      // 2240
                return onScriptLoad.call(this, load);                                                                  // 2241
            };                                                                                                         // 2242
        });                                                                                                            // 2243
                                                                                                                       // 2244
        hook('fetch', function(fetch) {                                                                                // 2245
            return function(load) {                                                                                    // 2246
                if (load.metadata.exports)                                                                             // 2247
                    load.metadata.format = 'global';                                                                   // 2248
                                                                                                                       // 2249
                // A global with exports, no globals and no deps                                                       // 2250
                // can be loaded via a script tag                                                                      // 2251
                if (load.metadata.format == 'global'                                                                   // 2252
                    && load.metadata.exports && !load.metadata.globals                                                 // 2253
                    && (!load.metadata.deps || load.metadata.deps.length == 0))                                        // 2254
                    load.metadata.scriptLoad = true;                                                                   // 2255
                                                                                                                       // 2256
                return fetch.call(this, load);                                                                         // 2257
            };                                                                                                         // 2258
        });                                                                                                            // 2259
                                                                                                                       // 2260
// ideally we could support script loading for globals, but the issue with that is that                                // 2261
// we can't do it with AMD support side-by-side since AMD support means defining the                                   // 2262
// global define, and global support means not definining it, yet we don't have any hook                               // 2263
// into the "pre-execution" phase of a script tag being loaded to handle both cases                                    // 2264
                                                                                                                       // 2265
                                                                                                                       // 2266
        hook('instantiate', function(instantiate) {                                                                    // 2267
            return function(load) {                                                                                    // 2268
                var loader = this;                                                                                     // 2269
                                                                                                                       // 2270
                if (!load.metadata.format)                                                                             // 2271
                    load.metadata.format = 'global';                                                                   // 2272
                                                                                                                       // 2273
                // add globals as dependencies                                                                         // 2274
                if (load.metadata.globals)                                                                             // 2275
                    for (var g in load.metadata.globals)                                                               // 2276
                        load.metadata.deps.push(load.metadata.globals[g]);                                             // 2277
                                                                                                                       // 2278
                // global is a fallback module format                                                                  // 2279
                if (load.metadata.format == 'global' && !load.metadata.registered) {                                   // 2280
                    load.metadata.execute = function(require, exports, module) {                                       // 2281
                                                                                                                       // 2282
                        var globals;                                                                                   // 2283
                        if (load.metadata.globals) {                                                                   // 2284
                            globals = {};                                                                              // 2285
                            for (var g in load.metadata.globals)                                                       // 2286
                                globals[g] = require(load.metadata.globals[g]);                                        // 2287
                        }                                                                                              // 2288
                                                                                                                       // 2289
                        var exportName = load.metadata.exports;                                                        // 2290
                        var retrieveGlobal = loader.get('@@global-helpers').prepareGlobal(module.id, exportName, globals);
                                                                                                                       // 2292
                        if (exportName)                                                                                // 2293
                            load.source += '\n' + __globalName + '["' + exportName + '"] = ' + exportName + ';';       // 2294
                                                                                                                       // 2295
                        // disable module detection                                                                    // 2296
                        var define = __global.define;                                                                  // 2297
                        var cRequire = __global.require;                                                               // 2298
                                                                                                                       // 2299
                        __global.define = undefined;                                                                   // 2300
                        __global.module = undefined;                                                                   // 2301
                        __global.exports = undefined;                                                                  // 2302
                                                                                                                       // 2303
                        __exec.call(loader, load);                                                                     // 2304
                                                                                                                       // 2305
                        __global.require = cRequire;                                                                   // 2306
                        __global.define = define;                                                                      // 2307
                                                                                                                       // 2308
                        return retrieveGlobal();                                                                       // 2309
                    }                                                                                                  // 2310
                }                                                                                                      // 2311
                return instantiate.call(this, load);                                                                   // 2312
            };                                                                                                         // 2313
        });                                                                                                            // 2314
        hookConstructor(function(constructor) {                                                                        // 2315
            return function() {                                                                                        // 2316
                var loader = this;                                                                                     // 2317
                constructor.call(loader);                                                                              // 2318
                                                                                                                       // 2319
                var hasOwnProperty = Object.prototype.hasOwnProperty;                                                  // 2320
                                                                                                                       // 2321
                // bare minimum ignores for IE8                                                                        // 2322
                var ignoredGlobalProps = ['_g', 'sessionStorage', 'localStorage', 'clipboardData', 'frames', 'external'];
                                                                                                                       // 2324
                var globalSnapshot;                                                                                    // 2325
                                                                                                                       // 2326
                function forEachGlobal(callback) {                                                                     // 2327
                    if (Object.keys)                                                                                   // 2328
                        Object.keys(__global).forEach(callback);                                                       // 2329
                    else                                                                                               // 2330
                        for (var g in __global) {                                                                      // 2331
                            if (!hasOwnProperty.call(__global, g))                                                     // 2332
                                continue;                                                                              // 2333
                            callback(g);                                                                               // 2334
                        }                                                                                              // 2335
                }                                                                                                      // 2336
                                                                                                                       // 2337
                function forEachGlobalValue(callback) {                                                                // 2338
                    forEachGlobal(function(globalName) {                                                               // 2339
                        if (indexOf.call(ignoredGlobalProps, globalName) != -1)                                        // 2340
                            return;                                                                                    // 2341
                        try {                                                                                          // 2342
                            var value = __global[globalName];                                                          // 2343
                        }                                                                                              // 2344
                        catch (e) {                                                                                    // 2345
                            ignoredGlobalProps.push(globalName);                                                       // 2346
                        }                                                                                              // 2347
                        callback(globalName, value);                                                                   // 2348
                    });                                                                                                // 2349
                }                                                                                                      // 2350
                                                                                                                       // 2351
                loader.set('@@global-helpers', loader.newModule({                                                      // 2352
                    prepareGlobal: function(moduleName, exportName, globals) {                                         // 2353
                        // set globals                                                                                 // 2354
                        var oldGlobals;                                                                                // 2355
                        if (globals) {                                                                                 // 2356
                            oldGlobals = {};                                                                           // 2357
                            for (var g in globals) {                                                                   // 2358
                                oldGlobals[g] = globals[g];                                                            // 2359
                                __global[g] = globals[g];                                                              // 2360
                            }                                                                                          // 2361
                        }                                                                                              // 2362
                                                                                                                       // 2363
                        // store a complete copy of the global object in order to detect changes                       // 2364
                        if (!exportName) {                                                                             // 2365
                            globalSnapshot = {};                                                                       // 2366
                                                                                                                       // 2367
                            forEachGlobalValue(function(name, value) {                                                 // 2368
                                globalSnapshot[name] = value;                                                          // 2369
                            });                                                                                        // 2370
                        }                                                                                              // 2371
                                                                                                                       // 2372
                        // return function to retrieve global                                                          // 2373
                        return function() {                                                                            // 2374
                            var globalValue;                                                                           // 2375
                                                                                                                       // 2376
                            if (exportName) {                                                                          // 2377
                                globalValue = readMemberExpression(exportName, __global);                              // 2378
                            }                                                                                          // 2379
                            else {                                                                                     // 2380
                                var singleGlobal;                                                                      // 2381
                                var multipleExports;                                                                   // 2382
                                var exports = {};                                                                      // 2383
                                                                                                                       // 2384
                                forEachGlobalValue(function(name, value) {                                             // 2385
                                    if (globalSnapshot[name] === value)                                                // 2386
                                        return;                                                                        // 2387
                                    if (typeof value == 'undefined')                                                   // 2388
                                        return;                                                                        // 2389
                                    exports[name] = value;                                                             // 2390
                                                                                                                       // 2391
                                    if (typeof singleGlobal != 'undefined') {                                          // 2392
                                        if (!multipleExports && singleGlobal !== value)                                // 2393
                                            multipleExports = true;                                                    // 2394
                                    }                                                                                  // 2395
                                    else {                                                                             // 2396
                                        singleGlobal = value;                                                          // 2397
                                    }                                                                                  // 2398
                                });                                                                                    // 2399
                                globalValue = multipleExports ? exports : singleGlobal;                                // 2400
                            }                                                                                          // 2401
                                                                                                                       // 2402
                            // revert globals                                                                          // 2403
                            if (oldGlobals) {                                                                          // 2404
                                for (var g in oldGlobals)                                                              // 2405
                                    __global[g] = oldGlobals[g];                                                       // 2406
                            }                                                                                          // 2407
                                                                                                                       // 2408
                            return globalValue;                                                                        // 2409
                        };                                                                                             // 2410
                    }                                                                                                  // 2411
                }));                                                                                                   // 2412
            };                                                                                                         // 2413
        });/*                                                                                                          // 2414
         SystemJS CommonJS Format                                                                                      // 2415
         */                                                                                                            // 2416
        (function() {                                                                                                  // 2417
            // CJS Module Format                                                                                       // 2418
            // require('...') || exports[''] = ... || exports.asd = ... || module.exports = ...                        // 2419
            var cjsExportsRegEx = /(?:^\uFEFF?|[^$_a-zA-Z\xA0-\uFFFF.]|module\.)exports\s*(\[['"]|\.)|(?:^\uFEFF?|[^$_a-zA-Z\xA0-\uFFFF.])module\.exports\s*[=,]/;
            // RegEx adjusted from https://github.com/jbrantly/yabble/blob/master/lib/yabble.js#L339                   // 2421
            var cjsRequireRegEx = /(?:^\uFEFF?|[^$_a-zA-Z\xA0-\uFFFF."'])require\s*\(\s*("[^"\\]*(?:\\.[^"\\]*)*"|'[^'\\]*(?:\\.[^'\\]*)*')\s*\)/g;
            var commentRegEx = /(\/\*([\s\S]*?)\*\/|([^:]|^)\/\/(.*)$)/mg;                                             // 2423
                                                                                                                       // 2424
            function getCJSDeps(source) {                                                                              // 2425
                cjsRequireRegEx.lastIndex = 0;                                                                         // 2426
                                                                                                                       // 2427
                var deps = [];                                                                                         // 2428
                                                                                                                       // 2429
                // remove comments from the source first, if not minified                                              // 2430
                if (source.length / source.split('\n').length < 200)                                                   // 2431
                    source = source.replace(commentRegEx, '');                                                         // 2432
                                                                                                                       // 2433
                var match;                                                                                             // 2434
                                                                                                                       // 2435
                while (match = cjsRequireRegEx.exec(source))                                                           // 2436
                    deps.push(match[1].substr(1, match[1].length - 2));                                                // 2437
                                                                                                                       // 2438
                return deps;                                                                                           // 2439
            }                                                                                                          // 2440
                                                                                                                       // 2441
            if (typeof window != 'undefined' && typeof document != 'undefined' && window.location)                     // 2442
                var windowOrigin = location.protocol + '//' + location.hostname + (location.port ? ':' + location.port : '');
                                                                                                                       // 2444
            hookConstructor(function(constructor) {                                                                    // 2445
                return function() {                                                                                    // 2446
                    constructor.call(this);                                                                            // 2447
                                                                                                                       // 2448
                    // include the node require since we're overriding it                                              // 2449
                    if (typeof require != 'undefined' && require.resolve && typeof process != 'undefined')             // 2450
                        this._nodeRequire = require;                                                                   // 2451
                };                                                                                                     // 2452
            });                                                                                                        // 2453
                                                                                                                       // 2454
            hook('instantiate', function(instantiate) {                                                                // 2455
                return function(load) {                                                                                // 2456
                    var loader = this;                                                                                 // 2457
                    if (!load.metadata.format) {                                                                       // 2458
                        cjsExportsRegEx.lastIndex = 0;                                                                 // 2459
                        cjsRequireRegEx.lastIndex = 0;                                                                 // 2460
                        if (cjsRequireRegEx.exec(load.source) || cjsExportsRegEx.exec(load.source))                    // 2461
                            load.metadata.format = 'cjs';                                                              // 2462
                    }                                                                                                  // 2463
                                                                                                                       // 2464
                    if (load.metadata.format == 'cjs') {                                                               // 2465
                        var metaDeps = load.metadata.deps || [];                                                       // 2466
                        load.metadata.deps = metaDeps.concat(getCJSDeps(load.source));                                 // 2467
                                                                                                                       // 2468
                        load.metadata.executingRequire = true;                                                         // 2469
                                                                                                                       // 2470
                        load.metadata.execute = function(require, exports, module) {                                   // 2471
                            // ensure meta deps execute first                                                          // 2472
                            for (var i = 0; i < metaDeps.length; i++)                                                  // 2473
                                require(metaDeps[i]);                                                                  // 2474
                            var address = load.address || '';                                                          // 2475
                                                                                                                       // 2476
                            var dirname = address.split('/');                                                          // 2477
                            dirname.pop();                                                                             // 2478
                            dirname = dirname.join('/');                                                               // 2479
                                                                                                                       // 2480
                            if (windowOrigin && address.substr(0, windowOrigin.length) === windowOrigin) {             // 2481
                                address = address.substr(windowOrigin.length);                                         // 2482
                                dirname = dirname.substr(windowOrigin.length);                                         // 2483
                            }                                                                                          // 2484
                            else if (address.substr(0, 8) == 'file:///') {                                             // 2485
                                address = address.substr(7);                                                           // 2486
                                dirname = dirname.substr(7);                                                           // 2487
                                                                                                                       // 2488
                                // on windows remove leading '/'                                                       // 2489
                                if (isWindows) {                                                                       // 2490
                                    address = address.substr(1);                                                       // 2491
                                    dirname = dirname.substr(1);                                                       // 2492
                                }                                                                                      // 2493
                            }                                                                                          // 2494
                                                                                                                       // 2495
                            // disable AMD detection                                                                   // 2496
                            var define = __global.define;                                                              // 2497
                            __global.define = undefined;                                                               // 2498
                                                                                                                       // 2499
                            __global.__cjsWrapper = {                                                                  // 2500
                                exports: exports,                                                                      // 2501
                                args: [require, exports, module, address, dirname, __global]                           // 2502
                            };                                                                                         // 2503
                                                                                                                       // 2504
                            load.source = "(function(require, exports, module, __filename, __dirname, global) {"       // 2505
                                + load.source + "\n}).apply(__cjsWrapper.exports, __cjsWrapper.args);";                // 2506
                                                                                                                       // 2507
                            __exec.call(loader, load);                                                                 // 2508
                                                                                                                       // 2509
                            __global.__cjsWrapper = undefined;                                                         // 2510
                            __global.define = define;                                                                  // 2511
                        };                                                                                             // 2512
                    }                                                                                                  // 2513
                                                                                                                       // 2514
                    return instantiate.call(loader, load);                                                             // 2515
                };                                                                                                     // 2516
            });                                                                                                        // 2517
        })();                                                                                                          // 2518
        /*                                                                                                             // 2519
         * AMD Helper function module                                                                                  // 2520
         * Separated into its own file as this is the part needed for full AMD support in SFX builds                   // 2521
         *                                                                                                             // 2522
         */                                                                                                            // 2523
        hookConstructor(function(constructor) {                                                                        // 2524
            return function() {                                                                                        // 2525
                var loader = this;                                                                                     // 2526
                constructor.call(this);                                                                                // 2527
                                                                                                                       // 2528
                var commentRegEx = /(\/\*([\s\S]*?)\*\/|([^:]|^)\/\/(.*)$)/mg;                                         // 2529
                var cjsRequirePre = "(?:^|[^$_a-zA-Z\\xA0-\\uFFFF.])";                                                 // 2530
                var cjsRequirePost = "\\s*\\(\\s*(\"([^\"]+)\"|'([^']+)')\\s*\\)";                                     // 2531
                var fnBracketRegEx = /\(([^\)]*)\)/;                                                                   // 2532
                var wsRegEx = /^\s+|\s+$/g;                                                                            // 2533
                                                                                                                       // 2534
                var requireRegExs = {};                                                                                // 2535
                                                                                                                       // 2536
                function getCJSDeps(source, requireIndex) {                                                            // 2537
                                                                                                                       // 2538
                    // remove comments                                                                                 // 2539
                    source = source.replace(commentRegEx, '');                                                         // 2540
                                                                                                                       // 2541
                    // determine the require alias                                                                     // 2542
                    var params = source.match(fnBracketRegEx);                                                         // 2543
                    var requireAlias = (params[1].split(',')[requireIndex] || 'require').replace(wsRegEx, '');         // 2544
                                                                                                                       // 2545
                    // find or generate the regex for this requireAlias                                                // 2546
                    var requireRegEx = requireRegExs[requireAlias] || (requireRegExs[requireAlias] = new RegExp(cjsRequirePre + requireAlias + cjsRequirePost, 'g'));
                                                                                                                       // 2548
                    requireRegEx.lastIndex = 0;                                                                        // 2549
                                                                                                                       // 2550
                    var deps = [];                                                                                     // 2551
                                                                                                                       // 2552
                    var match;                                                                                         // 2553
                    while (match = requireRegEx.exec(source))                                                          // 2554
                        deps.push(match[2] || match[3]);                                                               // 2555
                                                                                                                       // 2556
                    return deps;                                                                                       // 2557
                }                                                                                                      // 2558
                                                                                                                       // 2559
                /*                                                                                                     // 2560
                 AMD-compatible require                                                                                // 2561
                 To copy RequireJS, set window.require = window.requirejs = loader.amdRequire                          // 2562
                 */                                                                                                    // 2563
                function require(names, callback, errback, referer) {                                                  // 2564
                    // in amd, first arg can be a config object... we just ignore                                      // 2565
                    if (typeof names == 'object' && !(names instanceof Array))                                         // 2566
                        return require.apply(null, Array.prototype.splice.call(arguments, 1, arguments.length - 1));   // 2567
                                                                                                                       // 2568
                    // amd require                                                                                     // 2569
                    if (typeof names == 'string' && typeof callback == 'function')                                     // 2570
                        names = [names];                                                                               // 2571
                    if (names instanceof Array) {                                                                      // 2572
                        var dynamicRequires = [];                                                                      // 2573
                        for (var i = 0; i < names.length; i++)                                                         // 2574
                            dynamicRequires.push(loader['import'](names[i], referer));                                 // 2575
                        Promise.all(dynamicRequires).then(function(modules) {                                          // 2576
                            if (callback)                                                                              // 2577
                                callback.apply(null, modules);                                                         // 2578
                        }, errback);                                                                                   // 2579
                    }                                                                                                  // 2580
                                                                                                                       // 2581
                    // commonjs require                                                                                // 2582
                    else if (typeof names == 'string') {                                                               // 2583
                        var module = loader.get(names);                                                                // 2584
                        return module.__useDefault ? module['default'] : module;                                       // 2585
                    }                                                                                                  // 2586
                                                                                                                       // 2587
                    else                                                                                               // 2588
                        throw new TypeError('Invalid require');                                                        // 2589
                };                                                                                                     // 2590
                                                                                                                       // 2591
                function define(name, deps, factory) {                                                                 // 2592
                    if (typeof name != 'string') {                                                                     // 2593
                        factory = deps;                                                                                // 2594
                        deps = name;                                                                                   // 2595
                        name = null;                                                                                   // 2596
                    }                                                                                                  // 2597
                    if (!(deps instanceof Array)) {                                                                    // 2598
                        factory = deps;                                                                                // 2599
                        deps = ['require', 'exports', 'module'].splice(0, factory.length);                             // 2600
                    }                                                                                                  // 2601
                                                                                                                       // 2602
                    if (typeof factory != 'function')                                                                  // 2603
                        factory = (function(factory) {                                                                 // 2604
                            return function() { return factory; }                                                      // 2605
                        })(factory);                                                                                   // 2606
                                                                                                                       // 2607
                    // in IE8, a trailing comma becomes a trailing undefined entry                                     // 2608
                    if (deps[deps.length - 1] === undefined)                                                           // 2609
                        deps.pop();                                                                                    // 2610
                                                                                                                       // 2611
                    // remove system dependencies                                                                      // 2612
                    var requireIndex, exportsIndex, moduleIndex;                                                       // 2613
                                                                                                                       // 2614
                    if ((requireIndex = indexOf.call(deps, 'require')) != -1) {                                        // 2615
                                                                                                                       // 2616
                        deps.splice(requireIndex, 1);                                                                  // 2617
                                                                                                                       // 2618
                        // only trace cjs requires for non-named                                                       // 2619
                        // named defines assume the trace has already been done                                        // 2620
                        if (!name)                                                                                     // 2621
                            deps = deps.concat(getCJSDeps(factory.toString(), requireIndex));                          // 2622
                    }                                                                                                  // 2623
                                                                                                                       // 2624
                    if ((exportsIndex = indexOf.call(deps, 'exports')) != -1)                                          // 2625
                        deps.splice(exportsIndex, 1);                                                                  // 2626
                                                                                                                       // 2627
                    if ((moduleIndex = indexOf.call(deps, 'module')) != -1)                                            // 2628
                        deps.splice(moduleIndex, 1);                                                                   // 2629
                                                                                                                       // 2630
                    var define = {                                                                                     // 2631
                        name: name,                                                                                    // 2632
                        deps: deps,                                                                                    // 2633
                        execute: function(req, exports, module) {                                                      // 2634
                                                                                                                       // 2635
                            var depValues = [];                                                                        // 2636
                            for (var i = 0; i < deps.length; i++)                                                      // 2637
                                depValues.push(req(deps[i]));                                                          // 2638
                                                                                                                       // 2639
                            module.uri = module.id;                                                                    // 2640
                                                                                                                       // 2641
                            module.config = function() {};                                                             // 2642
                                                                                                                       // 2643
                            // add back in system dependencies                                                         // 2644
                            if (moduleIndex != -1)                                                                     // 2645
                                depValues.splice(moduleIndex, 0, module);                                              // 2646
                                                                                                                       // 2647
                            if (exportsIndex != -1)                                                                    // 2648
                                depValues.splice(exportsIndex, 0, exports);                                            // 2649
                                                                                                                       // 2650
                            if (requireIndex != -1) {                                                                  // 2651
                                function contextualRequire(names, callback, errback) {                                 // 2652
                                    if (typeof names == 'string' && typeof callback != 'function')                     // 2653
                                        return req(names);                                                             // 2654
                                    return require.call(loader, names, callback, errback, module.id);                  // 2655
                                }                                                                                      // 2656
                                contextualRequire.toUrl = function(name) {                                             // 2657
                                    // normalize without defaultJSExtensions                                           // 2658
                                    var defaultJSExtension = loader.defaultJSExtensions && name.substr(name.length - 3, 3) != '.js';
                                    var url = loader.normalizeSync(name, module.id);                                   // 2660
                                    if (defaultJSExtension && url.substr(url.length - 3, 3) == '.js')                  // 2661
                                        url = url.substr(0, url.length - 3);                                           // 2662
                                    return url;                                                                        // 2663
                                };                                                                                     // 2664
                                depValues.splice(requireIndex, 0, contextualRequire);                                  // 2665
                            }                                                                                          // 2666
                                                                                                                       // 2667
                            // set global require to AMD require                                                       // 2668
                            var curRequire = __global.require;                                                         // 2669
                            __global.require = require;                                                                // 2670
                                                                                                                       // 2671
                            var output = factory.apply(exportsIndex == -1 ? __global : exports, depValues);            // 2672
                                                                                                                       // 2673
                            __global.require = curRequire;                                                             // 2674
                                                                                                                       // 2675
                            if (typeof output == 'undefined' && module)                                                // 2676
                                output = module.exports;                                                               // 2677
                                                                                                                       // 2678
                            if (typeof output != 'undefined')                                                          // 2679
                                return output;                                                                         // 2680
                        }                                                                                              // 2681
                    };                                                                                                 // 2682
                                                                                                                       // 2683
                    // anonymous define                                                                                // 2684
                    if (!name) {                                                                                       // 2685
                        // already defined anonymously -> throw                                                        // 2686
                        if (lastModule.anonDefine)                                                                     // 2687
                            throw new TypeError('Multiple defines for anonymous module');                              // 2688
                        lastModule.anonDefine = define;                                                                // 2689
                    }                                                                                                  // 2690
                    // named define                                                                                    // 2691
                    else {                                                                                             // 2692
                        // if it has no dependencies and we don't have any other                                       // 2693
                        // defines, then let this be an anonymous define                                               // 2694
                        // this is just to support single modules of the form:                                         // 2695
                        // define('jquery')                                                                            // 2696
                        // still loading anonymously                                                                   // 2697
                        // because it is done widely enough to be useful                                               // 2698
                        if (deps.length == 0 && !lastModule.anonDefine && !lastModule.isBundle) {                      // 2699
                            lastModule.anonDefine = define;                                                            // 2700
                        }                                                                                              // 2701
                        // otherwise its a bundle only                                                                 // 2702
                        else {                                                                                         // 2703
                            // if there is an anonDefine already (we thought it could have had a single named define)  // 2704
                            // then we define it now                                                                   // 2705
                            // this is to avoid defining named defines when they are actually anonymous                // 2706
                            if (lastModule.anonDefine && lastModule.anonDefine.name)                                   // 2707
                                loader.registerDynamic(lastModule.anonDefine.name, lastModule.anonDefine.deps, false, lastModule.anonDefine.execute);
                                                                                                                       // 2709
                            lastModule.anonDefine = null;                                                              // 2710
                        }                                                                                              // 2711
                                                                                                                       // 2712
                        // note this is now a bundle                                                                   // 2713
                        lastModule.isBundle = true;                                                                    // 2714
                                                                                                                       // 2715
                        // define the module through the register registry                                             // 2716
                        loader.registerDynamic(name, define.deps, false, define.execute);                              // 2717
                    }                                                                                                  // 2718
                }                                                                                                      // 2719
                define.amd = {};                                                                                       // 2720
                                                                                                                       // 2721
                // adds define as a global (potentially just temporarily)                                              // 2722
                function createDefine(loader) {                                                                        // 2723
                    lastModule.anonDefine = null;                                                                      // 2724
                    lastModule.isBundle = false;                                                                       // 2725
                                                                                                                       // 2726
                    // ensure no NodeJS environment detection                                                          // 2727
                    var oldModule = __global.module;                                                                   // 2728
                    var oldExports = __global.exports;                                                                 // 2729
                    var oldDefine = __global.define;                                                                   // 2730
                                                                                                                       // 2731
                    __global.module = undefined;                                                                       // 2732
                    __global.exports = undefined;                                                                      // 2733
                    __global.define = define;                                                                          // 2734
                                                                                                                       // 2735
                    return function() {                                                                                // 2736
                        __global.define = oldDefine;                                                                   // 2737
                        __global.module = oldModule;                                                                   // 2738
                        __global.exports = oldExports;                                                                 // 2739
                    };                                                                                                 // 2740
                }                                                                                                      // 2741
                                                                                                                       // 2742
                var lastModule = {                                                                                     // 2743
                    isBundle: false,                                                                                   // 2744
                    anonDefine: null                                                                                   // 2745
                };                                                                                                     // 2746
                                                                                                                       // 2747
                loader.set('@@amd-helpers', loader.newModule({                                                         // 2748
                    createDefine: createDefine,                                                                        // 2749
                    require: require,                                                                                  // 2750
                    define: define,                                                                                    // 2751
                    lastModule: lastModule                                                                             // 2752
                }));                                                                                                   // 2753
                loader.amdDefine = define;                                                                             // 2754
                loader.amdRequire = require;                                                                           // 2755
            };                                                                                                         // 2756
        });/*                                                                                                          // 2757
         SystemJS AMD Format                                                                                           // 2758
         Provides the AMD module format definition at System.format.amd                                                // 2759
         as well as a RequireJS-style require on System.require                                                        // 2760
         */                                                                                                            // 2761
        (function() {                                                                                                  // 2762
            // AMD Module Format Detection RegEx                                                                       // 2763
            // define([.., .., ..], ...)                                                                               // 2764
            // define(varName); || define(function(require, exports) {}); || define({})                                // 2765
            var amdRegEx = /(?:^\uFEFF?|[^$_a-zA-Z\xA0-\uFFFF.])define\s*\(\s*("[^"]+"\s*,\s*|'[^']+'\s*,\s*)?\s*(\[(\s*(("[^"]+"|'[^']+')\s*,|\/\/.*\r?\n|\/\*(.|\s)*?\*\/))*(\s*("[^"]+"|'[^']+')\s*,?)?(\s*(\/\/.*\r?\n|\/\*(.|\s)*?\*\/))*\s*\]|function\s*|{|[_$a-zA-Z\xA0-\uFFFF][_$a-zA-Z0-9\xA0-\uFFFF]*\))/;
                                                                                                                       // 2767
            // script injection mode calls this function synchronously on load                                         // 2768
            hook('onScriptLoad', function(onScriptLoad) {                                                              // 2769
                return function(load) {                                                                                // 2770
                    onScriptLoad.call(this, load);                                                                     // 2771
                                                                                                                       // 2772
                    var lastModule = this.get('@@amd-helpers').lastModule;                                             // 2773
                    if (lastModule.anonDefine || lastModule.isBundle) {                                                // 2774
                        load.metadata.format = 'defined';                                                              // 2775
                        load.metadata.registered = true;                                                               // 2776
                        lastModule.isBundle = false;                                                                   // 2777
                    }                                                                                                  // 2778
                                                                                                                       // 2779
                    if (lastModule.anonDefine) {                                                                       // 2780
                        load.metadata.deps = load.metadata.deps ? load.metadata.deps.concat(lastModule.anonDefine.deps) : lastModule.anonDefine.deps;
                        load.metadata.execute = lastModule.anonDefine.execute;                                         // 2782
                        lastModule.anonDefine = null;                                                                  // 2783
                    }                                                                                                  // 2784
                };                                                                                                     // 2785
            });                                                                                                        // 2786
                                                                                                                       // 2787
            hook('fetch', function(fetch) {                                                                            // 2788
                return function(load) {                                                                                // 2789
                    if (load.metadata.format === 'amd')                                                                // 2790
                        load.metadata.scriptLoad = true;                                                               // 2791
                    if (load.metadata.scriptLoad)                                                                      // 2792
                        this.get('@@amd-helpers').createDefine(this);                                                  // 2793
                    return fetch.call(this, load);                                                                     // 2794
                };                                                                                                     // 2795
            });                                                                                                        // 2796
                                                                                                                       // 2797
            hook('instantiate', function(instantiate) {                                                                // 2798
                return function(load) {                                                                                // 2799
                    var loader = this;                                                                                 // 2800
                                                                                                                       // 2801
                    if (load.metadata.format == 'amd' || !load.metadata.format && load.source.match(amdRegEx)) {       // 2802
                        load.metadata.format = 'amd';                                                                  // 2803
                                                                                                                       // 2804
                        if (loader.execute !== false) {                                                                // 2805
                            var removeDefine = this.get('@@amd-helpers').createDefine(loader);                         // 2806
                                                                                                                       // 2807
                            __exec.call(loader, load);                                                                 // 2808
                                                                                                                       // 2809
                            removeDefine(loader);                                                                      // 2810
                                                                                                                       // 2811
                            var lastModule = this.get('@@amd-helpers').lastModule;                                     // 2812
                                                                                                                       // 2813
                            if (!lastModule.anonDefine && !lastModule.isBundle)                                        // 2814
                                throw new TypeError('AMD module ' + load.name + ' did not define');                    // 2815
                                                                                                                       // 2816
                            if (lastModule.anonDefine) {                                                               // 2817
                                load.metadata.deps = load.metadata.deps ? load.metadata.deps.concat(lastModule.anonDefine.deps) : lastModule.anonDefine.deps;
                                load.metadata.execute = lastModule.anonDefine.execute;                                 // 2819
                            }                                                                                          // 2820
                                                                                                                       // 2821
                            lastModule.isBundle = false;                                                               // 2822
                            lastModule.anonDefine = null;                                                              // 2823
                        }                                                                                              // 2824
                                                                                                                       // 2825
                        return instantiate.call(loader, load);                                                         // 2826
                    }                                                                                                  // 2827
                                                                                                                       // 2828
                    return instantiate.call(loader, load);                                                             // 2829
                };                                                                                                     // 2830
            });                                                                                                        // 2831
                                                                                                                       // 2832
        })();                                                                                                          // 2833
        /*                                                                                                             // 2834
         SystemJS map support                                                                                          // 2835
                                                                                                                       // 2836
         Provides map configuration through                                                                            // 2837
         System.map['jquery'] = 'some/module/map'                                                                      // 2838
                                                                                                                       // 2839
         Note that this applies for subpaths, just like RequireJS:                                                     // 2840
                                                                                                                       // 2841
         jquery      -> 'some/module/map'                                                                              // 2842
         jquery/path -> 'some/module/map/path'                                                                         // 2843
         bootstrap   -> 'bootstrap'                                                                                    // 2844
                                                                                                                       // 2845
         The most specific map is always taken, as longest path length                                                 // 2846
         */                                                                                                            // 2847
        hookConstructor(function(constructor) {                                                                        // 2848
            return function() {                                                                                        // 2849
                constructor.call(this);                                                                                // 2850
                this.map = {};                                                                                         // 2851
            };                                                                                                         // 2852
        });                                                                                                            // 2853
                                                                                                                       // 2854
        hook('normalize', function(normalize) {                                                                        // 2855
            return function(name, parentName, parentAddress) {                                                         // 2856
                if (name.substr(0, 1) != '.' && name.substr(0, 1) != '/' && !name.match(absURLRegEx)) {                // 2857
                    var bestMatch, bestMatchLength = 0;                                                                // 2858
                                                                                                                       // 2859
                    // now do the global map                                                                           // 2860
                    for (var p in this.map) {                                                                          // 2861
                        if (name.substr(0, p.length) == p && (name.length == p.length || name[p.length] == '/')) {     // 2862
                            var curMatchLength = p.split('/').length;                                                  // 2863
                            if (curMatchLength <= bestMatchLength)                                                     // 2864
                                continue;                                                                              // 2865
                            bestMatch = p;                                                                             // 2866
                            bestMatchLength = curMatchLength;                                                          // 2867
                        }                                                                                              // 2868
                    }                                                                                                  // 2869
                                                                                                                       // 2870
                    if (bestMatch)                                                                                     // 2871
                        name = this.map[bestMatch] + name.substr(bestMatch.length);                                    // 2872
                }                                                                                                      // 2873
                                                                                                                       // 2874
                return normalize.call(this, name, parentName, parentAddress);                                          // 2875
            };                                                                                                         // 2876
        });                                                                                                            // 2877
        /*                                                                                                             // 2878
         * Paths extension                                                                                             // 2879
         *                                                                                                             // 2880
         * Applies paths and normalizes to a full URL                                                                  // 2881
         */                                                                                                            // 2882
        hook('normalize', function(normalize) {                                                                        // 2883
                                                                                                                       // 2884
            return function(name, parentName) {                                                                        // 2885
                var normalized = normalize.call(this, name, parentName);                                               // 2886
                                                                                                                       // 2887
                // if the module is in the registry already, use that                                                  // 2888
                if (this.has(normalized))                                                                              // 2889
                    return normalized;                                                                                 // 2890
                                                                                                                       // 2891
                if (normalized.match(absURLRegEx)) {                                                                   // 2892
                    // defaultJSExtensions backwards compatibility                                                     // 2893
                    if (this.defaultJSExtensions && normalized.substr(normalized.length - 3, 3) != '.js')              // 2894
                        normalized += '.js';                                                                           // 2895
                    return normalized;                                                                                 // 2896
                }                                                                                                      // 2897
                                                                                                                       // 2898
                // applyPaths implementation provided from ModuleLoader system.js source                               // 2899
                normalized = applyPaths(this.paths, normalized) || normalized;                                         // 2900
                                                                                                                       // 2901
                // defaultJSExtensions backwards compatibility                                                         // 2902
                if (this.defaultJSExtensions && normalized.substr(normalized.length - 3, 3) != '.js')                  // 2903
                    normalized += '.js';                                                                               // 2904
                                                                                                                       // 2905
                // ./x, /x -> page-relative                                                                            // 2906
                if (normalized[0] == '.' || normalized[0] == '/')                                                      // 2907
                    return new URL(normalized, baseURIObj).href;                                                       // 2908
                // x -> baseURL-relative                                                                               // 2909
                else                                                                                                   // 2910
                    return new URL(normalized, getBaseURLObj.call(this)).href;                                         // 2911
            };                                                                                                         // 2912
        });/*                                                                                                          // 2913
         * Package Configuration Extension                                                                             // 2914
         *                                                                                                             // 2915
         * Example:                                                                                                    // 2916
         *                                                                                                             // 2917
         * System.packages = {                                                                                         // 2918
         *   jquery: {                                                                                                 // 2919
         *     main: 'index.js', // when not set, package name is requested directly                                   // 2920
         *     format: 'amd',                                                                                          // 2921
         *     defaultExtension: 'js',                                                                                 // 2922
         *     meta: {                                                                                                 // 2923
         *       '*.ts': {                                                                                             // 2924
         *         loader: 'typescript'                                                                                // 2925
         *       },                                                                                                    // 2926
         *       'vendor/sizzle.js': {                                                                                 // 2927
         *         format: 'global'                                                                                    // 2928
         *       }                                                                                                     // 2929
         *     },                                                                                                      // 2930
         *     map: {                                                                                                  // 2931
         *        // map internal require('sizzle') to local require('./vendor/sizzle')                                // 2932
         *        sizzle: './vendor/sizzle.js',                                                                        // 2933
         *        // map any internal or external require of 'jquery/vendor/another' to 'another/index.js'             // 2934
         *        './vendor/another.js': './another/index.js',                                                         // 2935
         *        // test.js / test -> lib/test.js                                                                     // 2936
         *        './test.js': './lib/test.js',                                                                        // 2937
         *      }                                                                                                      // 2938
         *    }                                                                                                        // 2939
         *  }                                                                                                          // 2940
         * };                                                                                                          // 2941
         *                                                                                                             // 2942
         * Then:                                                                                                       // 2943
         *   import 'jquery'                       -> jquery/index.js                                                  // 2944
         *   import 'jquery/submodule'             -> jquery/submodule.js                                              // 2945
         *   import 'jquery/submodule.ts'          -> jquery/submodule.ts loaded as typescript                         // 2946
         *   import 'jquery/vendor/another'        -> another/index.js                                                 // 2947
         *                                                                                                             // 2948
         * Detailed Behaviours                                                                                         // 2949
         * - main is the only property where a leading "./" can be added optionally                                    // 2950
         * - map and defaultExtension are applied to the main                                                          // 2951
         * - defaultExtension adds the extension only if no other extension is present                                 // 2952
         * - defaultJSExtensions applies after map when defaultExtension is not set                                    // 2953
         * - if a meta value is available for a module, map and defaultExtension are skipped                           // 2954
         * - like global map, package map also applies to subpaths (sizzle/x, ./vendor/another/sub)                    // 2955
         *                                                                                                             // 2956
         * In addition, the following meta properties will be allowed to be package                                    // 2957
         * -relative as well in the package meta config:                                                               // 2958
         *                                                                                                             // 2959
         *   - loader                                                                                                  // 2960
         *   - alias                                                                                                   // 2961
         *                                                                                                             // 2962
         */                                                                                                            // 2963
        (function() {                                                                                                  // 2964
                                                                                                                       // 2965
            hookConstructor(function(constructor) {                                                                    // 2966
                return function() {                                                                                    // 2967
                    constructor.call(this);                                                                            // 2968
                    this.packages = {};                                                                                // 2969
                };                                                                                                     // 2970
            });                                                                                                        // 2971
                                                                                                                       // 2972
            function getPackage(name) {                                                                                // 2973
                for (var p in this.packages) {                                                                         // 2974
                    if (name.substr(0, p.length) === p && (name.length === p.length || name[p.length] === '/'))        // 2975
                        return p;                                                                                      // 2976
                }                                                                                                      // 2977
            }                                                                                                          // 2978
                                                                                                                       // 2979
            function applyMap(map, name) {                                                                             // 2980
                var bestMatch, bestMatchLength = 0;                                                                    // 2981
                                                                                                                       // 2982
                for (var p in map) {                                                                                   // 2983
                    if (name.substr(0, p.length) == p && (name.length == p.length || name[p.length] == '/')) {         // 2984
                        var curMatchLength = p.split('/').length;                                                      // 2985
                        if (curMatchLength <= bestMatchLength)                                                         // 2986
                            continue;                                                                                  // 2987
                        bestMatch = p;                                                                                 // 2988
                        bestMatchLength = curMatchLength;                                                              // 2989
                    }                                                                                                  // 2990
                }                                                                                                      // 2991
                if (bestMatch)                                                                                         // 2992
                    return map[bestMatch] + name.substr(bestMatch.length);                                             // 2993
            }                                                                                                          // 2994
                                                                                                                       // 2995
            hook('normalize', function(normalize) {                                                                    // 2996
                return function(name, parentName) {                                                                    // 2997
                    // apply contextual package map first                                                              // 2998
                    if (parentName) {                                                                                  // 2999
                        var parentPackage = getPackage.call(this, parentName) ||                                       // 3000
                            this.defaultJSExtensions && parentName.substr(parentName.length - 3, 3) == '.js' &&        // 3001
                            getPackage.call(this, parentName.substr(0, parentName.length - 3));                        // 3002
                    }                                                                                                  // 3003
                                                                                                                       // 3004
                    if (parentPackage && name[0] !== '.') {                                                            // 3005
                        var parentMap = this.packages[parentPackage].map;                                              // 3006
                        if (parentMap) {                                                                               // 3007
                            name = applyMap(parentMap, name) || name;                                                  // 3008
                                                                                                                       // 3009
                            // relative maps are package-relative                                                      // 3010
                            if (name[0] === '.')                                                                       // 3011
                                parentName = parentPackage + '/';                                                      // 3012
                        }                                                                                              // 3013
                    }                                                                                                  // 3014
                                                                                                                       // 3015
                    var defaultJSExtension = this.defaultJSExtensions && name.substr(name.length - 3, 3) != '.js';     // 3016
                                                                                                                       // 3017
                    // apply global map, relative normalization                                                        // 3018
                    var normalized = normalize.call(this, name, parentName);                                           // 3019
                                                                                                                       // 3020
                    // undo defaultJSExtension                                                                         // 3021
                    if (normalized.substr(normalized.length - 3, 3) != '.js')                                          // 3022
                        defaultJSExtension = false;                                                                    // 3023
                    if (defaultJSExtension)                                                                            // 3024
                        normalized = normalized.substr(0, normalized.length - 3);                                      // 3025
                                                                                                                       // 3026
                    // check if we are inside a package                                                                // 3027
                    var pkgName = getPackage.call(this, normalized);                                                   // 3028
                                                                                                                       // 3029
                    if (pkgName) {                                                                                     // 3030
                        var pkg = this.packages[pkgName];                                                              // 3031
                                                                                                                       // 3032
                        // main                                                                                        // 3033
                        if (pkgName === normalized && pkg.main)                                                        // 3034
                            normalized += '/' + (pkg.main.substr(0, 2) == './' ? pkg.main.substr(2) : pkg.main);       // 3035
                                                                                                                       // 3036
                        // defaultExtension & defaultJSExtension                                                       // 3037
                        // if we have meta for this package, don't do defaultExtensions                                // 3038
                        var defaultExtension = '';                                                                     // 3039
                        if (!pkg.meta || !pkg.meta[normalized.substr(pkgName.length + 1)]) {                           // 3040
                            // apply defaultExtension                                                                  // 3041
                            if (pkg.defaultExtension) {                                                                // 3042
                                if (normalized.split('/').pop().indexOf('.') == -1)                                    // 3043
                                    defaultExtension = '.' + pkg.defaultExtension;                                     // 3044
                            }                                                                                          // 3045
                            // apply defaultJSExtensions if defaultExtension not set                                   // 3046
                            else if (defaultJSExtension) {                                                             // 3047
                                defaultExtension = '.js';                                                              // 3048
                            }                                                                                          // 3049
                        }                                                                                              // 3050
                                                                                                                       // 3051
                        // apply submap checking without then with defaultExtension                                    // 3052
                        var subPath = '.' + normalized.substr(pkgName.length);                                         // 3053
                        var mapped = applyMap(pkg.map, subPath) || defaultExtension && applyMap(pkg.map, subPath + defaultExtension);
                        if (mapped)                                                                                    // 3055
                            normalized = mapped.substr(0, 2) == './' ? pkgName + mapped.substr(1) : mapped;            // 3056
                        else                                                                                           // 3057
                            normalized += defaultExtension;                                                            // 3058
                    }                                                                                                  // 3059
                    // add back defaultJSExtension if not a package                                                    // 3060
                    else if (defaultJSExtension) {                                                                     // 3061
                        normalized += '.js';                                                                           // 3062
                    }                                                                                                  // 3063
                                                                                                                       // 3064
                    return normalized;                                                                                 // 3065
                };                                                                                                     // 3066
            });                                                                                                        // 3067
                                                                                                                       // 3068
            SystemJSLoader.prototype.normalizeSync = SystemJSLoader.prototype.normalize;                               // 3069
                                                                                                                       // 3070
            hook('locate', function(locate) {                                                                          // 3071
                return function(load) {                                                                                // 3072
                    var loader = this;                                                                                 // 3073
                    return Promise.resolve(locate.call(this, load))                                                    // 3074
                        .then(function(address) {                                                                      // 3075
                            var pkgName = getPackage.call(loader, load.name);                                          // 3076
                            if (pkgName) {                                                                             // 3077
                                var pkg = loader.packages[pkgName];                                                    // 3078
                                                                                                                       // 3079
                                // format                                                                              // 3080
                                if (pkg.format)                                                                        // 3081
                                    load.metadata.format = load.metadata.format || pkg.format;                         // 3082
                                                                                                                       // 3083
                                // loader                                                                              // 3084
                                if (pkg.loader)                                                                        // 3085
                                    load.metadata.loader = load.metadata.loader || pkg.loader;                         // 3086
                                                                                                                       // 3087
                                if (pkg.meta) {                                                                        // 3088
                                    // wildcard meta                                                                   // 3089
                                    var meta = {};                                                                     // 3090
                                    var bestDepth = 0;                                                                 // 3091
                                    var wildcardIndex;                                                                 // 3092
                                    for (var module in pkg.meta) {                                                     // 3093
                                        wildcardIndex = module.indexOf('*');                                           // 3094
                                        if (wildcardIndex === -1)                                                      // 3095
                                            continue;                                                                  // 3096
                                        if (module.substr(0, wildcardIndex) === load.name.substr(0, wildcardIndex)     // 3097
                                            && module.substr(wildcardIndex + 1) === load.name.substr(load.name.length - module.length + wildcardIndex + 1)) {
                                            var depth = module.split('/').length;                                      // 3099
                                            if (depth > bestDepth)                                                     // 3100
                                                bestDetph = depth;                                                     // 3101
                                            extend(meta, pkg.meta[module], bestDepth != depth);                        // 3102
                                        }                                                                              // 3103
                                    }                                                                                  // 3104
                                    // exact meta                                                                      // 3105
                                    var exactMeta = pkg.meta[load.name.substr(pkgName.length + 1)];                    // 3106
                                    if (exactMeta)                                                                     // 3107
                                        extend(meta, exactMeta);                                                       // 3108
                                                                                                                       // 3109
                                    // allow alias and loader to be package-relative                                   // 3110
                                    if (meta.alias && meta.alias.substr(0, 2) == './')                                 // 3111
                                        meta.alias = pkgName + meta.alias.substr(1);                                   // 3112
                                    if (meta.loader && meta.loader.substr(0, 2) == './')                               // 3113
                                        meta.loader = pkgName + meta.loader.substr(1);                                 // 3114
                                                                                                                       // 3115
                                    extend(load.metadata, meta);                                                       // 3116
                                }                                                                                      // 3117
                            }                                                                                          // 3118
                                                                                                                       // 3119
                            return address;                                                                            // 3120
                        });                                                                                            // 3121
                };                                                                                                     // 3122
            });                                                                                                        // 3123
                                                                                                                       // 3124
        })();/*                                                                                                        // 3125
         SystemJS Loader Plugin Support                                                                                // 3126
                                                                                                                       // 3127
         Supports plugin loader syntax with "!", or via metadata.loader                                                // 3128
                                                                                                                       // 3129
         The plugin name is loaded as a module itself, and can override standard loader hooks                          // 3130
         for the plugin resource. See the plugin section of the systemjs readme.                                       // 3131
         */                                                                                                            // 3132
        (function() {                                                                                                  // 3133
                                                                                                                       // 3134
            // sync or async plugin normalize function                                                                 // 3135
            function normalizePlugin(normalize, name, parentName, sync) {                                              // 3136
                var loader = this;                                                                                     // 3137
                // if parent is a plugin, normalize against the parent plugin argument only                            // 3138
                var parentPluginIndex;                                                                                 // 3139
                if (parentName && (parentPluginIndex = parentName.indexOf('!')) != -1)                                 // 3140
                    parentName = parentName.substr(0, parentPluginIndex);                                              // 3141
                                                                                                                       // 3142
                // if this is a plugin, normalize the plugin name and the argument                                     // 3143
                var pluginIndex = name.lastIndexOf('!');                                                               // 3144
                if (pluginIndex != -1) {                                                                               // 3145
                    var argumentName = name.substr(0, pluginIndex);                                                    // 3146
                    var pluginName = name.substr(pluginIndex + 1) || argumentName.substr(argumentName.lastIndexOf('.') + 1);
                                                                                                                       // 3148
                    // note if normalize will add a default js extension                                               // 3149
                    // if so, remove for backwards compat                                                              // 3150
                    // this is strange and sucks, but will be deprecated                                               // 3151
                    var defaultExtension = loader.defaultJSExtensions && argumentName.substr(argumentName.length - 3, 3) != '.js';
                                                                                                                       // 3153
                    if (sync) {                                                                                        // 3154
                        argumentName = loader.normalizeSync(argumentName, parentName);                                 // 3155
                        pluginName = loader.normalizeSync(pluginName, parentName);                                     // 3156
                                                                                                                       // 3157
                        if (defaultExtension && argumentName.substr(argumentName.length - 3, 3) == '.js')              // 3158
                            argumentName = argumentName.substr(0, argumentName.length - 3);                            // 3159
                                                                                                                       // 3160
                        return argumentName + '!' + pluginName;                                                        // 3161
                    }                                                                                                  // 3162
                    else {                                                                                             // 3163
                        return Promise.all([                                                                           // 3164
                            loader.normalize(argumentName, parentName),                                                // 3165
                            loader.normalize(pluginName, parentName)                                                   // 3166
                        ])                                                                                             // 3167
                            .then(function(normalized) {                                                               // 3168
                                argumentName = normalized[0];                                                          // 3169
                                if (defaultExtension)                                                                  // 3170
                                    argumentName = argumentName.substr(0, argumentName.length - 3);                    // 3171
                                return argumentName + '!' + normalized[1];                                             // 3172
                            });                                                                                        // 3173
                    }                                                                                                  // 3174
                }                                                                                                      // 3175
                else {                                                                                                 // 3176
                    return normalize.call(loader, name, parentName);                                                   // 3177
                }                                                                                                      // 3178
            }                                                                                                          // 3179
                                                                                                                       // 3180
            // async plugin normalize                                                                                  // 3181
            hook('normalize', function(normalize) {                                                                    // 3182
                return function(name, parentName) {                                                                    // 3183
                    return normalizePlugin.call(this, normalize, name, parentName, false);                             // 3184
                };                                                                                                     // 3185
            });                                                                                                        // 3186
                                                                                                                       // 3187
            hook('normalizeSync', function(normalizeSync) {                                                            // 3188
                return function(name, parentName) {                                                                    // 3189
                    return normalizePlugin.call(this, normalizeSync, name, parentName, true);                          // 3190
                };                                                                                                     // 3191
            });                                                                                                        // 3192
                                                                                                                       // 3193
            hook('locate', function(locate) {                                                                          // 3194
                return function(load) {                                                                                // 3195
                    var loader = this;                                                                                 // 3196
                                                                                                                       // 3197
                    var name = load.name;                                                                              // 3198
                                                                                                                       // 3199
                    // plugin syntax                                                                                   // 3200
                    var pluginSyntaxIndex = name.lastIndexOf('!');                                                     // 3201
                    if (pluginSyntaxIndex != -1) {                                                                     // 3202
                        load.metadata.loader = name.substr(pluginSyntaxIndex + 1);                                     // 3203
                        load.name = name.substr(0, pluginSyntaxIndex);                                                 // 3204
                    }                                                                                                  // 3205
                                                                                                                       // 3206
                    return locate.call(loader, load)                                                                   // 3207
                        .then(function(address) {                                                                      // 3208
                            var plugin = load.metadata.loader;                                                         // 3209
                                                                                                                       // 3210
                            if (!plugin)                                                                               // 3211
                                return address;                                                                        // 3212
                                                                                                                       // 3213
                            // only fetch the plugin itself if this name isn't defined                                 // 3214
                            if (loader.defined && loader.defined[name])                                                // 3215
                                return address;                                                                        // 3216
                                                                                                                       // 3217
                            var pluginLoader = loader.pluginLoader || loader;                                          // 3218
                                                                                                                       // 3219
                            // load the plugin module and run standard locate                                          // 3220
                            return pluginLoader['import'](plugin)                                                      // 3221
                                .then(function(loaderModule) {                                                         // 3222
                                    // store the plugin module itself on the metadata                                  // 3223
                                    load.metadata.loaderModule = loaderModule;                                         // 3224
                                    load.metadata.loaderArgument = name;                                               // 3225
                                                                                                                       // 3226
                                    load.address = address;                                                            // 3227
                                    if (loaderModule.locate)                                                           // 3228
                                        return loaderModule.locate.call(loader, load);                                 // 3229
                                                                                                                       // 3230
                                    return address;                                                                    // 3231
                                });                                                                                    // 3232
                        });                                                                                            // 3233
                };                                                                                                     // 3234
            });                                                                                                        // 3235
                                                                                                                       // 3236
            hook('fetch', function(fetch) {                                                                            // 3237
                return function(load) {                                                                                // 3238
                    var loader = this;                                                                                 // 3239
                    if (load.metadata.loaderModule && load.metadata.loaderModule.fetch) {                              // 3240
                        load.metadata.scriptLoad = false;                                                              // 3241
                        return load.metadata.loaderModule.fetch.call(loader, load, function(load) {                    // 3242
                            return fetch.call(loader, load);                                                           // 3243
                        });                                                                                            // 3244
                    }                                                                                                  // 3245
                    else {                                                                                             // 3246
                        return fetch.call(loader, load);                                                               // 3247
                    }                                                                                                  // 3248
                };                                                                                                     // 3249
            });                                                                                                        // 3250
                                                                                                                       // 3251
            hook('translate', function(translate) {                                                                    // 3252
                return function(load) {                                                                                // 3253
                    var loader = this;                                                                                 // 3254
                    if (load.metadata.loaderModule && load.metadata.loaderModule.translate)                            // 3255
                        return Promise.resolve(load.metadata.loaderModule.translate.call(loader, load)).then(function(result) {
                            if (typeof result == 'string')                                                             // 3257
                                load.source = result;                                                                  // 3258
                            return translate.call(loader, load);                                                       // 3259
                        });                                                                                            // 3260
                    else                                                                                               // 3261
                        return translate.call(loader, load);                                                           // 3262
                };                                                                                                     // 3263
            });                                                                                                        // 3264
                                                                                                                       // 3265
            hook('instantiate', function(instantiate) {                                                                // 3266
                return function(load) {                                                                                // 3267
                    var loader = this;                                                                                 // 3268
                    if (load.metadata.loaderModule && load.metadata.loaderModule.instantiate)                          // 3269
                        return Promise.resolve(load.metadata.loaderModule.instantiate.call(loader, load)).then(function(result) {
                            load.metadata.format = 'defined';                                                          // 3271
                            load.metadata.execute = function() {                                                       // 3272
                                return result;                                                                         // 3273
                            };                                                                                         // 3274
                            return instantiate.call(loader, load);                                                     // 3275
                        });                                                                                            // 3276
                    else                                                                                               // 3277
                        return instantiate.call(loader, load);                                                         // 3278
                };                                                                                                     // 3279
            });                                                                                                        // 3280
                                                                                                                       // 3281
        })();                                                                                                          // 3282
        /*                                                                                                             // 3283
         * Alias Extension                                                                                             // 3284
         *                                                                                                             // 3285
         * Allows a module to be a plain copy of another module by module name                                         // 3286
         *                                                                                                             // 3287
         * System.meta['mybootstrapalias'] = { alias: 'bootstrap' };                                                   // 3288
         *                                                                                                             // 3289
         */                                                                                                            // 3290
        (function() {                                                                                                  // 3291
            // aliases                                                                                                 // 3292
            hook('fetch', function(fetch) {                                                                            // 3293
                return function(load) {                                                                                // 3294
                    var alias = load.metadata.alias;                                                                   // 3295
                    if (alias) {                                                                                       // 3296
                        load.metadata.format = 'defined';                                                              // 3297
                        this.defined[load.name] = {                                                                    // 3298
                            declarative: true,                                                                         // 3299
                            deps: [alias],                                                                             // 3300
                            declare: function(_export) {                                                               // 3301
                                return {                                                                               // 3302
                                    setters: [function(module) {                                                       // 3303
                                        for (var p in module)                                                          // 3304
                                            _export(p, module[p]);                                                     // 3305
                                    }],                                                                                // 3306
                                    execute: function() {}                                                             // 3307
                                };                                                                                     // 3308
                            }                                                                                          // 3309
                        };                                                                                             // 3310
                        return '';                                                                                     // 3311
                    }                                                                                                  // 3312
                                                                                                                       // 3313
                    return fetch.call(this, load);                                                                     // 3314
                };                                                                                                     // 3315
            });                                                                                                        // 3316
        })();/*                                                                                                        // 3317
         * Meta Extension                                                                                              // 3318
         *                                                                                                             // 3319
         * Sets default metadata on a load record (load.metadata) from                                                 // 3320
         * loader.metadata via System.meta function.                                                                   // 3321
         *                                                                                                             // 3322
         *                                                                                                             // 3323
         * Also provides an inline meta syntax for module meta in source.                                              // 3324
         *                                                                                                             // 3325
         * Eg:                                                                                                         // 3326
         *                                                                                                             // 3327
         * loader.meta({                                                                                               // 3328
         *   'my/module': { deps: ['jquery'] }                                                                         // 3329
         *   'my/*': { format: 'amd' }                                                                                 // 3330
         * });                                                                                                         // 3331
         *                                                                                                             // 3332
         * Which in turn populates loader.metadata.                                                                    // 3333
         *                                                                                                             // 3334
         * load.metadata.deps and load.metadata.format will then be set                                                // 3335
         * for 'my/module'                                                                                             // 3336
         *                                                                                                             // 3337
         * The same meta could be set with a my/module.js file containing:                                             // 3338
         *                                                                                                             // 3339
         * my/module.js                                                                                                // 3340
         *   "format amd";                                                                                             // 3341
         *   "deps[] jquery";                                                                                          // 3342
         *   "globals.some value"                                                                                      // 3343
         *   console.log('this is my/module');                                                                         // 3344
         *                                                                                                             // 3345
         * Configuration meta always takes preference to inline meta.                                                  // 3346
         *                                                                                                             // 3347
         * Multiple matches in wildcards are supported and ammend the meta.                                            // 3348
         *                                                                                                             // 3349
         *                                                                                                             // 3350
         * The benefits of the function form is that paths are URL-normalized                                          // 3351
         * supporting say                                                                                              // 3352
         *                                                                                                             // 3353
         * loader.meta({ './app': { format: 'cjs' } });                                                                // 3354
         *                                                                                                             // 3355
         * Instead of needing to set against the absolute URL (https://site.com/app.js)                                // 3356
         *                                                                                                             // 3357
         */                                                                                                            // 3358
                                                                                                                       // 3359
        (function() {                                                                                                  // 3360
                                                                                                                       // 3361
            hookConstructor(function(constructor) {                                                                    // 3362
                return function() {                                                                                    // 3363
                    this.meta = {};                                                                                    // 3364
                    constructor.call(this);                                                                            // 3365
                };                                                                                                     // 3366
            });                                                                                                        // 3367
                                                                                                                       // 3368
            hook('locate', function(locate) {                                                                          // 3369
                return function(load) {                                                                                // 3370
                    var meta = this.meta;                                                                              // 3371
                    var name = load.name;                                                                              // 3372
                                                                                                                       // 3373
                    // NB for perf, maybe introduce a fast-path wildcard lookup cache here                             // 3374
                    // which is checked first                                                                          // 3375
                                                                                                                       // 3376
                    // apply wildcard metas                                                                            // 3377
                    var bestDepth = 0;                                                                                 // 3378
                    var wildcardIndex;                                                                                 // 3379
                    for (var module in meta) {                                                                         // 3380
                        wildcardIndex = indexOf.call(module, '*');                                                     // 3381
                        if (wildcardIndex === -1)                                                                      // 3382
                            continue;                                                                                  // 3383
                        if (module.substr(0, wildcardIndex) === name.substr(0, wildcardIndex)                          // 3384
                            && module.substr(wildcardIndex + 1) === name.substr(name.length - module.length + wildcardIndex + 1)) {
                            var depth = module.split('/').length;                                                      // 3386
                            if (depth > bestDepth)                                                                     // 3387
                                bestDetph = depth;                                                                     // 3388
                            extend(load.metadata, meta[module], bestDepth != depth);                                   // 3389
                        }                                                                                              // 3390
                    }                                                                                                  // 3391
                                                                                                                       // 3392
                    // apply exact meta                                                                                // 3393
                    if (meta[name])                                                                                    // 3394
                        extend(load.metadata, meta[name]);                                                             // 3395
                                                                                                                       // 3396
                    return locate.call(this, load);                                                                    // 3397
                };                                                                                                     // 3398
            });                                                                                                        // 3399
                                                                                                                       // 3400
            // detect any meta header syntax                                                                           // 3401
            // only set if not already set                                                                             // 3402
            var metaRegEx = /^(\s*\/\*.*\*\/|\s*\/\/[^\n]*|\s*"[^"]+"\s*;?|\s*'[^']+'\s*;?)+/;                         // 3403
            var metaPartRegEx = /\/\*.*\*\/|\/\/[^\n]*|"[^"]+"\s*;?|'[^']+'\s*;?/g;                                    // 3404
                                                                                                                       // 3405
            function setMetaProperty(target, p, value) {                                                               // 3406
                var pParts = p.split('.');                                                                             // 3407
                var curPart;                                                                                           // 3408
                while (pParts.length > 1) {                                                                            // 3409
                    curPart = pParts.shift();                                                                          // 3410
                    target = target[curPart] = target[curPart] || {};                                                  // 3411
                }                                                                                                      // 3412
                curPart = pParts.shift();                                                                              // 3413
                if (!(curPart in target))                                                                              // 3414
                    target[curPart] = value;                                                                           // 3415
            }                                                                                                          // 3416
                                                                                                                       // 3417
            hook('translate', function(translate) {                                                                    // 3418
                return function(load) {                                                                                // 3419
                    // NB meta will be post-translate pending transpiler conversion to plugins                         // 3420
                    var meta = load.source.match(metaRegEx);                                                           // 3421
                    if (meta) {                                                                                        // 3422
                        var metaParts = meta[0].match(metaPartRegEx);                                                  // 3423
                                                                                                                       // 3424
                        for (var i = 0; i < metaParts.length; i++) {                                                   // 3425
                            var curPart = metaParts[i];                                                                // 3426
                            var len = curPart.length;                                                                  // 3427
                                                                                                                       // 3428
                            var firstChar = curPart.substr(0, 1);                                                      // 3429
                            if (curPart.substr(len - 1, 1) == ';')                                                     // 3430
                                len--;                                                                                 // 3431
                                                                                                                       // 3432
                            if (firstChar != '"' && firstChar != "'")                                                  // 3433
                                continue;                                                                              // 3434
                                                                                                                       // 3435
                            var metaString = curPart.substr(1, curPart.length - 3);                                    // 3436
                            var metaName = metaString.substr(0, metaString.indexOf(' '));                              // 3437
                                                                                                                       // 3438
                            if (metaName) {                                                                            // 3439
                                var metaValue = metaString.substr(metaName.length + 1, metaString.length - metaName.length - 1);
                                                                                                                       // 3441
                                if (metaName.substr(metaName.length - 2, 2) == '[]') {                                 // 3442
                                    metaName = metaName.substr(0, metaName.length - 2);                                // 3443
                                    load.metadata[metaName] = load.metadata[metaName] || [];                           // 3444
                                }                                                                                      // 3445
                                                                                                                       // 3446
                                // temporary backwards compat for previous "deps" syntax                               // 3447
                                if (load.metadata[metaName] instanceof Array)                                          // 3448
                                    load.metadata[metaName].push(metaValue);                                           // 3449
                                else                                                                                   // 3450
                                    setMetaProperty(load.metadata, metaName, metaValue);                               // 3451
                            }                                                                                          // 3452
                        }                                                                                              // 3453
                    }                                                                                                  // 3454
                                                                                                                       // 3455
                    return translate.call(this, load);                                                                 // 3456
                };                                                                                                     // 3457
            });                                                                                                        // 3458
        })();/*                                                                                                        // 3459
         System bundles                                                                                                // 3460
                                                                                                                       // 3461
         Allows a bundle module to be specified which will be dynamically                                              // 3462
         loaded before trying to load a given module.                                                                  // 3463
                                                                                                                       // 3464
         For example:                                                                                                  // 3465
         System.bundles['mybundle'] = ['jquery', 'bootstrap/js/bootstrap']                                             // 3466
                                                                                                                       // 3467
         Will result in a load to "mybundle" whenever a load to "jquery"                                               // 3468
         or "bootstrap/js/bootstrap" is made.                                                                          // 3469
                                                                                                                       // 3470
         In this way, the bundle becomes the request that provides the module                                          // 3471
         */                                                                                                            // 3472
                                                                                                                       // 3473
        (function() {                                                                                                  // 3474
            // bundles support (just like RequireJS)                                                                   // 3475
            // bundle name is module name of bundle itself                                                             // 3476
            // bundle is array of modules defined by the bundle                                                        // 3477
            // when a module in the bundle is requested, the bundle is loaded instead                                  // 3478
            // of the form System.bundles['mybundle'] = ['jquery', 'bootstrap/js/bootstrap']                           // 3479
            hookConstructor(function(constructor) {                                                                    // 3480
                return function() {                                                                                    // 3481
                    constructor.call(this);                                                                            // 3482
                    this.bundles = {};                                                                                 // 3483
                    this.loadedBundles_ = {};                                                                          // 3484
                };                                                                                                     // 3485
            });                                                                                                        // 3486
                                                                                                                       // 3487
            function loadFromBundle(loader, bundle) {                                                                  // 3488
                return Promise.resolve(loader.normalize(bundle))                                                       // 3489
                    .then(function(normalized) {                                                                       // 3490
                        loader.loadedBundles_[normalized] = true;                                                      // 3491
                        loader.bundles[normalized] = loader.bundles[normalized] || loader.bundles[bundle];             // 3492
                        return loader.load(normalized);                                                                // 3493
                    })                                                                                                 // 3494
                    .then(function() {                                                                                 // 3495
                        return '';                                                                                     // 3496
                    });                                                                                                // 3497
            }                                                                                                          // 3498
                                                                                                                       // 3499
            // assign bundle metadata for bundle loads                                                                 // 3500
            hook('locate', function(locate) {                                                                          // 3501
                return function(load) {                                                                                // 3502
                    if (load.name in this.loadedBundles_ || load.name in this.bundles)                                 // 3503
                        load.metadata.bundle = true;                                                                   // 3504
                                                                                                                       // 3505
                    return locate.call(this, load);                                                                    // 3506
                };                                                                                                     // 3507
            });                                                                                                        // 3508
                                                                                                                       // 3509
            hook('fetch', function(fetch) {                                                                            // 3510
                return function(load) {                                                                                // 3511
                    var loader = this;                                                                                 // 3512
                    if (loader.trace)                                                                                  // 3513
                        return fetch.call(loader, load);                                                               // 3514
                                                                                                                       // 3515
                    // if already defined, no need to load a bundle                                                    // 3516
                    if (load.name in loader.defined)                                                                   // 3517
                        return '';                                                                                     // 3518
                                                                                                                       // 3519
                    // check if it is in an already-loaded bundle                                                      // 3520
                    for (var b in loader.loadedBundles_) {                                                             // 3521
                        if (indexOf.call(loader.bundles[b], load.name) != -1)                                          // 3522
                            return loadFromBundle(loader, b);                                                          // 3523
                    }                                                                                                  // 3524
                                                                                                                       // 3525
                    // check if it is a new bundle                                                                     // 3526
                    for (var b in loader.bundles) {                                                                    // 3527
                        if (indexOf.call(loader.bundles[b], load.name) != -1)                                          // 3528
                            return loadFromBundle(loader, b);                                                          // 3529
                    }                                                                                                  // 3530
                                                                                                                       // 3531
                    return fetch.call(loader, load);                                                                   // 3532
                };                                                                                                     // 3533
            });                                                                                                        // 3534
        })();                                                                                                          // 3535
        /*                                                                                                             // 3536
         * Dependency Tree Cache                                                                                       // 3537
         *                                                                                                             // 3538
         * Allows a build to pre-populate a dependency trace tree on the loader of                                     // 3539
         * the expected dependency tree, to be loaded upfront when requesting the                                      // 3540
         * module, avoinding the n round trips latency of module loading, where                                        // 3541
         * n is the dependency tree depth.                                                                             // 3542
         *                                                                                                             // 3543
         * eg:                                                                                                         // 3544
         * System.depCache = {                                                                                         // 3545
         *  'app': ['normalized', 'deps'],                                                                             // 3546
         *  'normalized': ['another'],                                                                                 // 3547
         *  'deps': ['tree']                                                                                           // 3548
         * };                                                                                                          // 3549
         *                                                                                                             // 3550
         * System.import('app')                                                                                        // 3551
         * // simultaneously starts loading all of:                                                                    // 3552
         * // 'normalized', 'deps', 'another', 'tree'                                                                  // 3553
         * // before "app" source is even loaded                                                                       // 3554
         */                                                                                                            // 3555
                                                                                                                       // 3556
        (function() {                                                                                                  // 3557
            hookConstructor(function(constructor) {                                                                    // 3558
                return function() {                                                                                    // 3559
                    constructor.call(this);                                                                            // 3560
                    this.depCache = {};                                                                                // 3561
                }                                                                                                      // 3562
            });                                                                                                        // 3563
                                                                                                                       // 3564
            hook('locate', function(locate) {                                                                          // 3565
                return function(load) {                                                                                // 3566
                    var loader = this;                                                                                 // 3567
                    // load direct deps, in turn will pick up their trace trees                                        // 3568
                    var deps = loader.depCache[load.name];                                                             // 3569
                    if (deps)                                                                                          // 3570
                        for (var i = 0; i < deps.length; i++)                                                          // 3571
                            loader['import'](deps[i]);                                                                 // 3572
                                                                                                                       // 3573
                    return locate.call(loader, load);                                                                  // 3574
                };                                                                                                     // 3575
            });                                                                                                        // 3576
        })();                                                                                                          // 3577
                                                                                                                       // 3578
        /*                                                                                                             // 3579
         * Conditions Extension                                                                                        // 3580
         *                                                                                                             // 3581
         *   Allows a condition module to alter the resolution of an import via syntax:                                // 3582
         *                                                                                                             // 3583
         *     import $ from 'jquery/#{browser}';                                                                      // 3584
         *                                                                                                             // 3585
         *   Will first load the module 'browser' via `System.import('browser')` and                                   // 3586
         *   take the default export of that module.                                                                   // 3587
         *   If the default export is not a string, an error is thrown.                                                // 3588
         *                                                                                                             // 3589
         *   We then substitute the string into the require to get the conditional resolution                          // 3590
         *   enabling environment-specific variations like:                                                            // 3591
         *                                                                                                             // 3592
         *     import $ from 'jquery/ie'                                                                               // 3593
         *     import $ from 'jquery/firefox'                                                                          // 3594
         *     import $ from 'jquery/chrome'                                                                           // 3595
         *     import $ from 'jquery/safari'                                                                           // 3596
         *                                                                                                             // 3597
         *   It can be useful for a condition module to define multiple conditions.                                    // 3598
         *   This can be done via the `.` modifier to specify a member expression:                                     // 3599
         *                                                                                                             // 3600
         *     import 'jquery/#{browser.grade}'                                                                        // 3601
         *                                                                                                             // 3602
         *   Where the `grade` export of the `browser` module is taken for substitution.                               // 3603
         *                                                                                                             // 3604
         *   Note that `/` and a leading `.` are not permitted within conditional modules                              // 3605
         *   so that this syntax can be well-defined.                                                                  // 3606
         *                                                                                                             // 3607
         *                                                                                                             // 3608
         * Boolean Conditionals                                                                                        // 3609
         *                                                                                                             // 3610
         *   For polyfill modules, that are used as imports but have no module value,                                  // 3611
         *   a binary conditional allows a module not to be loaded at all if not needed:                               // 3612
         *                                                                                                             // 3613
         *     import 'es5-shim#?conditions.needs-es5shim'                                                             // 3614
         *                                                                                                             // 3615
         */                                                                                                            // 3616
        (function() {                                                                                                  // 3617
                                                                                                                       // 3618
            var conditionalRegEx = /#\{[^\}]+\}|#\?.+$/;                                                               // 3619
                                                                                                                       // 3620
            hook('normalize', function(normalize) {                                                                    // 3621
                return function(name, parentName, parentAddress) {                                                     // 3622
                    var loader = this;                                                                                 // 3623
                    var conditionalMatch = name.match(conditionalRegEx);                                               // 3624
                    if (conditionalMatch) {                                                                            // 3625
                        var substitution = conditionalMatch[0][1] != '?';                                              // 3626
                                                                                                                       // 3627
                        var conditionModule = substitution ? conditionalMatch[0].substr(2, conditionalMatch[0].length - 3) : conditionalMatch[0].substr(2);
                                                                                                                       // 3629
                        if (conditionModule[0] == '.' || conditionModule.indexOf('/') != -1)                           // 3630
                            throw new TypeError('Invalid condition ' + conditionalMatch[0] + '\n\tCondition modules cannot contain . or / in the name.');
                                                                                                                       // 3632
                        var conditionExport = 'default';                                                               // 3633
                        var conditionExportIndex = conditionModule.indexOf('.');                                       // 3634
                        if (conditionExportIndex != -1) {                                                              // 3635
                            conditionExport = conditionModule.substr(conditionExportIndex + 1);                        // 3636
                            conditionModule = conditionModule.substr(0, conditionExportIndex);                         // 3637
                        }                                                                                              // 3638
                                                                                                                       // 3639
                        var booleanNegation = !substitution && conditionModule[0] == '~';                              // 3640
                        if (booleanNegation)                                                                           // 3641
                            conditionModule = conditionModule.substr(1);                                               // 3642
                                                                                                                       // 3643
                        return loader['import'](conditionModule, parentName, parentAddress)                            // 3644
                            .then(function(m) {                                                                        // 3645
                                var conditionValue = readMemberExpression(conditionExport, m);                         // 3646
                                                                                                                       // 3647
                                if (substitution) {                                                                    // 3648
                                    if (typeof conditionValue !== 'string')                                            // 3649
                                        throw new TypeError('The condition value for ' + conditionalMatch[0] + ' doesn\'t resolving to a string.');
                                    name = name.replace(conditionalRegEx, conditionValue);                             // 3651
                                }                                                                                      // 3652
                                else {                                                                                 // 3653
                                    if (typeof conditionValue !== 'boolean')                                           // 3654
                                        throw new TypeError('The condition value for ' + conditionalMatch[0] + ' isn\'t resolving to a boolean.');
                                    if (booleanNegation)                                                               // 3656
                                        conditionValue = !conditionValue;                                              // 3657
                                    if (!conditionValue)                                                               // 3658
                                        name = '@empty';                                                               // 3659
                                    else                                                                               // 3660
                                        name = name.replace(conditionalRegEx, '');                                     // 3661
                                }                                                                                      // 3662
                                return normalize.call(loader, name, parentName, parentAddress);                        // 3663
                            });                                                                                        // 3664
                    }                                                                                                  // 3665
                                                                                                                       // 3666
                    return Promise.resolve(normalize.call(loader, name, parentName, parentAddress));                   // 3667
                };                                                                                                     // 3668
            });                                                                                                        // 3669
                                                                                                                       // 3670
        })();System = new SystemJSLoader();                                                                            // 3671
        System.constructor = SystemJSLoader;  // -- exporting --                                                       // 3672
                                                                                                                       // 3673
        if (typeof exports === 'object')                                                                               // 3674
            module.exports = Loader;                                                                                   // 3675
                                                                                                                       // 3676
        __global.Reflect = __global.Reflect || {};                                                                     // 3677
        __global.Reflect.Loader = __global.Reflect.Loader || Loader;                                                   // 3678
        __global.Reflect.global = __global.Reflect.global || __global;                                                 // 3679
        __global.LoaderPolyfill = Loader;                                                                              // 3680
                                                                                                                       // 3681
        if (!System) {                                                                                                 // 3682
            System = new SystemLoader();                                                                               // 3683
            System.constructor = SystemLoader;                                                                         // 3684
        }                                                                                                              // 3685
                                                                                                                       // 3686
        if (typeof exports === 'object')                                                                               // 3687
            module.exports = System;                                                                                   // 3688
                                                                                                                       // 3689
        __global.System = System;                                                                                      // 3690
                                                                                                                       // 3691
    })(typeof self != 'undefined' ? self : global);}                                                                   // 3692
                                                                                                                       // 3693
// auto-load Promise and URL polyfills if needed in the browser                                                        // 3694
    try {                                                                                                              // 3695
        var hasURL = typeof URLPolyfill != 'undefined' || new URL('test:///').protocol == 'test:';                     // 3696
    }                                                                                                                  // 3697
    catch(e) {}                                                                                                        // 3698
                                                                                                                       // 3699
    if (typeof Promise === 'undefined' || !hasURL) {                                                                   // 3700
        // document.write                                                                                              // 3701
        if (typeof document !== 'undefined') {                                                                         // 3702
            var scripts = document.getElementsByTagName('script');                                                     // 3703
            $__curScript = scripts[scripts.length - 1];                                                                // 3704
            var curPath = $__curScript.src;                                                                            // 3705
            var basePath = curPath.substr(0, curPath.lastIndexOf('/') + 1);                                            // 3706
            window.systemJSBootstrap = bootstrap;                                                                      // 3707
            document.write(                                                                                            // 3708
                '<' + 'script type="text/javascript" src="' + basePath + 'system-polyfills.js">' + '<' + '/script>'    // 3709
            );                                                                                                         // 3710
        }                                                                                                              // 3711
        // importScripts                                                                                               // 3712
        else if (typeof importScripts !== 'undefined') {                                                               // 3713
            var basePath = '';                                                                                         // 3714
            try {                                                                                                      // 3715
                throw new Error('_');                                                                                  // 3716
            } catch (e) {                                                                                              // 3717
                e.stack.replace(/(?:at|@).*(http.+):[\d]+:[\d]+/, function(m, url) {                                   // 3718
                    basePath = url.replace(/\/[^\/]*$/, '/');                                                          // 3719
                });                                                                                                    // 3720
            }                                                                                                          // 3721
            importScripts(basePath + 'system-polyfills.js');                                                           // 3722
            bootstrap();                                                                                               // 3723
        }                                                                                                              // 3724
        else {                                                                                                         // 3725
            bootstrap();                                                                                               // 3726
        }                                                                                                              // 3727
    }                                                                                                                  // 3728
    else {                                                                                                             // 3729
        bootstrap();                                                                                                   // 3730
    }                                                                                                                  // 3731
                                                                                                                       // 3732
                                                                                                                       // 3733
})();                                                                                                                  // 3734
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['universe:modules'] = {};

})();
