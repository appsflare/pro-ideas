var require = meteorInstall({"imports":{"api":{"idea-comments":{"server":{"publications.js":["meteor/meteor","meteor/aldeed:simple-schema","../idea-comments",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/api/idea-comments/server/publications.js                                                            //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var IdeaComments;module.import('../idea-comments',{"IdeaComments":function(v){IdeaComments=v}});/* eslint-disable prefer-arrow-callback */
                                                                                                               //
                                                                                                               // 3
                                                                                                               // 4
                                                                                                               //
                                                                                                               // 6
                                                                                                               //
Meteor.publish('idea-comments.public', function (ideaId) {                                                     // 8
  check(ideaId, String);                                                                                       // 9
  return IdeaComments.find({ ideaId: ideaId }, { sort: { createdAt: -1 } });                                   // 10
});                                                                                                            // 11
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"commentsCountDenormalizer.js":["meteor/underscore","meteor/check","./idea-comments.js","../ideas/ideas.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/api/idea-comments/commentsCountDenormalizer.js                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
var _;module.import('meteor/underscore',{"_":function(v){_=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var IdeaComments;module.import('./idea-comments.js',{"IdeaComments":function(v){IdeaComments=v}});var Ideas;module.import('../ideas/ideas.js',{"Ideas":function(v){Ideas=v}});
                                                                                                               // 2
                                                                                                               //
                                                                                                               // 4
                                                                                                               // 5
                                                                                                               //
var commentsCountDenormalizer = {                                                                              // 7
  _updateIdea: function _updateIdea(ideaId) {                                                                  // 8
    // Recalculate the correct incomplete count direct from MongoDB                                            //
    var comments = IdeaComments.find({ ideaId: ideaId }).count();                                              // 10
                                                                                                               //
    Ideas.update(ideaId, { $set: { comments: comments } });                                                    // 12
  },                                                                                                           // 13
  afterInsertComment: function afterInsertComment(comment) {                                                   // 14
    this._updateIdea(comment.ideaId);                                                                          // 15
  },                                                                                                           // 16
  afterUpdateComment: function afterUpdateComment(selector, modifier) {                                        // 17
    // We only support very limited operations on todos                                                        //
    check(modifier, { $set: Object });                                                                         // 19
  },                                                                                                           // 21
                                                                                                               //
  // Here we need to take the list of todos being removed, selected *before* the update                        //
  // because otherwise we can't figure out the relevant list id(s) (if the todo has been deleted)              //
  afterRemoveComments: function afterRemoveComments(comments) {                                                // 24
    var _this = this;                                                                                          // 24
                                                                                                               //
    comments.forEach(function (comment) {                                                                      // 25
      return _this._updateIdea(comment.ideaId);                                                                // 25
    });                                                                                                        // 25
  }                                                                                                            // 26
};                                                                                                             // 7
                                                                                                               //
module.export("default",exports.default=(commentsCountDenormalizer));                                          // 29
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"idea-comments.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/factory","faker","./commentsCountDenormalizer","meteor/aldeed:simple-schema","../ideas/ideas",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/api/idea-comments/idea-comments.js                                                                  //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({IdeaComments:function(){return IdeaComments}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var Factory;module.import('meteor/factory',{"Factory":function(v){Factory=v}});var faker;module.import('faker',{"default":function(v){faker=v}});var commentsCountDenormalizer;module.import('./commentsCountDenormalizer',{"default":function(v){commentsCountDenormalizer=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Ideas;module.import('../ideas/ideas',{"Ideas":function(v){Ideas=v}});
                                                                                                               //
                                                                                                               //
                                                                                                               // 1
                                                                                                               // 2
                                                                                                               // 3
                                                                                                               //
                                                                                                               // 5
                                                                                                               // 6
                                                                                                               // 7
                                                                                                               //
var IdeaCommentsCollection = function (_Mongo$Collection) {                                                    //
  _inherits(IdeaCommentsCollection, _Mongo$Collection);                                                        //
                                                                                                               //
  function IdeaCommentsCollection() {                                                                          //
    _classCallCheck(this, IdeaCommentsCollection);                                                             //
                                                                                                               //
    return _possibleConstructorReturn(this, _Mongo$Collection.apply(this, arguments));                         //
  }                                                                                                            //
                                                                                                               //
  IdeaCommentsCollection.prototype.insert = function insert(doc, callback) {                                   //
    var ourDoc = doc;                                                                                          // 11
    ourDoc.createdAt = ourDoc.createdAt || new Date();                                                         // 12
    var result = _Mongo$Collection.prototype.insert.call(this, ourDoc, callback);                              // 13
    commentsCountDenormalizer.afterInsertComment(ourDoc);                                                      // 14
    return result;                                                                                             // 15
  };                                                                                                           // 16
                                                                                                               //
  IdeaCommentsCollection.prototype.update = function update(selector, modifier) {                              //
    var result = _Mongo$Collection.prototype.update.call(this, selector, modifier);                            // 18
    commentsCountDenormalizer.afterUpdateComment(selector, modifier);                                          // 19
    return result;                                                                                             // 20
  };                                                                                                           // 21
                                                                                                               //
  IdeaCommentsCollection.prototype.remove = function remove(selector) {                                        //
    var comments = this.find(selector).fetch();                                                                // 23
    var result = _Mongo$Collection.prototype.remove.call(this, selector);                                      // 24
    commentsCountDenormalizer.afterRemoveComments(comments);                                                   // 25
    return result;                                                                                             // 26
  };                                                                                                           // 27
                                                                                                               //
  return IdeaCommentsCollection;                                                                               //
}(Mongo.Collection);                                                                                           //
                                                                                                               //
var IdeaComments = new IdeaCommentsCollection('idea-comments');                                                // 30
                                                                                                               //
IdeaComments.schema = new SimpleSchema({                                                                       // 32
  ideaId: {                                                                                                    // 33
    type: String,                                                                                              // 34
    regEx: SimpleSchema.RegEx.Id,                                                                              // 35
    denyUpdate: true                                                                                           // 36
  },                                                                                                           // 33
  text: {                                                                                                      // 38
    type: String,                                                                                              // 39
    denyUpdate: true                                                                                           // 40
  },                                                                                                           // 38
  createdAt: {                                                                                                 // 42
    type: Date,                                                                                                // 43
    denyUpdate: true                                                                                           // 44
  },                                                                                                           // 42
  ownerId: {                                                                                                   // 46
    type: String,                                                                                              // 47
    regEx: SimpleSchema.RegEx.Id,                                                                              // 48
    denyUpdate: true                                                                                           // 49
  },                                                                                                           // 46
  ownerName: {                                                                                                 // 51
    type: String,                                                                                              // 52
    denyUpdate: true                                                                                           // 53
  }                                                                                                            // 51
});                                                                                                            // 32
                                                                                                               //
// Deny all client-side updates since we will be using methods to manage this collection                       //
IdeaComments.deny({                                                                                            // 58
  insert: function insert() {                                                                                  // 59
    return true;                                                                                               // 59
  },                                                                                                           // 59
  update: function update() {                                                                                  // 60
    return true;                                                                                               // 60
  },                                                                                                           // 60
  remove: function remove() {                                                                                  // 61
    return true;                                                                                               // 61
  }                                                                                                            // 61
});                                                                                                            // 58
                                                                                                               //
IdeaComments.attachSchema(IdeaComments.schema);                                                                // 65
                                                                                                               //
// This represents the keys from Lists objects that should be published                                        //
// to the client. If we add secret properties to List objects, don't list                                      //
// them here to keep them private to the server.                                                               //
IdeaComments.publicFields = {                                                                                  // 70
  ideaId: 1,                                                                                                   // 71
  text: 1,                                                                                                     // 72
  ownerId: 1,                                                                                                  // 73
  ownerName: 1                                                                                                 // 74
};                                                                                                             // 70
                                                                                                               //
// TODO This factory has a name - do we have a code style for this?                                            //
//   - usually I've used the singular, sometimes you have more than one though, like                           //
//   'todo', 'emptyTodo', 'checkedTodo'                                                                        //
Factory.define('idea-comment', IdeaComments, {                                                                 // 80
  ideaId: function ideaId() {                                                                                  // 81
    return Factory.get('ideas');                                                                               // 81
  },                                                                                                           // 81
  text: function text() {                                                                                      // 82
    return faker.lorem.sentence();                                                                             // 82
  },                                                                                                           // 82
  createdAt: function createdAt() {                                                                            // 83
    return new Date();                                                                                         // 83
  }                                                                                                            // 83
});                                                                                                            // 80
                                                                                                               //
IdeaComments.helpers({                                                                                         // 86
  getIdea: function getIdea() {                                                                                // 87
    return Ideas.findOne(this.ideaId);                                                                         // 88
  },                                                                                                           // 89
  editableBy: function editableBy(userId) {                                                                    // 90
    if (!this.ownerId) {                                                                                       // 91
      return true;                                                                                             // 92
    }                                                                                                          // 93
                                                                                                               //
    return this.ownerId === userId;                                                                            // 95
  }                                                                                                            // 96
});                                                                                                            // 86
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["meteor/meteor","meteor/underscore","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","./idea-comments","../ideas/ideas",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/api/idea-comments/methods.js                                                                        //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({insert:function(){return insert},updateText:function(){return updateText},remove:function(){return remove}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var IdeaComments;module.import('./idea-comments',{"IdeaComments":function(v){IdeaComments=v}});var Ideas;module.import('../ideas/ideas',{"Ideas":function(v){Ideas=v}});
                                                                                                               // 2
                                                                                                               // 3
                                                                                                               // 4
                                                                                                               // 5
                                                                                                               //
                                                                                                               // 7
                                                                                                               // 8
                                                                                                               //
var insert = new ValidatedMethod({                                                                             // 11
  name: 'idea-comments.insert',                                                                                // 12
  validate: new SimpleSchema({                                                                                 // 13
    ideaId: { type: String },                                                                                  // 14
    text: { type: String }                                                                                     // 15
  }).validator(),                                                                                              // 13
  run: function run(_ref) {                                                                                    // 17
    var ideaId = _ref.ideaId;                                                                                  // 17
    var text = _ref.text;                                                                                      // 17
                                                                                                               //
    var list = Ideas.findOne(ideaId);                                                                          // 18
                                                                                                               //
    var idea = Ideas.findOne(ideaId);                                                                          // 20
    if (!idea) {                                                                                               // 21
      throw new Meteor.Error('idea-not-found');                                                                // 22
    }                                                                                                          // 23
                                                                                                               //
    var ownerName = Meteor.user().profile.fullName;                                                            // 25
                                                                                                               //
    IdeaComments.insert({ ideaId: ideaId, text: text, ownerId: this.userId, ownerName: ownerName });           // 27
  }                                                                                                            // 28
});                                                                                                            // 11
                                                                                                               //
var updateText = new ValidatedMethod({                                                                         // 31
  name: 'idea-comments.updateText',                                                                            // 32
  validate: new SimpleSchema({                                                                                 // 33
    ideaId: { type: String },                                                                                  // 34
    text: { type: String }                                                                                     // 35
  }).validator(),                                                                                              // 33
  run: function run(_ref2) {                                                                                   // 37
    var ideaId = _ref2.ideaId;                                                                                 // 37
    var newText = _ref2.newText;                                                                               // 37
                                                                                                               //
    // This is complex auth stuff - perhaps denormalizing a userId onto todos                                  //
    // would be correct here?                                                                                  //
    var ideaComment = IdeaComments.findOne(ideaId);                                                            // 40
                                                                                                               //
    if (!ideaComment.editableBy(this.userId)) {                                                                // 42
      throw new Meteor.Error('ideaComments.updateText.accessDenied', 'Cannot edit comment that is not yours');
    }                                                                                                          // 45
                                                                                                               //
    IdeaComments.update(ideaId, {                                                                              // 47
      $set: { text: newText }                                                                                  // 48
    });                                                                                                        // 47
  }                                                                                                            // 50
});                                                                                                            // 31
                                                                                                               //
var remove = new ValidatedMethod({                                                                             // 53
  name: 'idea-comments.remove',                                                                                // 54
  validate: new SimpleSchema({                                                                                 // 55
    commentId: { type: String }                                                                                // 56
  }).validator(),                                                                                              // 55
  run: function run(_ref3) {                                                                                   // 58
    var commentId = _ref3.commentId;                                                                           // 58
                                                                                                               //
    var comment = IdeaComments.findOne(commentId);                                                             // 59
                                                                                                               //
    if (!comment.editableBy(this.userId)) {                                                                    // 61
      throw new Meteor.Error('ideaComments.remove.accessDenied', 'Cannot remove comment that is not yours');   // 62
    }                                                                                                          // 64
                                                                                                               //
    IdeaComments.remove(commentId);                                                                            // 66
  }                                                                                                            // 67
});                                                                                                            // 53
                                                                                                               //
// Get list of all method names on Todos                                                                       //
var IDEA_COMMENTS_METHODS = _.pluck([insert, updateText, remove], 'name');                                     // 71
                                                                                                               //
if (Meteor.isServer) {                                                                                         // 77
  // Only allow 5 todos operations per connection per second                                                   //
  DDPRateLimiter.addRule({                                                                                     // 79
    name: function name(_name) {                                                                               // 80
      return _.contains(IDEA_COMMENTS_METHODS, _name);                                                         // 81
    },                                                                                                         // 82
                                                                                                               //
                                                                                                               //
    // Rate limit per connection ID                                                                            //
    connectionId: function connectionId() {                                                                    // 85
      return true;                                                                                             // 85
    }                                                                                                          // 85
  }, 5, 1000);                                                                                                 // 79
}                                                                                                              // 87
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"ideas":{"server":{"publications.js":["meteor/meteor","../ideas.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/api/ideas/server/publications.js                                                                    //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Ideas;module.import('../ideas.js',{"Ideas":function(v){Ideas=v}});/* eslint-disable prefer-arrow-callback */
                                                                                                               //
                                                                                                               // 3
                                                                                                               //
                                                                                                               // 5
                                                                                                               //
Meteor.publish('ideas.public', function () {                                                                   // 7
  return Ideas.find({}, { fields: Ideas.publicFields, sort: { createdAt: -1 } });                              // 8
});                                                                                                            // 9
Meteor.publish('ideas.public.findOne', function (ideaId) {                                                     // 10
  return Ideas.find({ _id: ideaId }, { fields: Ideas.publicFields });                                          // 11
});                                                                                                            // 12
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"ideas.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/aldeed:simple-schema","meteor/factory",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/api/ideas/ideas.js                                                                                  //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({Ideas:function(){return Ideas}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Factory;module.import('meteor/factory',{"Factory":function(v){Factory=v}});
                                                                                                               //
                                                                                                               //
                                                                                                               // 1
                                                                                                               // 2
                                                                                                               // 3
                                                                                                               //
var IdeasCollection = function (_Mongo$Collection) {                                                           //
  _inherits(IdeasCollection, _Mongo$Collection);                                                               //
                                                                                                               //
  function IdeasCollection() {                                                                                 //
    _classCallCheck(this, IdeasCollection);                                                                    //
                                                                                                               //
    return _possibleConstructorReturn(this, _Mongo$Collection.apply(this, arguments));                         //
  }                                                                                                            //
                                                                                                               //
  IdeasCollection.prototype.insert = function insert(Idea, callback) {                                         //
    var ourIdea = Idea;                                                                                        // 7
    if (!ourIdea.name) {                                                                                       // 8
      var nextLetter = 'A';                                                                                    // 9
      ourIdea.name = 'Idea ' + nextLetter;                                                                     // 10
                                                                                                               //
      while (!!this.findOne({ name: ourIdea.name })) {                                                         // 12
        // not going to be too smart here, can go past Z                                                       //
        nextLetter = String.fromCharCode(nextLetter.charCodeAt(0) + 1);                                        // 14
        ourIdea.name = 'Idea ' + nextLetter;                                                                   // 15
      }                                                                                                        // 16
    }                                                                                                          // 17
                                                                                                               //
    return _Mongo$Collection.prototype.insert.call(this, ourIdea, callback);                                   // 19
  };                                                                                                           // 20
                                                                                                               //
  IdeasCollection.prototype.remove = function remove(selector, callback) {                                     //
    return _Mongo$Collection.prototype.remove.call(this, selector, callback);                                  // 22
  };                                                                                                           // 23
                                                                                                               //
  return IdeasCollection;                                                                                      //
}(Mongo.Collection);                                                                                           //
                                                                                                               //
var Ideas = new IdeasCollection('Ideas');                                                                      // 26
                                                                                                               //
// Deny all client-side updates since we will be using methods to manage this collection                       //
Ideas.deny({                                                                                                   // 29
  insert: function insert() {                                                                                  // 30
    return true;                                                                                               // 30
  },                                                                                                           // 30
  update: function update() {                                                                                  // 31
    return true;                                                                                               // 31
  },                                                                                                           // 31
  remove: function remove() {                                                                                  // 32
    return true;                                                                                               // 32
  }                                                                                                            // 32
});                                                                                                            // 29
                                                                                                               //
Ideas.schema = new SimpleSchema({                                                                              // 35
  name: {                                                                                                      // 36
    type: String                                                                                               // 37
  },                                                                                                           // 36
  businessValue: {                                                                                             // 39
    type: String                                                                                               // 40
  },                                                                                                           // 39
  definitionOfSuccess: {                                                                                       // 42
    type: String,                                                                                              // 43
    optional: true                                                                                             // 44
  },                                                                                                           // 42
  fundingRequirement: {                                                                                        // 46
    type: String,                                                                                              // 47
    optional: true,                                                                                            // 48
    defaultValue: ''                                                                                           // 49
  },                                                                                                           // 46
  createdAt: {                                                                                                 // 51
    type: Date                                                                                                 // 52
  },                                                                                                           // 51
  ownerId: {                                                                                                   // 54
    type: String,                                                                                              // 55
    regEx: SimpleSchema.RegEx.Id                                                                               // 56
  },                                                                                                           // 54
  ownerName: {                                                                                                 // 58
    type: String                                                                                               // 59
  },                                                                                                           // 58
  comments: {                                                                                                  // 61
    type: Number,                                                                                              // 62
    optional: true,                                                                                            // 63
    defaultValue: 0                                                                                            // 64
  },                                                                                                           // 61
  upVotes: {                                                                                                   // 66
    type: Number,                                                                                              // 67
    optional: true,                                                                                            // 68
    defaultValue: 0                                                                                            // 69
  },                                                                                                           // 66
  downVotes: {                                                                                                 // 71
    type: Number,                                                                                              // 72
    optional: true,                                                                                            // 73
    defaultValue: 0                                                                                            // 74
  }                                                                                                            // 71
});                                                                                                            // 35
                                                                                                               //
Ideas.attachSchema(Ideas.schema);                                                                              // 78
                                                                                                               //
Ideas.publicFields = {                                                                                         // 81
  name: 1,                                                                                                     // 82
  businessValue: 1,                                                                                            // 83
  definitionOfSuccess: 1,                                                                                      // 84
  fundingRequirement: 1,                                                                                       // 85
  createdAt: 1,                                                                                                // 86
  ownerId: 1,                                                                                                  // 87
  ownerName: 1,                                                                                                // 88
  comments: 1,                                                                                                 // 89
  upVotes: 1,                                                                                                  // 90
  downVotes: 1                                                                                                 // 91
};                                                                                                             // 81
                                                                                                               //
Factory.define('Idea', Ideas, {});                                                                             // 94
                                                                                                               //
Ideas.helpers({                                                                                                // 96
  // A Idea is considered to be private if it has a userId set                                                 //
                                                                                                               //
  isPrivate: function isPrivate() {                                                                            // 98
    return !!this.ownerId;                                                                                     // 99
  },                                                                                                           // 100
  editableBy: function editableBy(userId) {                                                                    // 101
    if (!this.ownerId) {                                                                                       // 102
      return true;                                                                                             // 103
    }                                                                                                          // 104
                                                                                                               //
    return this.ownerId === userId;                                                                            // 106
  },                                                                                                           // 107
  comments: function comments() {                                                                              // 108
    return Comments.find({ ideaId: this._id }, { sort: { createdAt: -1 } });                                   // 109
  }                                                                                                            // 110
});                                                                                                            // 96
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["meteor/meteor","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","meteor/underscore","./ideas.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/api/ideas/methods.js                                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({insert:function(){return insert},update:function(){return update},remove:function(){return remove}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Ideas;module.import('./ideas.js',{"Ideas":function(v){Ideas=v}});
                                                                                                               // 2
                                                                                                               // 3
                                                                                                               // 4
                                                                                                               // 5
                                                                                                               //
                                                                                                               // 7
                                                                                                               //
var IDEA_ID_ONLY = new SimpleSchema({                                                                          // 9
  ideaId: { type: String }                                                                                     // 10
}).validator();                                                                                                // 9
                                                                                                               //
var insert = new ValidatedMethod({                                                                             // 13
  name: 'ideas.insert',                                                                                        // 14
  validate: new SimpleSchema({                                                                                 // 15
    name: { type: String, optional: true },                                                                    // 16
    businessValue: { type: String, optional: true },                                                           // 17
    definitionOfSuccess: { type: String, optional: true },                                                     // 18
    fundingRequirement: { type: String, optional: true }                                                       // 19
  }).validator(),                                                                                              // 15
  run: function run(newIdea) {                                                                                 // 21
    if (!this.userId) {                                                                                        // 22
      throw new Error('not-authorized');                                                                       // 22
    }                                                                                                          // 22
                                                                                                               //
    newIdea.ownerId = this.userId;                                                                             // 24
    newIdea.ownerName = Meteor.user().profile.fullName;                                                        // 25
    newIdea.createdAt = Date.now();                                                                            // 26
    return Ideas.insert(newIdea);                                                                              // 27
  }                                                                                                            // 28
});                                                                                                            // 13
                                                                                                               //
var update = new ValidatedMethod({                                                                             // 31
  name: 'ideas.update',                                                                                        // 32
  validate: new SimpleSchema({                                                                                 // 33
    ideaId: { type: String },                                                                                  // 34
    name: { type: String, optional: true },                                                                    // 35
    businessValue: { type: String, optional: true },                                                           // 36
    definitionOfSuccess: { type: String, optional: true },                                                     // 37
    fundingRequirement: { type: String, optional: true }                                                       // 38
  }).validator(),                                                                                              // 33
  run: function run(data) {                                                                                    // 40
    var idea = Ideas.findOne(ideaId);                                                                          // 41
                                                                                                               //
    if (!list.editableBy(this.userId)) {                                                                       // 43
      throw new Meteor.Error('ideas.update.accessDenied', "You don't have permission to edit this idea.");     // 44
    }                                                                                                          // 46
                                                                                                               //
    // XXX the security check above is not atomic, so in theory a race condition could                         //
    // result in exposing private data                                                                         //
                                                                                                               //
    Ideas.update(ideaId, {                                                                                     // 51
      $set: data                                                                                               // 52
    });                                                                                                        // 51
  }                                                                                                            // 54
});                                                                                                            // 31
                                                                                                               //
var remove = new ValidatedMethod({                                                                             // 57
  name: 'ideas.remove',                                                                                        // 58
  validate: IDEA_ID_ONLY,                                                                                      // 59
  run: function run(_ref) {                                                                                    // 60
    var ideaId = _ref.ideaId;                                                                                  // 60
                                                                                                               //
    var idea = Ideas.findOne(ideaId);                                                                          // 61
                                                                                                               //
    if (!idea.editableBy(this.userId)) {                                                                       // 63
      throw new Meteor.Error('ideas.remove.accessDenied', "You don't have permission to remove this idea.");   // 64
    }                                                                                                          // 66
                                                                                                               //
    Ideas.remove(ideaId);                                                                                      // 68
  }                                                                                                            // 69
});                                                                                                            // 57
                                                                                                               //
// Get list of all method names on ideas                                                                       //
var ideas_METHODS = _.pluck([insert, update, remove], 'name');                                                 // 73
                                                                                                               //
if (Meteor.isServer) {                                                                                         // 79
  // Only allow 5 list operations per connection per second                                                    //
  DDPRateLimiter.addRule({                                                                                     // 81
    name: function name(_name) {                                                                               // 82
      return _.contains(ideas_METHODS, _name);                                                                 // 83
    },                                                                                                         // 84
                                                                                                               //
                                                                                                               //
    // Rate limit per connection ID                                                                            //
    connectionId: function connectionId() {                                                                    // 87
      return true;                                                                                             // 87
    }                                                                                                          // 87
  }, 5, 1000);                                                                                                 // 81
}                                                                                                              // 89
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"votes":{"methods.js":["meteor/meteor","meteor/underscore","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","./votes","../ideas/ideas",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/api/votes/methods.js                                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({cast:function(){return cast}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var Votes;module.import('./votes',{"Votes":function(v){Votes=v}});var Ideas;module.import('../ideas/ideas',{"Ideas":function(v){Ideas=v}});
                                                                                                               // 2
                                                                                                               // 3
                                                                                                               // 4
                                                                                                               // 5
                                                                                                               //
                                                                                                               // 7
                                                                                                               // 8
                                                                                                               //
var cast = new ValidatedMethod({                                                                               // 10
  name: 'votes.cast',                                                                                          // 11
  validate: new SimpleSchema({                                                                                 // 12
    ideaId: { type: String },                                                                                  // 13
    isUpVote: { type: Boolean }                                                                                // 14
  }).validator(),                                                                                              // 12
  run: function run(_ref) {                                                                                    // 16
    var ideaId = _ref.ideaId;                                                                                  // 16
    var isUpVote = _ref.isUpVote;                                                                              // 16
                                                                                                               //
    var idea = Ideas.findOne(ideaId);                                                                          // 17
    if (!idea) {                                                                                               // 18
      throw new Meteor.Error('idea-not-found');                                                                // 19
    }                                                                                                          // 20
                                                                                                               //
    var castedVote = Votes.findOne({ ideaId: ideaId, ownerId: this.userId });                                  // 22
    if (!castedVote) {                                                                                         // 23
      var ownerName = Meteor.user().profile.fullName;                                                          // 24
      var ownerId = this.userId;                                                                               // 25
      var vote = { ideaId: ideaId, isUpVote: isUpVote, ownerId: ownerId, ownerName: ownerName };               // 26
      Votes.insert(vote);                                                                                      // 27
    } else {                                                                                                   // 28
      Votes.update({ _id: castedVote._id }, { $set: { isUpVote: isUpVote } });                                 // 29
    }                                                                                                          // 30
  }                                                                                                            // 31
});                                                                                                            // 10
                                                                                                               //
// Get list of all method names on Todos                                                                       //
var VOTES_METHODS = _.pluck([cast], 'name');                                                                   // 35
                                                                                                               //
if (Meteor.isServer) {                                                                                         // 37
  // Only allow 5 todos operations per connection per second                                                   //
  DDPRateLimiter.addRule({                                                                                     // 39
    name: function name(_name) {                                                                               // 40
      return _.contains(VOTES_METHODS, _name);                                                                 // 41
    },                                                                                                         // 42
                                                                                                               //
                                                                                                               //
    // Rate limit per connection ID                                                                            //
    connectionId: function connectionId() {                                                                    // 45
      return true;                                                                                             // 45
    }                                                                                                          // 45
  }, 5, 1000);                                                                                                 // 39
}                                                                                                              // 47
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"votes.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/check","meteor/factory","faker","./votesCountDenormalizer","meteor/aldeed:simple-schema",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/api/votes/votes.js                                                                                  //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({Votes:function(){return Votes}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Factory;module.import('meteor/factory',{"Factory":function(v){Factory=v}});var faker;module.import('faker',{"default":function(v){faker=v}});var votesCountDenormalizer;module.import('./votesCountDenormalizer',{"default":function(v){votesCountDenormalizer=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});
                                                                                                               //
                                                                                                               //
                                                                                                               // 1
                                                                                                               // 2
                                                                                                               // 3
                                                                                                               // 4
                                                                                                               //
                                                                                                               // 6
                                                                                                               // 7
                                                                                                               //
var VotesCollection = function (_Mongo$Collection) {                                                           //
  _inherits(VotesCollection, _Mongo$Collection);                                                               //
                                                                                                               //
  function VotesCollection() {                                                                                 //
    _classCallCheck(this, VotesCollection);                                                                    //
                                                                                                               //
    return _possibleConstructorReturn(this, _Mongo$Collection.apply(this, arguments));                         //
  }                                                                                                            //
                                                                                                               //
  VotesCollection.prototype.insert = function insert(doc, callback) {                                          //
    var ourDoc = doc;                                                                                          // 14
    ourDoc.createdAt = ourDoc.createdAt || new Date();                                                         // 15
    var result = _Mongo$Collection.prototype.insert.call(this, ourDoc, callback);                              // 16
    votesCountDenormalizer.afterInsertVote(ourDoc);                                                            // 17
    return result;                                                                                             // 18
  };                                                                                                           // 19
                                                                                                               //
  VotesCollection.prototype.update = function update(selector, modifier) {                                     //
    var result = _Mongo$Collection.prototype.update.call(this, selector, modifier);                            // 21
    votesCountDenormalizer.afterUpdateVote(selector, modifier);                                                // 22
    return result;                                                                                             // 23
  };                                                                                                           // 24
                                                                                                               //
  VotesCollection.prototype.remove = function remove(selector) {                                               //
    var comments = this.find(selector).fetch();                                                                // 26
    var result = _Mongo$Collection.prototype.remove.call(this, selector);                                      // 27
    votesCountDenormalizer.afterRemoveVotes(comments);                                                         // 28
    return result;                                                                                             // 29
  };                                                                                                           // 30
                                                                                                               //
  return VotesCollection;                                                                                      //
}(Mongo.Collection);                                                                                           //
                                                                                                               //
var Votes = new VotesCollection('votes');                                                                      // 33
                                                                                                               //
Votes.schema = new SimpleSchema({                                                                              // 35
  ideaId: {                                                                                                    // 36
    type: String,                                                                                              // 37
    regEx: SimpleSchema.RegEx.Id,                                                                              // 38
    denyUpdate: true                                                                                           // 39
  },                                                                                                           // 36
  isUpVote: {                                                                                                  // 41
    type: Boolean                                                                                              // 42
  },                                                                                                           // 41
  createdAt: {                                                                                                 // 44
    type: Date,                                                                                                // 45
    denyUpdate: true                                                                                           // 46
  },                                                                                                           // 44
  ownerId: {                                                                                                   // 48
    type: String,                                                                                              // 49
    regEx: SimpleSchema.RegEx.Id,                                                                              // 50
    denyUpdate: true                                                                                           // 51
  },                                                                                                           // 48
  ownerName: {                                                                                                 // 53
    type: String,                                                                                              // 54
    denyUpdate: true                                                                                           // 55
  }                                                                                                            // 53
});                                                                                                            // 35
                                                                                                               //
Votes.attachSchema(Votes.schema);                                                                              // 59
                                                                                                               //
// Deny all client-side updates since we will be using methods to manage this collection                       //
Votes.deny({                                                                                                   // 62
  insert: function insert() {                                                                                  // 63
    return true;                                                                                               // 63
  },                                                                                                           // 63
  update: function update() {                                                                                  // 64
    return true;                                                                                               // 64
  },                                                                                                           // 64
  remove: function remove() {                                                                                  // 65
    return true;                                                                                               // 65
  }                                                                                                            // 65
});                                                                                                            // 62
                                                                                                               //
Factory.define('Vote', Votes, {});                                                                             // 68
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"votesCountDenormalizer.js":["meteor/underscore","meteor/check","./votes","../ideas/ideas",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/api/votes/votesCountDenormalizer.js                                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
var _;module.import('meteor/underscore',{"_":function(v){_=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Votes;module.import('./votes',{"Votes":function(v){Votes=v}});var Ideas;module.import('../ideas/ideas',{"Ideas":function(v){Ideas=v}});
                                                                                                               // 2
                                                                                                               //
                                                                                                               // 4
                                                                                                               // 5
                                                                                                               //
function getVotesCount(ideaId, isUpVote) {                                                                     // 7
  return Votes.find({ ideaId: ideaId, isUpVote: isUpVote }).count();                                           // 8
}                                                                                                              // 9
                                                                                                               //
var votesCountDenormalizer = {                                                                                 // 11
  _updateIdea: function _updateIdea(ideaId) {                                                                  // 12
    // Recalculate the correct incomplete count direct from MongoDB                                            //
    var stats = { upVotes: getVotesCount(ideaId, true), downVotes: getVotesCount(ideaId, false) };             // 14
    Ideas.update(ideaId, { $set: stats });                                                                     // 15
  },                                                                                                           // 16
  afterInsertVote: function afterInsertVote(vote) {                                                            // 17
    this._updateIdea(vote.ideaId);                                                                             // 18
  },                                                                                                           // 19
  afterUpdateVote: function afterUpdateVote(selector, modifier) {                                              // 20
    var _this = this;                                                                                          // 20
                                                                                                               //
    // We only support very limited operations on todos                                                        //
    check(modifier, { $set: Object });                                                                         // 22
                                                                                                               //
    var votes = Votes.find(selector);                                                                          // 24
    votes.forEach(function (vote) {                                                                            // 25
      return _this._updateIdea(vote.ideaId);                                                                   // 25
    });                                                                                                        // 25
  },                                                                                                           // 26
                                                                                                               //
  // Here we need to take the list of todos being removed, selected *before* the update                        //
  // because otherwise we can't figure out the relevant list id(s) (if the todo has been deleted)              //
  afterRemoveVotes: function afterRemoveVotes(votes) {                                                         // 29
    var _this2 = this;                                                                                         // 29
                                                                                                               //
    votes.forEach(function (vote) {                                                                            // 30
      return _this2._updateIdea(vote.ideaId);                                                                  // 30
    });                                                                                                        // 30
  }                                                                                                            // 31
};                                                                                                             // 11
                                                                                                               //
module.export("default",exports.default=(votesCountDenormalizer));                                             // 34
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"startup":{"server":{"fixtures.js":["meteor/meteor","../../api/ideas/ideas","../../api/idea-comments/idea-comments","../../api/votes/votes",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/startup/server/fixtures.js                                                                          //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Ideas;module.import('../../api/ideas/ideas',{"Ideas":function(v){Ideas=v}});var IdeaComments;module.import('../../api/idea-comments/idea-comments',{"IdeaComments":function(v){IdeaComments=v}});var Votes;module.import('../../api/votes/votes',{"Votes":function(v){Votes=v}});
                                                                                                               // 2
                                                                                                               // 3
                                                                                                               // 4
                                                                                                               //
Meteor.startup(function () {});                                                                                // 8
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./fixtures.js","./reset-password-email.js","./security.js","./register-api.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/startup/server/index.js                                                                             //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.import('./fixtures.js');module.import('./reset-password-email.js');module.import('./security.js');module.import('./register-api.js');// This defines a starting set of data to be loaded if the app is loaded with an empty db.
                                                                                                               // 2
                                                                                                               //
// This file configures the Accounts package to define the UI of the reset password email.                     //
                                                                                                               // 5
                                                                                                               //
// Set up some rate limiting and other important security settings.                                            //
                                                                                                               // 8
                                                                                                               //
// This defines all the collections, publications and methods that the application provides                    //
// as an API to the client.                                                                                    //
                                                                                                               // 12
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"register-api.js":["../../api/ideas/methods.js","../../api/ideas/server/publications.js","../../api/idea-comments/methods.js","../../api/idea-comments/server/publications.js","../../api/votes/methods.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/startup/server/register-api.js                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.import('../../api/ideas/methods.js');module.import('../../api/ideas/server/publications.js');module.import('../../api/idea-comments/methods.js');module.import('../../api/idea-comments/server/publications.js');module.import('../../api/votes/methods.js');
                                                                                                               // 2
                                                                                                               // 3
                                                                                                               // 4
                                                                                                               // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"reset-password-email.js":["meteor/accounts-base",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/startup/server/reset-password-email.js                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});                       // 1
                                                                                                               //
Accounts.emailTemplates.siteName = 'Idea Dashboard';                                                           // 4
Accounts.emailTemplates.from = 'Ideas Dashboard <accounts@example.com>';                                       // 5
                                                                                                               //
Accounts.emailTemplates.resetPassword = {                                                                      // 7
  subject: function subject() {                                                                                // 8
    return 'Reset your password on Idea Dashboard';                                                            // 9
  },                                                                                                           // 10
  text: function text(user, url) {                                                                             // 11
    return 'Hello!\n\nClick the link below to reset your password on Idea Dashboard.\n\n' + url + '\n\nIf you didn\'t request this email, please ignore it.\n\nThanks,\nThe Idea Dashboard Team\n';
  }                                                                                                            // 23
};                                                                                                             // 7
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"security.js":["meteor/meteor","meteor/ddp-rate-limiter","meteor/underscore",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/startup/server/security.js                                                                          //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});
                                                                                                               // 2
                                                                                                               // 3
                                                                                                               //
// Don't let people write arbitrary data to their 'profile' field from the client                              //
Meteor.users.deny({                                                                                            // 6
  update: function update() {                                                                                  // 7
    return true;                                                                                               // 8
  }                                                                                                            // 9
});                                                                                                            // 6
                                                                                                               //
// Get a list of all accounts methods by running `Meteor.server.method_handlers` in meteor shell               //
var AUTH_METHODS = ['login', 'logout', 'logoutOtherClients', 'getNewToken', 'removeOtherTokens', 'configureLoginService', 'changePassword', 'forgotPassword', 'resetPassword', 'verifyEmail', 'createUser', 'ATRemoveService', 'ATCreateUserServer', 'ATResendVerificationEmail'];
                                                                                                               //
if (Meteor.isServer) {                                                                                         // 30
  // Only allow 2 login attempts per connection per 5 seconds                                                  //
  DDPRateLimiter.addRule({                                                                                     // 32
    name: function name(_name) {                                                                               // 33
      return _.contains(AUTH_METHODS, _name);                                                                  // 34
    },                                                                                                         // 35
                                                                                                               //
                                                                                                               //
    // Rate limit per connection ID                                                                            //
    connectionId: function connectionId() {                                                                    // 38
      return true;                                                                                             // 38
    }                                                                                                          // 38
  }, 2, 5000);                                                                                                 // 32
}                                                                                                              // 40
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}},"i18n":{"en.i18n.json":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// i18n/en.i18n.json                                                                                           //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n._enable({"helper_name":"_","supported_languages":null,"i18n_files_route":"/tap-i18n","preloaded_langs":[],"cdn_path":null});
TAPi18n.languages_names["en"] = ["English","English"];
// integrate the fallback language translations 
translations = {};
translations[namespace] = {"lists":{"makePrivate":{"notLoggedIn":"Must be logged in to make private lists.","lastPublicList":"Cannot make the last public list private."},"makePublic":{"notLoggedIn":"Must be logged in.","accessDenied":"You don't have permission to edit this list."},"updateName":{"accessDenied":"You don't have permission to edit this list."},"remove":{"accessDenied":"'You don't have permission to remove this list.'","lastPublicList":"Cannot delete the last public list."}},"todos":{"insert":{"accessDenied":"Cannot add todos to a private list that is not yours"},"setCheckedStatus":{"accessDenied":"Cannot edit todos in a private list that is not yours"},"updateText":{"accessDenied":"Cannot edit todos in a private list that is not yours"},"remove":{"accessDenied":"Cannot remove todos in a private list that is not yours"}}};
TAPi18n._loadLangFileObject("en", translations);
TAPi18n._registerServerTranslator("en", namespace);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":["/imports/startup/server",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/main.js                                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.import('/imports/startup/server');                                                                      // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./i18n/en.i18n.json");
require("./server/main.js");
//# sourceMappingURL=app.js.map
