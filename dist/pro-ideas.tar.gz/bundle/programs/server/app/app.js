var require = meteorInstall({"imports":{"api":{"idea-comments.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/check","./ideas",function(require,exports){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// imports/api/idea-comments.js                                                                         //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
exports.__esModule = true;                                                                              //
exports.IdeaComments = undefined;                                                                       //
                                                                                                        //
var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');                                 //
                                                                                                        //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                        //
                                                                                                        //
var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');           //
                                                                                                        //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                  //
                                                                                                        //
var _inherits2 = require('babel-runtime/helpers/inherits');                                             //
                                                                                                        //
var _inherits3 = _interopRequireDefault(_inherits2);                                                    //
                                                                                                        //
var _mongo = require('meteor/mongo');                                                                   // 1
                                                                                                        //
var _check = require('meteor/check');                                                                   // 2
                                                                                                        //
var _ideas = require('./ideas');                                                                        // 3
                                                                                                        //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }       //
                                                                                                        //
var _ideaCommentNotifications = {                                                                       // 5
  _onInsert: function () {                                                                              // 6
    function _onInsert(comment) {                                                                       //
      console.log(comment);                                                                             // 7
      Meteor.call('ideas.calcComments', comment.ideaId);                                                // 8
    }                                                                                                   //
                                                                                                        //
    return _onInsert;                                                                                   //
  }(),                                                                                                  //
  _onRemove: function () {                                                                              // 11
    function _onRemove(comment) {                                                                       //
      Meteor.call('ideas.calcComments', comment.ideaId);                                                // 12
    }                                                                                                   //
                                                                                                        //
    return _onRemove;                                                                                   //
  }()                                                                                                   //
};                                                                                                      //
                                                                                                        //
var IdeaCommentsCollection = function (_Mongo$Collection) {                                             //
  (0, _inherits3['default'])(IdeaCommentsCollection, _Mongo$Collection);                                //
                                                                                                        //
  function IdeaCommentsCollection() {                                                                   //
    (0, _classCallCheck3['default'])(this, IdeaCommentsCollection);                                     //
    return (0, _possibleConstructorReturn3['default'])(this, _Mongo$Collection.apply(this, arguments));
  }                                                                                                     //
                                                                                                        //
  IdeaCommentsCollection.prototype.insert = function () {                                               //
    function insert(comment, callback) {                                                                //
      var res = _Mongo$Collection.prototype.insert.call(this, comment, callback);                       // 19
                                                                                                        //
      _ideaCommentNotifications._onInsert(comment, callback);                                           // 21
                                                                                                        //
      return res;                                                                                       // 23
    }                                                                                                   //
                                                                                                        //
    return insert;                                                                                      //
  }();                                                                                                  //
                                                                                                        //
  IdeaCommentsCollection.prototype.remove = function () {                                               // 16
    function remove(commentId, callback) {                                                              //
      var comment = _Mongo$Collection.prototype.findOne.call(this, commentId);                          // 28
      var res = _Mongo$Collection.prototype.remove.call(this, commentId, callback);                     // 29
      _ideaCommentNotifications._onRemove(comment, callback);                                           // 30
      return res;                                                                                       // 31
    }                                                                                                   //
                                                                                                        //
    return remove;                                                                                      //
  }();                                                                                                  //
                                                                                                        //
  return IdeaCommentsCollection;                                                                        //
}(_mongo.Mongo.Collection);                                                                             //
                                                                                                        //
var IdeaComments = exports.IdeaComments = new IdeaCommentsCollection('idea-comments');                  // 36
                                                                                                        //
IdeaComments.schema = new SimpleSchema({                                                                // 38
  ideaId: {                                                                                             // 39
    type: String,                                                                                       // 40
    regEx: SimpleSchema.RegEx.Id                                                                        // 41
  },                                                                                                    //
  text: {                                                                                               // 43
    type: String                                                                                        // 44
  },                                                                                                    //
  createdAt: {                                                                                          // 46
    type: Date                                                                                          // 47
  },                                                                                                    //
  ownerId: {                                                                                            // 49
    type: String,                                                                                       // 50
    regEx: SimpleSchema.RegEx.Id                                                                        // 51
  },                                                                                                    //
  ownerName: {                                                                                          // 53
    type: String                                                                                        // 54
  }                                                                                                     //
});                                                                                                     //
                                                                                                        //
IdeaComments.attachSchema(IdeaComments.schema);                                                         // 58
                                                                                                        //
IdeaComments.publicKeys = ['ideaId', 'text', 'createdAt', 'ownerId'];                                   // 60
                                                                                                        //
if (Meteor.isServer) {                                                                                  // 62
  Meteor.publish('idea-comments.public', function (ideaId) {                                            // 63
    (0, _check.check)(ideaId, String);                                                                  // 64
    return IdeaComments.find({ ideaId: ideaId }, { sort: { createdAt: -1 } });                          // 65
  });                                                                                                   //
                                                                                                        //
  Meteor.methods({                                                                                      // 68
    'idea-comments.getCount': function () {                                                             // 69
      function ideaCommentsGetCount(ideaId) {                                                           //
        return IdeaComments.find({ ideaId: ideaId }).count();                                           // 70
      }                                                                                                 //
                                                                                                        //
      return ideaCommentsGetCount;                                                                      //
    }(),                                                                                                //
    'idea-comments.insert': function () {                                                               // 73
      function ideaCommentsInsert(ideaId, text) {                                                       //
        (0, _check.check)(ideaId, String);                                                              // 74
        (0, _check.check)(text, String);                                                                // 75
                                                                                                        //
        if (!this.userId) {                                                                             // 77
          throw new Meteor.Error('not-authorized');                                                     // 78
        }                                                                                               //
                                                                                                        //
        var idea = _ideas.Ideas.findOne(ideaId);                                                        // 81
        if (!idea) {                                                                                    // 82
          throw new Meteor.Error('idea-not-found');                                                     // 83
        }                                                                                               //
                                                                                                        //
        var userEmail = Meteor.user().emails[0].address;                                                // 86
                                                                                                        //
        IdeaComments.insert({ ideaId: ideaId, text: text, createdAt: Date.now(), ownerId: this.userId, ownerName: userEmail });
      }                                                                                                 //
                                                                                                        //
      return ideaCommentsInsert;                                                                        //
    }(),                                                                                                //
    'idea-comments.update': function () {                                                               // 90
      function ideaCommentsUpdate(commentId, text) {                                                    //
        (0, _check.check)(commentId, String);                                                           // 91
        (0, _check.check)(text, String);                                                                // 92
                                                                                                        //
        var comment = IdeaComments.findOne(commentId);                                                  // 94
        if (!comment) {                                                                                 // 95
          throw new Meteor.Error('idea-comment-not-found');                                             // 96
        }                                                                                               //
                                                                                                        //
        if (!this.userId && comment.ownerId !== this.userId) {                                          // 99
          throw new Meteor.Error('not-authorized');                                                     // 100
        }                                                                                               //
                                                                                                        //
        IdeaComments.update(commentId, { $set: { text: text } });                                       // 103
      }                                                                                                 //
                                                                                                        //
      return ideaCommentsUpdate;                                                                        //
    }(),                                                                                                //
    'idea-comments.remove': function () {                                                               // 106
      function ideaCommentsRemove(commentId) {                                                          //
        (0, _check.check)(commentId, String);                                                           // 107
                                                                                                        //
        var comment = IdeaComments.findOne(commentId);                                                  // 109
                                                                                                        //
        if (!this.userId && comment.ownerId !== this.userId) {                                          // 111
          throw new Meteor.Error('not-authorized');                                                     // 112
        }                                                                                               //
                                                                                                        //
        IdeaComments.remove(commentId);                                                                 // 115
      }                                                                                                 //
                                                                                                        //
      return ideaCommentsRemove;                                                                        //
    }()                                                                                                 //
  });                                                                                                   //
}                                                                                                       //
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ideas.js":["meteor/mongo","meteor/check",function(require,exports){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// imports/api/ideas.js                                                                                 //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
exports.__esModule = true;                                                                              //
exports.Ideas = undefined;                                                                              //
                                                                                                        //
var _mongo = require('meteor/mongo');                                                                   // 1
                                                                                                        //
var _check = require('meteor/check');                                                                   // 3
                                                                                                        //
var Ideas = exports.Ideas = new _mongo.Mongo.Collection('ideas');                                       // 2
                                                                                                        //
                                                                                                        //
Ideas.schema = new SimpleSchema({                                                                       // 5
  name: {                                                                                               // 6
    type: String                                                                                        // 7
  },                                                                                                    //
  businessValue: {                                                                                      // 9
    type: String                                                                                        // 10
  },                                                                                                    //
  definitionOfSuccess: {                                                                                // 12
    type: String                                                                                        // 13
  },                                                                                                    //
  isFundingRequired: {                                                                                  // 15
    type: Boolean,                                                                                      // 16
    optional: true,                                                                                     // 17
    defaultValue: false                                                                                 // 18
  },                                                                                                    //
  requiredFund: {                                                                                       // 20
    type: Number,                                                                                       // 21
    optional: true,                                                                                     // 22
    defaultValue: 0                                                                                     // 23
  },                                                                                                    //
  createdAt: {                                                                                          // 25
    type: Date                                                                                          // 26
  },                                                                                                    //
  ownerId: {                                                                                            // 28
    type: String,                                                                                       // 29
    regEx: SimpleSchema.RegEx.Id                                                                        // 30
  },                                                                                                    //
  ownerName: {                                                                                          // 32
    type: String                                                                                        // 33
  },                                                                                                    //
  comments: {                                                                                           // 35
    type: Number,                                                                                       // 36
    optional: true,                                                                                     // 37
    defaultValue: 0                                                                                     // 38
  },                                                                                                    //
  upVotes: {                                                                                            // 40
    type: Number,                                                                                       // 41
    optional: true,                                                                                     // 42
    defaultValue: 0                                                                                     // 43
  },                                                                                                    //
  downVotes: {                                                                                          // 45
    type: Number,                                                                                       // 46
    optional: true,                                                                                     // 47
    defaultValue: 0                                                                                     // 48
  }                                                                                                     //
});                                                                                                     //
                                                                                                        //
Ideas.publicKeys = ['name', 'description', 'createdAt', 'teamId', 'ownerId', 'ownerName'];              // 52
                                                                                                        //
if (Meteor.isServer) {                                                                                  // 54
  Meteor.publish('ideas.public', function () {                                                          // 55
    return Ideas.find({}, { sort: { createdAt: -1 } });                                                 // 56
  });                                                                                                   //
  Meteor.publish('ideas.public.findOne', function (ideaId) {                                            // 58
    return Ideas.find({ _id: ideaId });                                                                 // 59
  });                                                                                                   //
                                                                                                        //
  Meteor.methods({                                                                                      // 62
    'ideas.insert': function () {                                                                       // 63
      function ideasInsert(args) {                                                                      //
        (0, _check.check)(args, Object);                                                                // 64
                                                                                                        //
        if (!this.userId) {                                                                             // 66
          throw new Meteor.Error('not-authorized');                                                     // 67
        }                                                                                               //
                                                                                                        //
        var userEmail = Meteor.user().emails[0].address;                                                // 70
                                                                                                        //
        var idea = {                                                                                    // 72
          name: args.name,                                                                              // 73
          businessValue: args.businessValue,                                                            // 74
          definitionOfSuccess: args.definitionOfSuccess,                                                // 75
          isFundingRequired: args.isFundingRequired,                                                    // 76
          requiredFund: args.requiredFund,                                                              // 77
          createdAt: new Date(),                                                                        // 78
          ownerId: this.userId,                                                                         // 79
          ownerName: userEmail                                                                          // 80
        };                                                                                              //
                                                                                                        //
        Ideas.schema.validate(idea);                                                                    // 83
                                                                                                        //
        Ideas.insert(idea);                                                                             // 85
      }                                                                                                 //
                                                                                                        //
      return ideasInsert;                                                                               //
    }(),                                                                                                //
    'ideas.calcComments': function () {                                                                 // 87
      function ideasCalcComments(ideaId) {                                                              //
        // Make sure the user is logged in before inserting a task                                      //
        if (!this.userId) {                                                                             // 89
          throw new Meteor.Error('not-authorized');                                                     // 90
        }                                                                                               //
                                                                                                        //
        var idea = Ideas.findOne(ideaId);                                                               // 93
                                                                                                        //
        if (!idea) {                                                                                    // 95
          throw new Meteor.Error('idea-not-found');                                                     // 96
        }                                                                                               //
                                                                                                        //
        var commentsCount = Meteor.call('idea-comments.getCount', ideaId);                              // 99
        Ideas.update(ideaId, { $set: { comments: commentsCount } });                                    // 100
      }                                                                                                 //
                                                                                                        //
      return ideasCalcComments;                                                                         //
    }(),                                                                                                //
    'ideas.calcVotes': function () {                                                                    // 102
      function ideasCalcVotes(ideaId) {                                                                 //
        // Make sure the user is logged in before inserting a task                                      //
        if (!this.userId) {                                                                             // 104
          throw new Meteor.Error('not-authorized');                                                     // 105
        }                                                                                               //
                                                                                                        //
        var idea = Ideas.findOne(ideaId);                                                               // 108
                                                                                                        //
        if (!idea) {                                                                                    // 110
          throw new Meteor.Error('idea-not-found');                                                     // 111
        }                                                                                               //
                                                                                                        //
        var stats = Meteor.call('votes.getStats', ideaId);                                              // 114
        Ideas.update(ideaId, { $set: stats });                                                          // 115
      }                                                                                                 //
                                                                                                        //
      return ideasCalcVotes;                                                                            //
    }(),                                                                                                //
    'ideas.update': function () {                                                                       // 118
      function ideasUpdate(ideaId, data) {                                                              //
        (0, _check.check)(data, Object);                                                                // 119
        (0, _check.check)(data.name, String);                                                           // 120
        (0, _check.check)(data.description, String);                                                    // 121
                                                                                                        //
        var idea = Ideas.findOne(ideaId);                                                               // 123
                                                                                                        //
        if (!this.userId && idea.ownerId !== this.userId) {                                             // 125
          throw new Meteor.Error('not-authorized');                                                     // 126
        }                                                                                               //
                                                                                                        //
        Ideas.update(ideaId, { $set: { name: name, description: description } });                       // 129
      }                                                                                                 //
                                                                                                        //
      return ideasUpdate;                                                                               //
    }(),                                                                                                //
    'ideas.remove': function () {                                                                       // 131
      function ideasRemove(ideaId) {                                                                    //
        (0, _check.check)(ideaId, String);                                                              // 132
                                                                                                        //
        var idea = Ideas.findOne(ideaId);                                                               // 134
                                                                                                        //
        if (!this.userId && idea.ownerId !== this.userId) {                                             // 136
          throw new Meteor.Error('not-authorized');                                                     // 137
        }                                                                                               //
                                                                                                        //
        Ideas.remove(ideaId);                                                                           // 140
      }                                                                                                 //
                                                                                                        //
      return ideasRemove;                                                                               //
    }()                                                                                                 //
  });                                                                                                   //
}                                                                                                       //
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"votes.js":["meteor/mongo","meteor/check",function(require,exports){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// imports/api/votes.js                                                                                 //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
exports.__esModule = true;                                                                              //
exports.Votes = undefined;                                                                              //
                                                                                                        //
var _mongo = require('meteor/mongo');                                                                   // 1
                                                                                                        //
var _check = require('meteor/check');                                                                   // 2
                                                                                                        //
var Votes = exports.Votes = new _mongo.Mongo.Collection('votes');                                       // 4
                                                                                                        //
function getVotesCount(ideaId, isUpvote) {                                                              // 6
    return Votes.find({ idea: ideaId, isUpVote: isUpvote }).count();                                    // 7
}                                                                                                       //
                                                                                                        //
Meteor.methods({                                                                                        // 11
    'votes.getStats': function () {                                                                     // 12
        function votesGetStats(ideaId) {                                                                //
            return { upVotes: getVotesCount(ideaId, true), downVotes: getVotesCount(ideaId, false) };   // 13
        }                                                                                               //
                                                                                                        //
        return votesGetStats;                                                                           //
    }(),                                                                                                //
    'votes.cast': function () {                                                                         // 15
        function votesCast(ideaId, isUpVote) {                                                          //
                                                                                                        //
            (0, _check.check)(isUpVote, Boolean);                                                       // 17
                                                                                                        //
            if (!this.userId) {                                                                         // 19
                throw new Meteor.Error('not-authorized');                                               // 20
            }                                                                                           //
                                                                                                        //
            var castedVote = Votes.findOne({ idea: ideaId, user: this.userId });                        // 24
            if (!castedVote) {                                                                          // 25
                Votes.insert({ idea: ideaId, user: this.userId, isUpVote: isUpVote });                  // 26
            } else {                                                                                    //
                Votes.update(castedVote._id, { $set: { idea: ideaId, isUpVote: isUpVote } });           // 28
            }                                                                                           //
                                                                                                        //
            Meteor.call('ideas.calcVotes', ideaId);                                                     // 31
        }                                                                                               //
                                                                                                        //
        return votesCast;                                                                               //
    }()                                                                                                 //
});                                                                                                     //
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["../imports/api/ideas.js","../imports/api/votes.js","../imports/api/idea-comments.js",function(require){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// server/main.js                                                                                       //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
require('../imports/api/ideas.js');                                                                     // 1
                                                                                                        //
require('../imports/api/votes.js');                                                                     // 2
                                                                                                        //
require('../imports/api/idea-comments.js');                                                             // 3
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
