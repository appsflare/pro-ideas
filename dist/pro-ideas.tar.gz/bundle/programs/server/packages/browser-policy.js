(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['browser-policy'] = {};

})();
