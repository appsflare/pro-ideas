(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var check = Package.check.check;
var Match = Package.check.Match;
var HTTP = Package.http.HTTP;
var HTTPInternals = Package.http.HTTPInternals;
var ECMAScript = Package.ecmascript.ECMAScript;
var ReactMeteorData = Package['react-meteor-data'].ReactMeteorData;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var ValidatedMethod = Package['mdg:validated-method'].ValidatedMethod;
var ValidationError = Package['mdg:validation-error'].ValidationError;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var _ = Package.underscore._;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Collection2 = Package['aldeed:collection2-core'].Collection2;
var Autoupdate = Package.autoupdate.Autoupdate;

var require = meteorInstall({"node_modules":{"meteor":{"pro-ideas:kanban":{"api":{"index.js":["./taskstates/methods.js","./taskstates/server/publications.js","./tasks/methods.js","./tasks/server/publications.js","./boards/boards.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/pro-ideas_kanban/api/index.js                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.import('./taskstates/methods.js');module.import('./taskstates/server/publications.js');module.import('./tasks/methods.js');module.import('./tasks/server/publications.js');module.import('./boards/boards.js');
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      // 5
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"kanban.js":["babel-runtime/helpers/classCallCheck","./boards/boards",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/pro-ideas_kanban/api/kanban.js                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var Boards;module.import('./boards/boards',{"Boards":function(v){Boards=v}});
                                                                                                                      // 1
                                                                                                                      //
var Kanban = function () {                                                                                            //
    function Kanban() {                                                                                               //
        _classCallCheck(this, Kanban);                                                                                //
    }                                                                                                                 //
                                                                                                                      //
    Kanban.getBoardId = function getBoardId(integrationId) {                                                          //
                                                                                                                      //
        var user = Meteor.user();                                                                                     // 7
        if (!user) {                                                                                                  // 8
            throw new Error('not-authorized');                                                                        // 9
        }                                                                                                             // 10
                                                                                                                      //
        var board = Boards.findOne({ integrationId: integrationId });                                                 // 12
                                                                                                                      //
        if (board) {                                                                                                  // 14
            return board._id;                                                                                         // 15
        }                                                                                                             // 16
                                                                                                                      //
        return Boards.insert({ integrationId: integrationId, ownerId: user._id });                                    // 18
    };                                                                                                                // 19
                                                                                                                      //
    return Kanban;                                                                                                    //
}();                                                                                                                  //
                                                                                                                      //
module.export("default",exports.default=(Kanban));                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"boards":{"boards.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/aldeed:simple-schema","meteor/factory","./boardsTaskStatesDenormalizer",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/pro-ideas_kanban/api/boards/boards.js                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({Boards:function(){return Boards}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Factory;module.import('meteor/factory',{"Factory":function(v){Factory=v}});var boardsTaskStatesDenormalizer;module.import('./boardsTaskStatesDenormalizer',{"default":function(v){boardsTaskStatesDenormalizer=v}});
                                                                                                                      //
                                                                                                                      //
                                                                                                                      // 1
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      //
var BoardsCollection = function (_Mongo$Collection) {                                                                 //
    _inherits(BoardsCollection, _Mongo$Collection);                                                                   //
                                                                                                                      //
    function BoardsCollection() {                                                                                     //
        _classCallCheck(this, BoardsCollection);                                                                      //
                                                                                                                      //
        return _possibleConstructorReturn(this, _Mongo$Collection.apply(this, arguments));                            //
    }                                                                                                                 //
                                                                                                                      //
    BoardsCollection.prototype.insert = function insert(board, callback) {                                            //
        var result = _Mongo$Collection.prototype.insert.call(this, board, callback);                                  // 8
        boardsTaskStatesDenormalizer.afterInsertBoard({ _id: result, integrationId: board.integrationId });           // 9
        return result;                                                                                                // 10
    };                                                                                                                // 11
                                                                                                                      //
    BoardsCollection.prototype.remove = function remove(selector, callback) {                                         //
        return _Mongo$Collection.prototype.remove.call(this, selector, callback);                                     // 13
    };                                                                                                                // 14
                                                                                                                      //
    return BoardsCollection;                                                                                          //
}(Mongo.Collection);                                                                                                  //
                                                                                                                      //
var Boards = new BoardsCollection('kanaban-boards');                                                                  // 17
                                                                                                                      //
// Deny all client-side updates since we will be using methods to manage this collection                              //
Boards.deny({                                                                                                         // 20
    insert: function insert() {                                                                                       // 21
        return true;                                                                                                  // 21
    },                                                                                                                // 21
    update: function update() {                                                                                       // 22
        return true;                                                                                                  // 22
    },                                                                                                                // 22
    remove: function remove() {                                                                                       // 23
        return true;                                                                                                  // 23
    }                                                                                                                 // 23
});                                                                                                                   // 20
                                                                                                                      //
Boards.schema = new SimpleSchema({                                                                                    // 26
    integrationId: {                                                                                                  // 27
        type: String,                                                                                                 // 28
        regEx: SimpleSchema.RegEx.Id                                                                                  // 29
    },                                                                                                                // 27
    ownerId: {                                                                                                        // 31
        type: String,                                                                                                 // 32
        regEx: SimpleSchema.RegEx.Id                                                                                  // 33
    }                                                                                                                 // 31
});                                                                                                                   // 26
                                                                                                                      //
Boards.attachSchema(Boards.schema);                                                                                   // 37
                                                                                                                      //
Boards.publicFields = {                                                                                               // 39
    integrationId: 1,                                                                                                 // 40
    ownerId: 1                                                                                                        // 41
};                                                                                                                    // 39
                                                                                                                      //
Factory.define('Board', Boards, {});                                                                                  // 44
                                                                                                                      //
Boards.helpers({                                                                                                      // 46
    isPrivate: function isPrivate() {                                                                                 // 47
        return !!this.ownerId;                                                                                        // 48
    },                                                                                                                // 49
    editableBy: function editableBy(userId) {                                                                         // 50
        if (!this.ownerId) {                                                                                          // 51
            return true;                                                                                              // 52
        }                                                                                                             // 53
                                                                                                                      //
        return this.ownerId === userId;                                                                               // 55
    }                                                                                                                 // 56
});                                                                                                                   // 46
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"boardsTaskStatesDenormalizer.js":["../taskstates/taskstates",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/pro-ideas_kanban/api/boards/boardsTaskStatesDenormalizer.js                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var TaskStates;module.import('../taskstates/taskstates',{"TaskStates":function(v){TaskStates=v}});                    // 1
                                                                                                                      //
var boardsTaskStatesDenormalizer = {                                                                                  // 3
    afterInsertBoard: function afterInsertBoard(board) {                                                              // 5
                                                                                                                      //
        var states = [{                                                                                               // 7
            name: 'Todo',                                                                                             // 9
            description: '',                                                                                          // 10
            tasks: 0,                                                                                                 // 11
            order: 0                                                                                                  // 12
        }, {                                                                                                          // 8
            name: 'In Progress',                                                                                      // 15
            description: '',                                                                                          // 16
            tasks: 0,                                                                                                 // 17
            order: 1                                                                                                  // 18
        }, {                                                                                                          // 14
            name: 'Review',                                                                                           // 21
            description: '',                                                                                          // 22
            tasks: 0,                                                                                                 // 23
            order: 2                                                                                                  // 24
        }, {                                                                                                          // 20
            name: 'Done',                                                                                             // 27
            description: '',                                                                                          // 28
            tasks: 0,                                                                                                 // 29
            order: 3                                                                                                  // 30
        }];                                                                                                           // 26
                                                                                                                      //
        var user = Meteor.user();                                                                                     // 34
                                                                                                                      //
        states.forEach(function (state) {                                                                             // 36
            state.boardId = board._id;                                                                                // 37
            state.createdAt = Date.now();                                                                             // 38
            state.ownerId = user._id;                                                                                 // 39
            TaskStates.insert(state);                                                                                 // 40
        });                                                                                                           // 41
        return true;                                                                                                  // 42
    }                                                                                                                 // 43
};                                                                                                                    // 3
                                                                                                                      //
module.export("default",exports.default=(boardsTaskStatesDenormalizer));                                              // 47
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"tasks":{"methods.js":["meteor/meteor","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","meteor/underscore","./tasks.js","../taskstates/taskstates.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/pro-ideas_kanban/api/tasks/methods.js                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({insert:function(){return insert},updateTitle:function(){return updateTitle},updateState:function(){return updateState},remove:function(){return remove}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Tasks;module.import('./tasks.js',{"Tasks":function(v){Tasks=v}});var TaskStates;module.import('../taskstates/taskstates.js',{"TaskStates":function(v){TaskStates=v}});
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      // 5
                                                                                                                      //
                                                                                                                      // 7
                                                                                                                      // 8
                                                                                                                      //
var validations = {                                                                                                   // 10
    validateTaskTitle: function validateTaskTitle(title) {                                                            // 11
        // const count = title && title.length                                                                        //
        // if (count > 1) {                                                                                           //
        //     throw new Meteor.Error('task.name.alreadyExist', 'Task with the specified name already exist')         //
        // }                                                                                                          //
    }                                                                                                                 // 16
};                                                                                                                    // 10
                                                                                                                      //
var TASK_ID_ONLY = new SimpleSchema({                                                                                 // 20
    taskId: { type: String }                                                                                          // 21
}).validator();                                                                                                       // 20
                                                                                                                      //
var insert = new ValidatedMethod({                                                                                    // 24
    name: 'tasks.insert',                                                                                             // 25
    validate: new SimpleSchema({                                                                                      // 26
        title: { type: String },                                                                                      // 27
        details: { type: String, optional: true },                                                                    // 28
        state: { type: String }                                                                                       // 29
    }).validator(),                                                                                                   // 26
    run: function run(_ref) {                                                                                         // 31
        var title = _ref.title;                                                                                       // 31
        var details = _ref.details;                                                                                   // 31
        var state = _ref.state;                                                                                       // 31
                                                                                                                      //
        if (!this.userId) {                                                                                           // 32
            throw new Error('not-authorized');                                                                        // 32
        }                                                                                                             // 32
                                                                                                                      //
        validations.validateTaskTitle(title);                                                                         // 34
                                                                                                                      //
        var createdBy = this.userId;                                                                                  // 36
        var createdAt = Date.now();                                                                                   // 37
                                                                                                                      //
        return Tasks.insert({ title: title, details: details, state: state, createdAt: createdAt, createdBy: createdBy });
    }                                                                                                                 // 40
});                                                                                                                   // 24
                                                                                                                      //
var updateTitle = new ValidatedMethod({                                                                               // 43
    name: 'tasks.update',                                                                                             // 44
    validate: new SimpleSchema({                                                                                      // 45
        taskId: { type: String },                                                                                     // 46
        title: { type: String, optional: true }                                                                       // 47
    }).validator(),                                                                                                   // 45
    run: function run(_ref2) {                                                                                        // 49
        var taskId = _ref2.taskId;                                                                                    // 49
        var title = _ref2.title;                                                                                      // 49
        var details = _ref2.details;                                                                                  // 49
                                                                                                                      //
                                                                                                                      //
        var task = Tasks.findOne(taskId);                                                                             // 51
                                                                                                                      //
        if (!task.editableBy(this.userId)) {                                                                          // 53
            throw new Meteor.Error('lanes.update.accessDenied', "You don't have permission to edit this lane.");      // 54
        }                                                                                                             // 56
                                                                                                                      //
        if (title && task.title !== title) {                                                                          // 58
            validations.validateTaskTitle(title);                                                                     // 59
        }                                                                                                             // 60
        // XXX the security check above is not atomic, so in theory a race condition could                            //
        // result in exposing private data                                                                            //
                                                                                                                      //
        Tasks.update(taskId, {                                                                                        // 64
            $set: { title: title }                                                                                    // 65
        });                                                                                                           // 64
    }                                                                                                                 // 67
});                                                                                                                   // 43
                                                                                                                      //
var updateState = new ValidatedMethod({                                                                               // 70
    name: 'tasks.updateState',                                                                                        // 71
    validate: new SimpleSchema({                                                                                      // 72
        taskId: { type: String },                                                                                     // 73
        stateId: { type: String }                                                                                     // 74
    }).validator(),                                                                                                   // 72
    run: function run(_ref3) {                                                                                        // 76
        var taskId = _ref3.taskId;                                                                                    // 76
        var stateId = _ref3.stateId;                                                                                  // 76
                                                                                                                      //
                                                                                                                      //
        var task = Tasks.findOne(taskId);                                                                             // 78
                                                                                                                      //
        if (!task.editableBy(this.userId)) {                                                                          // 80
            throw new Meteor.Error('tasks.update.accessDenied', "You don't have permission to edit this task.");      // 81
        }                                                                                                             // 83
                                                                                                                      //
        var taskState = TaskStates.findOne(stateId);                                                                  // 85
                                                                                                                      //
        if (!taskState || !taskState.editableBy(this.userId)) {                                                       // 87
            throw new Meteor.Error('tasks.updateState.invalidState', 'invalid state');                                // 88
        }                                                                                                             // 89
                                                                                                                      //
        // XXX the security check above is not atomic, so in theory a race condition could                            //
        // result in exposing private data                                                                            //
                                                                                                                      //
        Tasks.update(taskId, {                                                                                        // 94
            $set: { state: stateId }                                                                                  // 95
        });                                                                                                           // 94
    }                                                                                                                 // 97
});                                                                                                                   // 70
                                                                                                                      //
var remove = new ValidatedMethod({                                                                                    // 100
    name: 'lanes.remove',                                                                                             // 101
    validate: TASK_ID_ONLY,                                                                                           // 102
    run: function run(_ref4) {                                                                                        // 103
        var taskId = _ref4.taskId;                                                                                    // 103
                                                                                                                      //
        var task = Tasks.findOne(taskId);                                                                             // 104
                                                                                                                      //
        if (!task.editableBy(this.userId)) {                                                                          // 106
            throw new Meteor.Error('ideas.remove.accessDenied', "You don't have permission to remove this idea.");    // 107
        }                                                                                                             // 109
                                                                                                                      //
        Tasks.remove(taskId);                                                                                         // 111
    }                                                                                                                 // 112
});                                                                                                                   // 100
                                                                                                                      //
// Get list of all method names on ideas                                                                              //
var tasks_METHODS = _.pluck([insert, updateTitle, remove], 'name');                                                   // 116
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 122
    // Only allow 5 list operations per connection per second                                                         //
    DDPRateLimiter.addRule({                                                                                          // 124
        name: function name(_name) {                                                                                  // 125
            return _.contains(tasks_METHODS, _name);                                                                  // 126
        },                                                                                                            // 127
                                                                                                                      //
                                                                                                                      //
        // Rate limit per connection ID                                                                               //
        connectionId: function connectionId() {                                                                       // 130
            return true;                                                                                              // 130
        }                                                                                                             // 130
    }, 5, 1000);                                                                                                      // 124
}                                                                                                                     // 132
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"tasks.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/aldeed:simple-schema","meteor/factory",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/pro-ideas_kanban/api/tasks/tasks.js                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({Tasks:function(){return Tasks}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Factory;module.import('meteor/factory',{"Factory":function(v){Factory=v}});
                                                                                                                      //
                                                                                                                      //
                                                                                                                      // 1
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      //
var TasksCollection = function (_Mongo$Collection) {                                                                  //
  _inherits(TasksCollection, _Mongo$Collection);                                                                      //
                                                                                                                      //
  function TasksCollection() {                                                                                        //
    _classCallCheck(this, TasksCollection);                                                                           //
                                                                                                                      //
    return _possibleConstructorReturn(this, _Mongo$Collection.apply(this, arguments));                                //
  }                                                                                                                   //
                                                                                                                      //
  TasksCollection.prototype.insert = function insert(lane, callback) {                                                //
    return _Mongo$Collection.prototype.insert.call(this, lane, callback);                                             // 7
  };                                                                                                                  // 8
                                                                                                                      //
  TasksCollection.prototype.remove = function remove(selector, callback) {                                            //
    return _Mongo$Collection.prototype.remove.call(this, selector, callback);                                         // 10
  };                                                                                                                  // 11
                                                                                                                      //
  return TasksCollection;                                                                                             //
}(Mongo.Collection);                                                                                                  //
                                                                                                                      //
var Tasks = new TasksCollection('kanaban-tasks');                                                                     // 14
                                                                                                                      //
// Deny all client-side updates since we will be using methods to manage this collection                              //
Tasks.deny({                                                                                                          // 17
  insert: function insert() {                                                                                         // 18
    return true;                                                                                                      // 18
  },                                                                                                                  // 18
  update: function update() {                                                                                         // 19
    return true;                                                                                                      // 19
  },                                                                                                                  // 19
  remove: function remove() {                                                                                         // 20
    return true;                                                                                                      // 20
  }                                                                                                                   // 20
});                                                                                                                   // 17
                                                                                                                      //
Tasks.schema = new SimpleSchema({                                                                                     // 23
  title: {                                                                                                            // 24
    type: String                                                                                                      // 25
  },                                                                                                                  // 24
  details: {                                                                                                          // 27
    type: String,                                                                                                     // 28
    defaultValue: ''                                                                                                  // 29
  },                                                                                                                  // 27
  createdAt: {                                                                                                        // 31
    type: Date                                                                                                        // 32
  },                                                                                                                  // 31
  updatedAt: {                                                                                                        // 34
    type: Date,                                                                                                       // 35
    optional: true                                                                                                    // 36
  },                                                                                                                  // 34
  createdBy: {                                                                                                        // 38
    type: String,                                                                                                     // 39
    regEx: SimpleSchema.RegEx.Id                                                                                      // 40
  },                                                                                                                  // 38
  lockedBy: {                                                                                                         // 42
    type: String,                                                                                                     // 43
    optional: true,                                                                                                   // 44
    regEx: SimpleSchema.RegEx.Id                                                                                      // 45
  },                                                                                                                  // 42
  state: {                                                                                                            // 47
    type: SimpleSchema.RegEx.Id                                                                                       // 48
  }                                                                                                                   // 47
});                                                                                                                   // 23
                                                                                                                      //
Tasks.attachSchema(Tasks.schema);                                                                                     // 52
                                                                                                                      //
Tasks.publicFields = {                                                                                                // 54
  title: 1,                                                                                                           // 55
  details: 1,                                                                                                         // 56
  state: 1,                                                                                                           // 57
  createdBy: 1,                                                                                                       // 58
  lockedBy: 1,                                                                                                        // 59
  createdAt: 1,                                                                                                       // 60
  updatedAt: 1,                                                                                                       // 61
  ownerId: 1                                                                                                          // 62
};                                                                                                                    // 54
                                                                                                                      //
Factory.define('Task', Tasks, {});                                                                                    // 65
                                                                                                                      //
Tasks.helpers({                                                                                                       // 67
  // A Idea is considered to be private if it has a userId set                                                        //
                                                                                                                      //
  isLocked: function isLocked() {                                                                                     // 69
    return !!this.lockedBy;                                                                                           // 70
  },                                                                                                                  // 71
  editableBy: function editableBy(userId) {                                                                           // 72
    return this.lockedBy ? this.lockedBy === userId : this.createdBy === userId;                                      // 73
  }                                                                                                                   // 74
});                                                                                                                   // 67
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"server":{"publications.js":["meteor/meteor","../tasks.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/pro-ideas_kanban/api/tasks/server/publications.js                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Tasks;module.import('../tasks.js',{"Tasks":function(v){Tasks=v}});/* eslint-disable prefer-arrow-callback */
                                                                                                                      //
                                                                                                                      // 3
                                                                                                                      //
                                                                                                                      // 5
                                                                                                                      //
Meteor.publish('tasks.public', function (stateIds) {                                                                  // 7
    return Tasks.find({ laneId: { $in: stateIds } }, { fields: Tasks.publicFields, sort: { createdAt: -1 } });        // 8
});                                                                                                                   // 9
Meteor.publish('tasks.public.findOne', function (taskId) {                                                            // 10
    return Tasks.find({ _id: taskId }, { fields: Tasks.publicFields });                                               // 11
});                                                                                                                   // 12
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"taskstates":{"methods.js":["meteor/meteor","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","meteor/underscore","../boards/boards","./taskstates.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/pro-ideas_kanban/api/taskstates/methods.js                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({insert:function(){return insert},update:function(){return update},remove:function(){return remove}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Boards;module.import('../boards/boards',{"Boards":function(v){Boards=v}});var TaskStates;module.import('./taskstates.js',{"TaskStates":function(v){TaskStates=v}});
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      // 5
                                                                                                                      //
                                                                                                                      // 7
                                                                                                                      // 8
                                                                                                                      //
var validations = {                                                                                                   // 10
    validateBoard: function validateBoard(boardId) {                                                                  // 11
        if (Boards.find({ _id: boardId }).count() > 0) {                                                              // 12
            throw new Meteor.Error('taskstate.invalid.board', 'Invalid board');                                       // 13
        }                                                                                                             // 14
    },                                                                                                                // 15
    validateLaneName: function validateLaneName(name) {                                                               // 16
        var count = TaskStates.find({ name: name }).count();                                                          // 17
        if (count > 1) {                                                                                              // 18
            throw new Meteor.Error('taskstate.name.alreadyExist', 'Lane with the specified name already exist');      // 19
        }                                                                                                             // 20
    }                                                                                                                 // 21
};                                                                                                                    // 10
                                                                                                                      //
var LANE_ID_ONLY = new SimpleSchema({                                                                                 // 26
    laneId: { type: String }                                                                                          // 27
}).validator();                                                                                                       // 26
                                                                                                                      //
var insert = new ValidatedMethod({                                                                                    // 30
    name: 'taskstates.insert',                                                                                        // 31
    validate: new SimpleSchema({                                                                                      // 32
        boardId: { type: String, regEx: SimpleSchema.RegEx.Id },                                                      // 33
        name: { type: String, optional: true },                                                                       // 34
        description: { type: String, optional: true }                                                                 // 35
    }).validator(),                                                                                                   // 32
    run: function run(_ref) {                                                                                         // 37
        var boardId = _ref.boardId;                                                                                   // 37
        var name = _ref.name;                                                                                         // 37
        var description = _ref.description;                                                                           // 37
        var _ref$tasks = _ref.tasks;                                                                                  // 37
        var tasks = _ref$tasks === undefined ? 0 : _ref$tasks;                                                        // 37
                                                                                                                      //
        if (!this.userId) {                                                                                           // 38
            throw new Error('not-authorized');                                                                        // 38
        }                                                                                                             // 38
                                                                                                                      //
        validations.validateBoard(boardId);                                                                           // 40
                                                                                                                      //
        validations.validateLaneName(name);                                                                           // 42
                                                                                                                      //
        var ownerId = this.userId;                                                                                    // 44
        var createdAt = Date.now();                                                                                   // 45
                                                                                                                      //
        return TaskStates.insert({ name: name, description: description, tasks: tasks, ownerId: ownerId, createdAt: createdAt });
    }                                                                                                                 // 48
});                                                                                                                   // 30
                                                                                                                      //
var update = new ValidatedMethod({                                                                                    // 51
    name: 'taskstates.update',                                                                                        // 52
    validate: new SimpleSchema({                                                                                      // 53
        laneId: { type: String, optional: true },                                                                     // 54
        name: { type: String, optional: true },                                                                       // 55
        description: { type: String, optional: true }                                                                 // 56
    }).validator(),                                                                                                   // 53
    run: function run(_ref2) {                                                                                        // 58
        var laneId = _ref2.laneId;                                                                                    // 58
        var name = _ref2.name;                                                                                        // 58
        var description = _ref2.description;                                                                          // 58
                                                                                                                      //
                                                                                                                      //
        var lane = TaskStates.findOne(laneId);                                                                        // 60
                                                                                                                      //
        if (!lane.editableBy(this.userId)) {                                                                          // 62
            throw new Meteor.Error('taskstates.update.accessDenied', "You don't have permission to edit this lane.");
        }                                                                                                             // 65
                                                                                                                      //
        if (lane.name !== data.name) {                                                                                // 67
            validations.validateLaneName(name);                                                                       // 68
        }                                                                                                             // 69
        // XXX the security check above is not atomic, so in theory a race condition could                            //
        // result in exposing private data                                                                            //
                                                                                                                      //
        TaskStates.update(laneId, {                                                                                   // 73
            $set: { name: name, description: description }                                                            // 74
        });                                                                                                           // 73
    }                                                                                                                 // 76
});                                                                                                                   // 51
                                                                                                                      //
var remove = new ValidatedMethod({                                                                                    // 79
    name: 'taskstates.remove',                                                                                        // 80
    validate: LANE_ID_ONLY,                                                                                           // 81
    run: function run(_ref3) {                                                                                        // 82
        var laneId = _ref3.laneId;                                                                                    // 82
                                                                                                                      //
        var idea = TaskStates.findOne(laneId);                                                                        // 83
                                                                                                                      //
        if (!idea.editableBy(this.userId)) {                                                                          // 85
            throw new Meteor.Error('taskstates.remove.accessDenied', "You don't have permission to remove this idea.");
        }                                                                                                             // 88
                                                                                                                      //
        TaskStates.remove(laneId);                                                                                    // 90
    }                                                                                                                 // 91
});                                                                                                                   // 79
                                                                                                                      //
// Get list of all method names on ideas                                                                              //
var lanes_METHODS = _.pluck([insert, update, remove], 'name');                                                        // 95
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 101
    // Only allow 5 list operations per connection per second                                                         //
    DDPRateLimiter.addRule({                                                                                          // 103
        name: function name(_name) {                                                                                  // 104
            return _.contains(lanes_METHODS, _name);                                                                  // 105
        },                                                                                                            // 106
                                                                                                                      //
                                                                                                                      //
        // Rate limit per connection ID                                                                               //
        connectionId: function connectionId() {                                                                       // 109
            return true;                                                                                              // 109
        }                                                                                                             // 109
    }, 5, 1000);                                                                                                      // 103
}                                                                                                                     // 111
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"taskstates.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/aldeed:simple-schema","meteor/factory","../tasks/tasks",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/pro-ideas_kanban/api/taskstates/taskstates.js                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({TaskStates:function(){return TaskStates}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Factory;module.import('meteor/factory',{"Factory":function(v){Factory=v}});var Tasks;module.import('../tasks/tasks',{"Tasks":function(v){Tasks=v}});
                                                                                                                      //
                                                                                                                      //
                                                                                                                      // 1
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      //
var TaskStatesCollection = function (_Mongo$Collection) {                                                             //
  _inherits(TaskStatesCollection, _Mongo$Collection);                                                                 //
                                                                                                                      //
  function TaskStatesCollection() {                                                                                   //
    _classCallCheck(this, TaskStatesCollection);                                                                      //
                                                                                                                      //
    return _possibleConstructorReturn(this, _Mongo$Collection.apply(this, arguments));                                //
  }                                                                                                                   //
                                                                                                                      //
  TaskStatesCollection.prototype.insert = function insert(lane, callback) {                                           //
    return _Mongo$Collection.prototype.insert.call(this, lane, callback);                                             // 9
  };                                                                                                                  // 10
                                                                                                                      //
  TaskStatesCollection.prototype.remove = function remove(selector, callback) {                                       //
    return _Mongo$Collection.prototype.remove.call(this, selector, callback);                                         // 12
  };                                                                                                                  // 13
                                                                                                                      //
  return TaskStatesCollection;                                                                                        //
}(Mongo.Collection);                                                                                                  //
                                                                                                                      //
var TaskStates = new TaskStatesCollection('kanaban-taskstates');                                                      // 16
                                                                                                                      //
// Deny all client-side updates since we will be using methods to manage this collection                              //
TaskStates.deny({                                                                                                     // 19
  insert: function insert() {                                                                                         // 20
    return true;                                                                                                      // 20
  },                                                                                                                  // 20
  update: function update() {                                                                                         // 21
    return true;                                                                                                      // 21
  },                                                                                                                  // 21
  remove: function remove() {                                                                                         // 22
    return true;                                                                                                      // 22
  }                                                                                                                   // 22
});                                                                                                                   // 19
                                                                                                                      //
TaskStates.schema = new SimpleSchema({                                                                                // 25
  name: {                                                                                                             // 26
    type: String                                                                                                      // 27
  },                                                                                                                  // 26
  description: {                                                                                                      // 29
    type: String,                                                                                                     // 30
    defaultValue: ''                                                                                                  // 31
  },                                                                                                                  // 29
  order: {                                                                                                            // 33
    type: Number                                                                                                      // 34
  },                                                                                                                  // 33
  createdAt: {                                                                                                        // 36
    type: Date                                                                                                        // 37
  },                                                                                                                  // 36
  updatedAt: {                                                                                                        // 39
    type: Date,                                                                                                       // 40
    optional: true                                                                                                    // 41
  },                                                                                                                  // 39
  boardId: {                                                                                                          // 43
    type: String,                                                                                                     // 44
    regEx: SimpleSchema.RegEx.Id                                                                                      // 45
  },                                                                                                                  // 43
  ownerId: {                                                                                                          // 47
    type: String,                                                                                                     // 48
    regEx: SimpleSchema.RegEx.Id                                                                                      // 49
  },                                                                                                                  // 47
  tasks: {                                                                                                            // 51
    type: Number,                                                                                                     // 52
    optional: true,                                                                                                   // 53
    defaultValue: 0                                                                                                   // 54
  }                                                                                                                   // 51
});                                                                                                                   // 25
                                                                                                                      //
TaskStates.attachSchema(TaskStates.schema);                                                                           // 58
                                                                                                                      //
TaskStates.publicFields = {                                                                                           // 60
  name: 1,                                                                                                            // 61
  description: 1,                                                                                                     // 62
  order: 1,                                                                                                           // 63
  tasks: 1,                                                                                                           // 64
  createdAt: 1,                                                                                                       // 65
  updatedAt: 1,                                                                                                       // 66
  boardId: 1,                                                                                                         // 67
  ownerId: 1                                                                                                          // 68
};                                                                                                                    // 60
                                                                                                                      //
Factory.define('TaskState', TaskStates, {});                                                                          // 71
                                                                                                                      //
TaskStates.helpers({                                                                                                  // 73
  // A Idea is considered to be private if it has a userId set                                                        //
                                                                                                                      //
  isPrivate: function isPrivate() {                                                                                   // 75
    return !!this.ownerId;                                                                                            // 76
  },                                                                                                                  // 77
  editableBy: function editableBy(userId) {                                                                           // 78
    if (!this.ownerId) {                                                                                              // 79
      return true;                                                                                                    // 80
    }                                                                                                                 // 81
                                                                                                                      //
    return this.ownerId === userId;                                                                                   // 83
  },                                                                                                                  // 84
  tasks: function tasks() {                                                                                           // 85
    return Tasks.find({ laneId: this._id }, { sort: { createdAt: -1 } });                                             // 86
  }                                                                                                                   // 87
});                                                                                                                   // 73
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"server":{"publications.js":["meteor/meteor","../taskstates.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/pro-ideas_kanban/api/taskstates/server/publications.js                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var TaskStates;module.import('../taskstates.js',{"TaskStates":function(v){TaskStates=v}});/* eslint-disable prefer-arrow-callback */
                                                                                                                      //
                                                                                                                      // 3
                                                                                                                      //
                                                                                                                      // 5
                                                                                                                      //
Meteor.publish('taskstates.public', function (boardId) {                                                              // 7
    return TaskStates.find({ boardId: boardId }, { fields: TaskStates.publicFields, sort: { order: 1 } });            // 8
});                                                                                                                   // 9
Meteor.publish('taskstates.public.findOne', function (id) {                                                           // 10
    return TaskStates.find({ _id: id }, { fields: TaskStates.publicFields });                                         // 11
});                                                                                                                   // 12
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/pro-ideas:kanban/api/index.js");
var exports = require("./node_modules/meteor/pro-ideas:kanban/api/kanban.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['pro-ideas:kanban'] = exports;

})();

//# sourceMappingURL=pro-ideas_kanban.js.map
