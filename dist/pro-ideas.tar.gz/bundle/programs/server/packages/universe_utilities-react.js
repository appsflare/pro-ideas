(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var EJSON = Package.ejson.EJSON;
var ECMAScript = Package.ecmascript.ECMAScript;
var UniUtils = Package['universe:utilities'].UniUtils;
var UniConfig = Package['universe:utilities'].UniConfig;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"universe:utilities-react":{"index.js":["./mixins/autorun","./mixins/subscription","./mixins/dualLink","./helpers/execution-environment",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/universe_utilities-react/index.js                                                                      //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({AutorunMixin:function(){return AutorunMixin},SubscriptionMixin:function(){return SubscriptionMixin},DualLinkMixin:function(){return DualLinkMixin},executionEnvironment:function(){return executionEnvironment}});var AutorunMixin;module.import('./mixins/autorun',{"default":function(v){AutorunMixin=v}});var SubscriptionMixin;module.import('./mixins/subscription',{"default":function(v){SubscriptionMixin=v}});var DualLinkMixin;module.import('./mixins/dualLink',{"default":function(v){DualLinkMixin=v}});var executionEnvironment;module.import('./helpers/execution-environment',{"default":function(v){executionEnvironment=v}});//export {default as DualLinkMixin} from './mixins/dualLink';
//export {default as classNames} from './helpers/classnames';                                                      // 2
//export {default as executionEnvironment} from './helpers/execution-environment';                                 // 3
//export {default as objectAssign} from './helpers/object-assign';                                                 // 4
//export {default as deepEqual} from './helpers/deep-equal';                                                       // 5
//export {default as deepExtend} from './helpers/deep-extend';                                                     // 6
//export {default as cloneWithProps} from './helpers/react-clonewithprops';                                        // 7
                                                                                                                   //
/*                                                                                                                 // 9
 Re-exporting doesn't work as of Meteor 1.3b4                                                                      //
 Please enable mixins/helpers when you're sure that they work and are still needed in Meteor 1.3!                  //
 */                                                                                                                //
                                                                                                                   //
                                                                                                                   // 14
                                                                                                                   // 15
                                                                                                                   // 16
                                                                                                                   // 17
                                                                                                                   //
                                                                                                                   // 20
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"helpers":{"execution-environment.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/universe_utilities-react/helpers/execution-environment.js                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var canUseDOM = !!(typeof window !== 'undefined' && window.document && window.document.createElement);             // 1
                                                                                                                   //
module.export("default",exports.default=({                                                                         // 7
                                                                                                                   //
    canUseDOM: canUseDOM,                                                                                          // 9
                                                                                                                   //
    canUseWorkers: typeof Worker !== 'undefined',                                                                  // 11
                                                                                                                   //
    canUseEventListeners: canUseDOM && !!(window.addEventListener || window.attachEvent),                          // 13
                                                                                                                   //
    canUseViewport: canUseDOM && !!window.screen                                                                   // 16
                                                                                                                   //
}));                                                                                                               // 7
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"mixins":{"autorun.js":["meteor/tracker",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/universe_utilities-react/mixins/autorun.js                                                             //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var Tracker;module.import('meteor/tracker',{"Tracker":function(v){Tracker=v}});                                    // 1
                                                                                                                   //
var AutorunMixin = {                                                                                               // 3
    componentWillMount: function () {                                                                              // 4
        function componentWillMount() {                                                                            // 3
            var _this = this;                                                                                      // 4
                                                                                                                   //
            var _loop = function () {                                                                              // 4
                function _loop(method) {                                                                           // 4
                    if (_this.hasOwnProperty(method) && method.indexOf('autorun', 0) === 0) {                      // 6
                        var methodComputation = method + 'Computation';                                            // 7
                                                                                                                   //
                        if (_this[methodComputation] === undefined) {                                              // 9
                            _this[methodComputation] = Tracker.nonreactive(function () {                           // 10
                                // we put this inside nonreactive to be sure that it won't be related to any other computation
                                return Tracker.autorun(_this[method]);                                             // 12
                            });                                                                                    // 13
                        }                                                                                          // 14
                    }                                                                                              // 15
                }                                                                                                  // 4
                                                                                                                   //
                return _loop;                                                                                      // 4
            }();                                                                                                   // 4
                                                                                                                   //
            for (var method in meteorBabelHelpers.sanitizeForInObject(this)) {                                     // 5
                _loop(method);                                                                                     // 5
            }                                                                                                      // 16
        }                                                                                                          // 17
                                                                                                                   //
        return componentWillMount;                                                                                 // 3
    }(),                                                                                                           // 3
    componentWillUnmount: function () {                                                                            // 19
        function componentWillUnmount() {                                                                          // 3
            for (var method in meteorBabelHelpers.sanitizeForInObject(this)) {                                     // 20
                if (this.hasOwnProperty(method) && method.indexOf('autorun', 0) === 0) {                           // 21
                    var methodComputation = method + 'Computation';                                                // 22
                                                                                                                   //
                    if (this[methodComputation]) {                                                                 // 24
                        this[methodComputation].stop();                                                            // 25
                        this[methodComputation] = null;                                                            // 26
                    }                                                                                              // 27
                }                                                                                                  // 28
            }                                                                                                      // 29
        }                                                                                                          // 30
                                                                                                                   //
        return componentWillUnmount;                                                                               // 3
    }()                                                                                                            // 3
};                                                                                                                 // 3
                                                                                                                   //
module.export("default",exports.default=(AutorunMixin));                                                           // 33
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"dualLink.js":["babel-runtime/helpers/typeof","babel-runtime/helpers/classCallCheck","meteor/universe:utilities",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/universe_utilities-react/mixins/dualLink.js                                                            //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var _typeof;module.import('babel-runtime/helpers/typeof',{"default":function(v){_typeof=v}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var UniUtils;module.import('meteor/universe:utilities',{"UniUtils":function(v){UniUtils=v}});
                                                                                                                   //
                                                                                                                   // 1
                                                                                                                   //
var DualLinkMixin = {                                                                                              // 3
    componentWillMount: function () {                                                                              // 4
        function componentWillMount() {                                                                            // 3
            this._dualLinks = {};                                                                                  // 5
        }                                                                                                          // 6
                                                                                                                   //
        return componentWillMount;                                                                                 // 3
    }(),                                                                                                           // 3
    dualLink: function () {                                                                                        // 8
        function dualLink() {                                                                                      // 3
            var linkName = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'default';          // 8
                                                                                                                   //
            if (this._dualLinks[linkName]) {                                                                       // 9
                // get DualLink from cache                                                                         // 10
                return this._dualLinks[linkName];                                                                  // 11
            }                                                                                                      // 12
                                                                                                                   //
            // create new DualLink                                                                                 // 14
            return this._dualLinks[linkName] = new DualLink(this, linkName);                                       // 15
        }                                                                                                          // 16
                                                                                                                   //
        return dualLink;                                                                                           // 3
    }()                                                                                                            // 3
};                                                                                                                 // 3
                                                                                                                   //
var DualLink = function () {                                                                                       //
    function DualLink(component, name) {                                                                           // 20
        _classCallCheck(this, DualLink);                                                                           // 20
                                                                                                                   //
        check(name, String);                                                                                       // 21
                                                                                                                   //
        this.name = name;                                                                                          // 23
        this.component = component;                                                                                // 24
                                                                                                                   //
        this._setState('local', {});                                                                               // 26
        this._setState('remote', {});                                                                              // 27
    }                                                                                                              // 28
                                                                                                                   //
    DualLink.prototype._getStateName = function () {                                                               //
        function _getStateName(type) {                                                                             //
            return '_dualLink_' + this.name + '_' + type;                                                          // 31
        }                                                                                                          // 32
                                                                                                                   //
        return _getStateName;                                                                                      //
    }();                                                                                                           //
                                                                                                                   //
    DualLink.prototype._getState = function () {                                                                   //
        function _getState(type) {                                                                                 //
            return this.component.state[this._getStateName(type)];                                                 // 35
        }                                                                                                          // 36
                                                                                                                   //
        return _getState;                                                                                          //
    }();                                                                                                           //
                                                                                                                   //
    DualLink.prototype._setState = function () {                                                                   //
        function _setState(type, field, value) {                                                                   //
            if (typeof field === 'string' && value !== undefined) {                                                // 39
                var _component$setState;                                                                           // 39
                                                                                                                   //
                // set/update only one field                                                                       // 41
                this.component.setState((_component$setState = {}, _component$setState[this._getStateName(type)] = UniUtils.set(this._getState(type), field, value), _component$setState));
            } else if ((typeof field === 'undefined' ? 'undefined' : _typeof(field)) === 'object' && value === undefined) {
                var _component$setState2;                                                                          // 46
                                                                                                                   //
                // set whole object, in this case our value is in field argument                                   // 48
                this.component.setState((_component$setState2 = {}, _component$setState2[this._getStateName(type)] = field, _component$setState2));
            } else if (field === undefined && value === undefined) {                                               // 53
                                                                                                                   //
                // subscription helper                                                                             // 55
                                                                                                                   //
            } else {                                                                                               // 57
                console.warn('[DualLinkMixin] Invalid set params', { type: type, field: field, value: value });    // 58
            }                                                                                                      // 59
        }                                                                                                          // 60
                                                                                                                   //
        return _setState;                                                                                          //
    }();                                                                                                           //
                                                                                                                   //
    DualLink.prototype.getLocal = function () {                                                                    //
        function getLocal(field) {                                                                                 //
            return field ? UniUtils.get(this._getState('local'), field) : this._getState('local');                 // 63
        }                                                                                                          // 64
                                                                                                                   //
        return getLocal;                                                                                           //
    }();                                                                                                           //
                                                                                                                   //
    DualLink.prototype.getRemote = function () {                                                                   //
        function getRemote(field) {                                                                                //
            return field ? UniUtils.get(this._getState('remote'), field) : this._getState('remote');               // 67
        }                                                                                                          // 68
                                                                                                                   //
        return getRemote;                                                                                          //
    }();                                                                                                           //
                                                                                                                   //
    DualLink.prototype.get = function () {                                                                         //
        function get(field) {                                                                                      //
            if (field) {                                                                                           // 71
                // return only one field                                                                           // 72
                                                                                                                   //
                var local = this.getLocal(field);                                                                  // 74
                if (local !== undefined) {                                                                         // 75
                    // local can be also e.g. empty string                                                         // 76
                    return local;                                                                                  // 77
                }                                                                                                  // 78
                                                                                                                   //
                return this.getRemote(field);                                                                      // 80
            }                                                                                                      // 81
                                                                                                                   //
            // return whole object                                                                                 // 83
            return $.extend(true, {}, this.getRemote(), this.getLocal());                                          // 84
        }                                                                                                          // 85
                                                                                                                   //
        return get;                                                                                                //
    }();                                                                                                           //
                                                                                                                   //
    DualLink.prototype.isEmpty = function () {                                                                     //
        function isEmpty() {                                                                                       //
            return _.isEmpty(this.get());                                                                          // 88
        }                                                                                                          // 89
                                                                                                                   //
        return isEmpty;                                                                                            //
    }();                                                                                                           //
                                                                                                                   //
    DualLink.prototype.setLocal = function () {                                                                    //
        function setLocal(field, value) {                                                                          //
            this._setState('local', field, value);                                                                 // 92
        }                                                                                                          // 93
                                                                                                                   //
        return setLocal;                                                                                           //
    }();                                                                                                           //
                                                                                                                   //
    DualLink.prototype.setRemote = function () {                                                                   //
        function setRemote(field, value) {                                                                         //
            this._setState('remote', field, value);                                                                // 96
        }                                                                                                          // 97
                                                                                                                   //
        return setRemote;                                                                                          //
    }();                                                                                                           //
                                                                                                                   //
    DualLink.prototype.clear = function () {                                                                       //
        function clear() {                                                                                         //
            this.setLocal({});                                                                                     // 100
        }                                                                                                          // 101
                                                                                                                   //
        return clear;                                                                                              //
    }();                                                                                                           //
                                                                                                                   //
    DualLink.prototype.valueLink = function () {                                                                   //
        function valueLink(field) {                                                                                //
            var _this = this;                                                                                      // 103
                                                                                                                   //
            return {                                                                                               // 104
                value: this.get(field),                                                                            // 105
                requestChange: function () {                                                                       // 106
                    function requestChange(value) {                                                                // 106
                        return _this.setLocal(field, value);                                                       // 106
                    }                                                                                              // 106
                                                                                                                   //
                    return requestChange;                                                                          // 106
                }()                                                                                                // 106
            };                                                                                                     // 104
        }                                                                                                          // 108
                                                                                                                   //
        return valueLink;                                                                                          //
    }();                                                                                                           //
                                                                                                                   //
    return DualLink;                                                                                               //
}();                                                                                                               //
                                                                                                                   //
module.export("default",exports.default=(DualLinkMixin));                                                          // 111
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"subscription.js":["babel-runtime/helpers/toConsumableArray","meteor/meteor","meteor/ejson",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/universe_utilities-react/mixins/subscription.js                                                        //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var _toConsumableArray;module.import('babel-runtime/helpers/toConsumableArray',{"default":function(v){_toConsumableArray=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var EJSON;module.import('meteor/ejson',{"EJSON":function(v){EJSON=v}});
                                                                                                                   // 1
                                                                                                                   // 2
                                                                                                                   //
var SubscriptionMixin = {                                                                                          // 4
    getInitialState: function () {                                                                                 // 5
        function getInitialState() {                                                                               // 4
            return {};                                                                                             // 6
        }                                                                                                          // 7
                                                                                                                   //
        return getInitialState;                                                                                    // 4
    }(),                                                                                                           // 4
    componentWillMount: function () {                                                                              // 8
        function componentWillMount() {                                                                            // 4
            this.subscriptions = {};                                                                               // 9
        }                                                                                                          // 10
                                                                                                                   //
        return componentWillMount;                                                                                 // 4
    }(),                                                                                                           // 4
    componentWillUnmount: function () {                                                                            // 12
        function componentWillUnmount() {                                                                          // 4
            this.subscriptionsStop();                                                                              // 13
        }                                                                                                          // 14
                                                                                                                   //
        return componentWillUnmount;                                                                               // 4
    }(),                                                                                                           // 4
    subscribe: function () {                                                                                       // 16
        function subscribe(subscription) {                                                                         // 4
            var _this = this;                                                                                      // 16
                                                                                                                   //
            var cb = void 0;                                                                                       // 17
                                                                                                                   //
            for (var _len = arguments.length, params = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
                params[_key - 1] = arguments[_key];                                                                // 16
            }                                                                                                      // 16
                                                                                                                   //
            if (Array.isArray(params) && params.length && typeof params[params.length - 1] === 'function') {       // 19
                cb = params.pop();                                                                                 // 20
            }                                                                                                      // 21
                                                                                                                   //
            var handleId = '__SubscriptionMixin_' + subscription + '_' + EJSON.stringify(params);                  // 23
            var handle = Meteor.subscribe.apply(Meteor, [subscription].concat(_toConsumableArray(params), [{       // 24
                onReady: function () {                                                                             // 25
                    function onReady() {                                                                           // 25
                        var _this$setState;                                                                        // 25
                                                                                                                   //
                        _this.setState((_this$setState = {}, _this$setState[handleId] = 'ready', _this$setState));
                        cb && cb();                                                                                // 27
                    }                                                                                              // 28
                                                                                                                   //
                    return onReady;                                                                                // 25
                }(),                                                                                               // 25
                                                                                                                   //
                onStop: function () {                                                                              // 30
                    function onStop(err) {                                                                         // 30
                        var _this$setState2;                                                                       // 30
                                                                                                                   //
                        _this.setState((_this$setState2 = {}, _this$setState2[handleId] = 'stopped', _this$setState2));
                                                                                                                   //
                        delete _this.subscriptions[subscription][handleId];                                        // 33
                    }                                                                                              // 34
                                                                                                                   //
                    return onStop;                                                                                 // 30
                }()                                                                                                // 30
            }]));                                                                                                  // 24
                                                                                                                   //
            this.subscriptions[subscription] = this.subscriptions[subscription] || {};                             // 38
            this.subscriptions[subscription][handleId] = handle;                                                   // 39
                                                                                                                   //
            return handle;                                                                                         // 41
        }                                                                                                          // 42
                                                                                                                   //
        return subscribe;                                                                                          // 4
    }(),                                                                                                           // 4
    subscriptionReady: function () {                                                                               // 44
        function subscriptionReady(subscription, handleId) {                                                       // 4
            if (handleId) {                                                                                        // 45
                var handle = this.subscriptions[subscription][handleId];                                           // 46
                return handle && handle.ready();                                                                   // 47
            }                                                                                                      // 48
                                                                                                                   //
            return _(this.subscriptions[subscription] || {}).every(function (handle) {                             // 50
                return handle.ready();                                                                             // 50
            });                                                                                                    // 50
        }                                                                                                          // 51
                                                                                                                   //
        return subscriptionReady;                                                                                  // 4
    }(),                                                                                                           // 4
    subscriptionsReady: function () {                                                                              // 53
        function subscriptionsReady() {                                                                            // 4
            return _.every(this.subscriptions, function (handlers) {                                               // 54
                return _(handlers).every(function (handle) {                                                       // 54
                    return handle.ready();                                                                         // 54
                });                                                                                                // 54
            });                                                                                                    // 54
        }                                                                                                          // 55
                                                                                                                   //
        return subscriptionsReady;                                                                                 // 4
    }(),                                                                                                           // 4
    subscriptionsStop: function () {                                                                               // 57
        function subscriptionsStop() {                                                                             // 4
            return _.each(this.subscriptions, function (handlers) {                                                // 58
                return _(handlers).forEach(function (handle) {                                                     // 58
                    return handle.stop();                                                                          // 58
                });                                                                                                // 58
            });                                                                                                    // 58
        }                                                                                                          // 59
                                                                                                                   //
        return subscriptionsStop;                                                                                  // 4
    }(),                                                                                                           // 4
    subscriptionStop: function () {                                                                                // 61
        function subscriptionStop(subscription, handleId) {                                                        // 4
            if (handleId) {                                                                                        // 62
                var handle = this.subscriptions[subscription][handleId];                                           // 63
                return handle && handle.stop();                                                                    // 64
            }                                                                                                      // 65
                                                                                                                   //
            return _(this.subscriptions[subscription] || {}).every(function (handle) {                             // 67
                return handle.stop();                                                                              // 67
            });                                                                                                    // 67
        }                                                                                                          // 68
                                                                                                                   //
        return subscriptionStop;                                                                                   // 4
    }()                                                                                                            // 4
};                                                                                                                 // 4
                                                                                                                   //
module.export("default",exports.default=(SubscriptionMixin));                                                      // 71
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}}}},{"extensions":[".js",".json",".jsx"]});
var exports = require("./node_modules/meteor/universe:utilities-react/index.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['universe:utilities-react'] = exports;

})();

//# sourceMappingURL=universe_utilities-react.js.map
