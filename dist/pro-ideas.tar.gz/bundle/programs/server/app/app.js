var require = meteorInstall({"imports":{"api":{"idea-comments":{"server":{"publications.js":["meteor/meteor","meteor/aldeed:simple-schema","../idea-comments",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/idea-comments/server/publications.js                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var IdeaComments;module.import('../idea-comments',{"IdeaComments":function(v){IdeaComments=v}});/* eslint-disable prefer-arrow-callback */
                                                                                                                      //
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      //
                                                                                                                      // 6
                                                                                                                      //
Meteor.publish('idea-comments.public', function (ideaId) {                                                            // 8
  check(ideaId, String);                                                                                              // 9
  return IdeaComments.find({ ideaId: ideaId }, { sort: { createdAt: -1 } });                                          // 10
});                                                                                                                   // 11
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"commentsCountDenormalizer.js":["meteor/underscore","meteor/check","./idea-comments.js","../ideas/ideas.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/idea-comments/commentsCountDenormalizer.js                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _;module.import('meteor/underscore',{"_":function(v){_=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var IdeaComments;module.import('./idea-comments.js',{"IdeaComments":function(v){IdeaComments=v}});var Ideas;module.import('../ideas/ideas.js',{"Ideas":function(v){Ideas=v}});
                                                                                                                      // 2
                                                                                                                      //
                                                                                                                      // 4
                                                                                                                      // 5
                                                                                                                      //
var commentsCountDenormalizer = {                                                                                     // 7
  _updateIdea: function _updateIdea(ideaId) {                                                                         // 8
    // Recalculate the correct incomplete count direct from MongoDB                                                   //
    var comments = IdeaComments.find({ ideaId: ideaId }).count();                                                     // 10
                                                                                                                      //
    Ideas.update(ideaId, { $set: { comments: comments } });                                                           // 12
  },                                                                                                                  // 13
  afterInsertComment: function afterInsertComment(comment) {                                                          // 14
    this._updateIdea(comment.ideaId);                                                                                 // 15
  },                                                                                                                  // 16
  afterUpdateComment: function afterUpdateComment(selector, modifier) {                                               // 17
    // We only support very limited operations on todos                                                               //
    check(modifier, { $set: Object });                                                                                // 19
  },                                                                                                                  // 21
                                                                                                                      //
  // Here we need to take the list of todos being removed, selected *before* the update                               //
  // because otherwise we can't figure out the relevant list id(s) (if the todo has been deleted)                     //
  afterRemoveComments: function afterRemoveComments(comments) {                                                       // 24
    var _this = this;                                                                                                 // 24
                                                                                                                      //
    comments.forEach(function (comment) {                                                                             // 25
      return _this._updateIdea(comment.ideaId);                                                                       // 25
    });                                                                                                               // 25
  }                                                                                                                   // 26
};                                                                                                                    // 7
                                                                                                                      //
module.export("default",exports.default=(commentsCountDenormalizer));                                                 // 29
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"idea-comments.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/factory","faker","./commentsCountDenormalizer","meteor/aldeed:simple-schema","../ideas/ideas",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/idea-comments/idea-comments.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({IdeaComments:function(){return IdeaComments}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var Factory;module.import('meteor/factory',{"Factory":function(v){Factory=v}});var faker;module.import('faker',{"default":function(v){faker=v}});var commentsCountDenormalizer;module.import('./commentsCountDenormalizer',{"default":function(v){commentsCountDenormalizer=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Ideas;module.import('../ideas/ideas',{"Ideas":function(v){Ideas=v}});
                                                                                                                      //
                                                                                                                      //
                                                                                                                      // 1
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      //
                                                                                                                      // 5
                                                                                                                      // 6
                                                                                                                      // 7
                                                                                                                      //
var IdeaCommentsCollection = function (_Mongo$Collection) {                                                           //
  _inherits(IdeaCommentsCollection, _Mongo$Collection);                                                               //
                                                                                                                      //
  function IdeaCommentsCollection() {                                                                                 //
    _classCallCheck(this, IdeaCommentsCollection);                                                                    //
                                                                                                                      //
    return _possibleConstructorReturn(this, _Mongo$Collection.apply(this, arguments));                                //
  }                                                                                                                   //
                                                                                                                      //
  IdeaCommentsCollection.prototype.insert = function insert(doc, callback) {                                          //
    var ourDoc = doc;                                                                                                 // 11
    ourDoc.createdAt = ourDoc.createdAt || new Date();                                                                // 12
    var result = _Mongo$Collection.prototype.insert.call(this, ourDoc, callback);                                     // 13
    commentsCountDenormalizer.afterInsertComment(ourDoc);                                                             // 14
    return result;                                                                                                    // 15
  };                                                                                                                  // 16
                                                                                                                      //
  IdeaCommentsCollection.prototype.update = function update(selector, modifier) {                                     //
    var result = _Mongo$Collection.prototype.update.call(this, selector, modifier);                                   // 18
    commentsCountDenormalizer.afterUpdateComment(selector, modifier);                                                 // 19
    return result;                                                                                                    // 20
  };                                                                                                                  // 21
                                                                                                                      //
  IdeaCommentsCollection.prototype.remove = function remove(selector) {                                               //
    var comments = this.find(selector).fetch();                                                                       // 23
    var result = _Mongo$Collection.prototype.remove.call(this, selector);                                             // 24
    commentsCountDenormalizer.afterRemoveComments(comments);                                                          // 25
    return result;                                                                                                    // 26
  };                                                                                                                  // 27
                                                                                                                      //
  return IdeaCommentsCollection;                                                                                      //
}(Mongo.Collection);                                                                                                  //
                                                                                                                      //
var IdeaComments = new IdeaCommentsCollection('idea-comments');                                                       // 30
                                                                                                                      //
IdeaComments.schema = new SimpleSchema({                                                                              // 32
  ideaId: {                                                                                                           // 33
    type: String,                                                                                                     // 34
    regEx: SimpleSchema.RegEx.Id,                                                                                     // 35
    denyUpdate: true                                                                                                  // 36
  },                                                                                                                  // 33
  text: {                                                                                                             // 38
    type: String                                                                                                      // 39
  },                                                                                                                  // 38
  createdAt: {                                                                                                        // 41
    type: Date,                                                                                                       // 42
    denyUpdate: true                                                                                                  // 43
  },                                                                                                                  // 41
  updatedOn: {                                                                                                        // 45
    type: Date,                                                                                                       // 46
    optional: true                                                                                                    // 47
  },                                                                                                                  // 45
  ownerId: {                                                                                                          // 49
    type: String,                                                                                                     // 50
    regEx: SimpleSchema.RegEx.Id,                                                                                     // 51
    denyUpdate: true                                                                                                  // 52
  },                                                                                                                  // 49
  ownerName: {                                                                                                        // 54
    type: String,                                                                                                     // 55
    denyUpdate: true                                                                                                  // 56
  }                                                                                                                   // 54
});                                                                                                                   // 32
                                                                                                                      //
// Deny all client-side updates since we will be using methods to manage this collection                              //
IdeaComments.deny({                                                                                                   // 61
  insert: function insert() {                                                                                         // 62
    return true;                                                                                                      // 62
  },                                                                                                                  // 62
  update: function update() {                                                                                         // 63
    return true;                                                                                                      // 63
  },                                                                                                                  // 63
  remove: function remove() {                                                                                         // 64
    return true;                                                                                                      // 64
  }                                                                                                                   // 64
});                                                                                                                   // 61
                                                                                                                      //
IdeaComments.attachSchema(IdeaComments.schema);                                                                       // 68
                                                                                                                      //
// This represents the keys from Lists objects that should be published                                               //
// to the client. If we add secret properties to List objects, don't list                                             //
// them here to keep them private to the server.                                                                      //
IdeaComments.publicFields = {                                                                                         // 73
  ideaId: 1,                                                                                                          // 74
  text: 1,                                                                                                            // 75
  ownerId: 1,                                                                                                         // 76
  ownerName: 1                                                                                                        // 77
};                                                                                                                    // 73
                                                                                                                      //
// TODO This factory has a name - do we have a code style for this?                                                   //
//   - usually I've used the singular, sometimes you have more than one though, like                                  //
//   'todo', 'emptyTodo', 'checkedTodo'                                                                               //
Factory.define('idea-comment', IdeaComments, {                                                                        // 83
  ideaId: function ideaId() {                                                                                         // 84
    return Factory.get('ideas');                                                                                      // 84
  },                                                                                                                  // 84
  text: function text() {                                                                                             // 85
    return faker.lorem.sentence();                                                                                    // 85
  },                                                                                                                  // 85
  createdAt: function createdAt() {                                                                                   // 86
    return new Date();                                                                                                // 86
  }                                                                                                                   // 86
});                                                                                                                   // 83
                                                                                                                      //
IdeaComments.helpers({                                                                                                // 89
  getIdea: function getIdea() {                                                                                       // 90
    return Ideas.findOne(this.ideaId);                                                                                // 91
  },                                                                                                                  // 92
  editableBy: function editableBy(userId) {                                                                           // 93
    if (!this.ownerId) {                                                                                              // 94
      return true;                                                                                                    // 95
    }                                                                                                                 // 96
                                                                                                                      //
    return this.ownerId === userId;                                                                                   // 98
  }                                                                                                                   // 99
});                                                                                                                   // 89
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["meteor/meteor","meteor/underscore","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","./idea-comments","../ideas/ideas",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/idea-comments/methods.js                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({insert:function(){return insert},updateText:function(){return updateText},remove:function(){return remove}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var IdeaComments;module.import('./idea-comments',{"IdeaComments":function(v){IdeaComments=v}});var Ideas;module.import('../ideas/ideas',{"Ideas":function(v){Ideas=v}});
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      // 5
                                                                                                                      //
                                                                                                                      // 7
                                                                                                                      // 8
                                                                                                                      //
var insert = new ValidatedMethod({                                                                                    // 11
  name: 'idea-comments.insert',                                                                                       // 12
  validate: new SimpleSchema({                                                                                        // 13
    ideaId: { type: String },                                                                                         // 14
    text: { type: String }                                                                                            // 15
  }).validator(),                                                                                                     // 13
  run: function run(_ref) {                                                                                           // 17
    var ideaId = _ref.ideaId;                                                                                         // 17
    var text = _ref.text;                                                                                             // 17
                                                                                                                      //
    var list = Ideas.findOne(ideaId);                                                                                 // 18
                                                                                                                      //
    var idea = Ideas.findOne(ideaId);                                                                                 // 20
    if (!idea) {                                                                                                      // 21
      throw new Meteor.Error('idea-not-found');                                                                       // 22
    }                                                                                                                 // 23
                                                                                                                      //
    var ownerName = Meteor.user().profile.fullName;                                                                   // 25
                                                                                                                      //
    IdeaComments.insert({ ideaId: ideaId, text: text, ownerId: this.userId, ownerName: ownerName });                  // 27
  }                                                                                                                   // 28
});                                                                                                                   // 11
                                                                                                                      //
var updateText = new ValidatedMethod({                                                                                // 31
  name: 'idea-comments.updateText',                                                                                   // 32
  validate: new SimpleSchema({                                                                                        // 33
    commentId: { type: String },                                                                                      // 34
    text: { type: String }                                                                                            // 35
  }).validator(),                                                                                                     // 33
  run: function run(_ref2) {                                                                                          // 37
    var commentId = _ref2.commentId;                                                                                  // 37
    var text = _ref2.text;                                                                                            // 37
                                                                                                                      //
    // This is complex auth stuff - perhaps denormalizing a userId onto todos                                         //
    // would be correct here?                                                                                         //
    var ideaComment = IdeaComments.findOne(commentId);                                                                // 40
                                                                                                                      //
    if (!ideaComment.editableBy(this.userId)) {                                                                       // 42
      throw new Meteor.Error('ideaComments.updateText.accessDenied', 'Cannot edit comment that is not yours');        // 43
    }                                                                                                                 // 45
                                                                                                                      //
    var updatedOn = Date.now();                                                                                       // 47
                                                                                                                      //
    IdeaComments.update(commentId, {                                                                                  // 49
      $set: { text: text, updatedOn: updatedOn }                                                                      // 50
    });                                                                                                               // 49
  }                                                                                                                   // 52
});                                                                                                                   // 31
                                                                                                                      //
var remove = new ValidatedMethod({                                                                                    // 55
  name: 'idea-comments.remove',                                                                                       // 56
  validate: new SimpleSchema({                                                                                        // 57
    commentId: { type: String }                                                                                       // 58
  }).validator(),                                                                                                     // 57
  run: function run(_ref3) {                                                                                          // 60
    var commentId = _ref3.commentId;                                                                                  // 60
                                                                                                                      //
    var comment = IdeaComments.findOne(commentId);                                                                    // 61
                                                                                                                      //
    if (!comment.editableBy(this.userId)) {                                                                           // 63
      throw new Meteor.Error('ideaComments.remove.accessDenied', 'Cannot remove comment that is not yours');          // 64
    }                                                                                                                 // 66
                                                                                                                      //
    IdeaComments.remove(commentId);                                                                                   // 68
  }                                                                                                                   // 69
});                                                                                                                   // 55
                                                                                                                      //
// Get list of all method names on Todos                                                                              //
var IDEA_COMMENTS_METHODS = _.pluck([insert, updateText, remove], 'name');                                            // 73
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 79
  // Only allow 5 todos operations per connection per second                                                          //
  DDPRateLimiter.addRule({                                                                                            // 81
    name: function name(_name) {                                                                                      // 82
      return _.contains(IDEA_COMMENTS_METHODS, _name);                                                                // 83
    },                                                                                                                // 84
                                                                                                                      //
                                                                                                                      //
    // Rate limit per connection ID                                                                                   //
    connectionId: function connectionId() {                                                                           // 87
      return true;                                                                                                    // 87
    }                                                                                                                 // 87
  }, 5, 1000);                                                                                                        // 81
}                                                                                                                     // 89
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"ideas":{"server":{"publications.js":["meteor/meteor","../ideas.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/ideas/server/publications.js                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Ideas;module.import('../ideas.js',{"Ideas":function(v){Ideas=v}});/* eslint-disable prefer-arrow-callback */
                                                                                                                      //
                                                                                                                      // 3
                                                                                                                      //
                                                                                                                      // 5
                                                                                                                      //
Meteor.publish('ideas.public', function () {                                                                          // 7
  return Ideas.find({}, { fields: Ideas.publicFields, sort: { createdAt: -1 } });                                     // 8
});                                                                                                                   // 9
Meteor.publish('ideas.public.findOne', function (ideaId) {                                                            // 10
  return Ideas.find({ _id: ideaId }, { fields: Ideas.publicFields });                                                 // 11
});                                                                                                                   // 12
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"ideas.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/aldeed:simple-schema","meteor/factory","../teams/teams",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/ideas/ideas.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({Ideas:function(){return Ideas}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Factory;module.import('meteor/factory',{"Factory":function(v){Factory=v}});var Teams;module.import('../teams/teams',{"Teams":function(v){Teams=v}});
                                                                                                                      //
                                                                                                                      //
                                                                                                                      // 1
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      //
var IdeasCollection = function (_Mongo$Collection) {                                                                  //
  _inherits(IdeasCollection, _Mongo$Collection);                                                                      //
                                                                                                                      //
  function IdeasCollection() {                                                                                        //
    _classCallCheck(this, IdeasCollection);                                                                           //
                                                                                                                      //
    return _possibleConstructorReturn(this, _Mongo$Collection.apply(this, arguments));                                //
  }                                                                                                                   //
                                                                                                                      //
  IdeasCollection.prototype.insert = function insert(Idea, callback) {                                                //
    var ourIdea = Idea;                                                                                               // 8
    if (!ourIdea.name) {                                                                                              // 9
      var nextLetter = 'A';                                                                                           // 10
      ourIdea.name = 'Idea ' + nextLetter;                                                                            // 11
                                                                                                                      //
      while (!!this.findOne({ name: ourIdea.name })) {                                                                // 13
        // not going to be too smart here, can go past Z                                                              //
        nextLetter = String.fromCharCode(nextLetter.charCodeAt(0) + 1);                                               // 15
        ourIdea.name = 'Idea ' + nextLetter;                                                                          // 16
      }                                                                                                               // 17
    }                                                                                                                 // 18
                                                                                                                      //
    return _Mongo$Collection.prototype.insert.call(this, ourIdea, callback);                                          // 20
  };                                                                                                                  // 21
                                                                                                                      //
  IdeasCollection.prototype.remove = function remove(selector, callback) {                                            //
    return _Mongo$Collection.prototype.remove.call(this, selector, callback);                                         // 23
  };                                                                                                                  // 24
                                                                                                                      //
  return IdeasCollection;                                                                                             //
}(Mongo.Collection);                                                                                                  //
                                                                                                                      //
var Ideas = new IdeasCollection('Ideas');                                                                             // 27
                                                                                                                      //
// Deny all client-side updates since we will be using methods to manage this collection                              //
Ideas.deny({                                                                                                          // 30
  insert: function insert() {                                                                                         // 31
    return true;                                                                                                      // 31
  },                                                                                                                  // 31
  update: function update() {                                                                                         // 32
    return true;                                                                                                      // 32
  },                                                                                                                  // 32
  remove: function remove() {                                                                                         // 33
    return true;                                                                                                      // 33
  }                                                                                                                   // 33
});                                                                                                                   // 30
                                                                                                                      //
Ideas.schema = new SimpleSchema({                                                                                     // 36
  name: {                                                                                                             // 37
    type: String                                                                                                      // 38
  },                                                                                                                  // 37
  businessValue: {                                                                                                    // 40
    type: String,                                                                                                     // 41
    defaultValue: ''                                                                                                  // 42
  },                                                                                                                  // 40
  definitionOfSuccess: {                                                                                              // 44
    type: String,                                                                                                     // 45
    optional: true,                                                                                                   // 46
    defaultValue: ''                                                                                                  // 47
  },                                                                                                                  // 44
  fundingRequirement: {                                                                                               // 49
    type: String,                                                                                                     // 50
    optional: true,                                                                                                   // 51
    defaultValue: ''                                                                                                  // 52
  },                                                                                                                  // 49
  createdAt: {                                                                                                        // 54
    type: Date                                                                                                        // 55
  },                                                                                                                  // 54
  ownerId: {                                                                                                          // 57
    type: String,                                                                                                     // 58
    regEx: SimpleSchema.RegEx.Id                                                                                      // 59
  },                                                                                                                  // 57
  ownerName: {                                                                                                        // 61
    type: String                                                                                                      // 62
  },                                                                                                                  // 61
  status: {                                                                                                           // 64
    type: String,                                                                                                     // 65
    allowedValues: ['new', 'completed'],                                                                              // 66
    defaultValue: 'new'                                                                                               // 67
  },                                                                                                                  // 64
  kanbanBoardId: {                                                                                                    // 69
    type: String,                                                                                                     // 70
    regEx: SimpleSchema.RegEx.Id,                                                                                     // 71
    optional: true                                                                                                    // 72
  },                                                                                                                  // 69
  comments: {                                                                                                         // 74
    type: Number,                                                                                                     // 75
    optional: true,                                                                                                   // 76
    defaultValue: 0                                                                                                   // 77
  },                                                                                                                  // 74
  upVotes: {                                                                                                          // 79
    type: Number,                                                                                                     // 80
    optional: true,                                                                                                   // 81
    defaultValue: 0                                                                                                   // 82
  },                                                                                                                  // 79
  downVotes: {                                                                                                        // 84
    type: Number,                                                                                                     // 85
    optional: true,                                                                                                   // 86
    defaultValue: 0                                                                                                   // 87
  }                                                                                                                   // 84
});                                                                                                                   // 36
                                                                                                                      //
Ideas.attachSchema(Ideas.schema);                                                                                     // 91
                                                                                                                      //
Ideas.publicFields = {                                                                                                // 93
  name: 1,                                                                                                            // 94
  businessValue: 1,                                                                                                   // 95
  definitionOfSuccess: 1,                                                                                             // 96
  fundingRequirement: 1,                                                                                              // 97
  createdAt: 1,                                                                                                       // 98
  ownerId: 1,                                                                                                         // 99
  ownerName: 1,                                                                                                       // 100
  status: 1,                                                                                                          // 101
  kanbanBoardId: 1,                                                                                                   // 102
  comments: 1,                                                                                                        // 103
  upVotes: 1,                                                                                                         // 104
  downVotes: 1                                                                                                        // 105
};                                                                                                                    // 93
                                                                                                                      //
Factory.define('Idea', Ideas, {});                                                                                    // 108
                                                                                                                      //
Ideas.helpers({                                                                                                       // 110
  // A Idea is considered to be private if it has a userId set                                                        //
                                                                                                                      //
  isPrivate: function isPrivate() {                                                                                   // 112
    return !!this.ownerId;                                                                                            // 113
  },                                                                                                                  // 114
  isCompleted: function isCompleted() {                                                                               // 115
    return this.status === 'completed';                                                                               // 116
  },                                                                                                                  // 117
  getTeam: function getTeam() {                                                                                       // 118
    return Teams.find({ ideaId: this._id });                                                                          // 119
  },                                                                                                                  // 120
  hasKanbanBoard: function hasKanbanBoard(userId) {                                                                   // 121
    return !!this.kanbanBoardId;                                                                                      // 122
  },                                                                                                                  // 123
  editableBy: function editableBy(userId) {                                                                           // 124
    if (!this.ownerId) {                                                                                              // 125
      return true;                                                                                                    // 126
    }                                                                                                                 // 127
                                                                                                                      //
    return this.ownerId === userId;                                                                                   // 129
  },                                                                                                                  // 130
  comments: function comments() {                                                                                     // 131
    return Comments.find({ ideaId: this._id }, { sort: { createdAt: -1 } });                                          // 132
  }                                                                                                                   // 133
});                                                                                                                   // 110
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["meteor/meteor","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","meteor/underscore","meteor/pro-ideas:kanban","./ideas.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/ideas/methods.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({insert:function(){return insert},update:function(){return update},markAsCompleted:function(){return markAsCompleted},createKanbanBoard:function(){return createKanbanBoard},remove:function(){return remove}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Kanban;module.import('meteor/pro-ideas:kanban',{"default":function(v){Kanban=v}});var Ideas;module.import('./ideas.js',{"Ideas":function(v){Ideas=v}});
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      // 5
                                                                                                                      // 6
                                                                                                                      //
                                                                                                                      // 8
                                                                                                                      //
function validateIdeaName(name) {                                                                                     // 10
  var count = Ideas.find({ name: name }).count();                                                                     // 11
  if (count > 1) {                                                                                                    // 12
    throw new Meteor.Error('idea.name.alreadyExist', 'Idea with the specified name already exist');                   // 13
  }                                                                                                                   // 14
}                                                                                                                     // 15
                                                                                                                      //
var IDEA_ID_ONLY = new SimpleSchema({                                                                                 // 17
  ideaId: { type: String }                                                                                            // 18
}).validator();                                                                                                       // 17
                                                                                                                      //
var insert = new ValidatedMethod({                                                                                    // 21
  name: 'ideas.insert',                                                                                               // 22
  validate: new SimpleSchema({                                                                                        // 23
    name: { type: String, optional: true },                                                                           // 24
    businessValue: { type: String, optional: true },                                                                  // 25
    definitionOfSuccess: { type: String, optional: true },                                                            // 26
    fundingRequirement: { type: String, optional: true }                                                              // 27
  }).validator(),                                                                                                     // 23
  run: function run(newIdea) {                                                                                        // 29
    if (!this.userId) {                                                                                               // 30
      throw new Error('not-authorized');                                                                              // 30
    }                                                                                                                 // 30
                                                                                                                      //
    validateIdeaName(newIdea.name);                                                                                   // 32
                                                                                                                      //
    newIdea.ownerId = this.userId;                                                                                    // 34
    newIdea.ownerName = Meteor.user().profile.fullName;                                                               // 35
    newIdea.createdAt = Date.now();                                                                                   // 36
    return Ideas.insert(newIdea);                                                                                     // 37
  }                                                                                                                   // 38
});                                                                                                                   // 21
                                                                                                                      //
var update = new ValidatedMethod({                                                                                    // 41
  name: 'ideas.update',                                                                                               // 42
  validate: new SimpleSchema({                                                                                        // 43
    ideaId: { type: String },                                                                                         // 44
    name: { type: String, optional: true },                                                                           // 45
    businessValue: { type: String, optional: true },                                                                  // 46
    definitionOfSuccess: { type: String, optional: true },                                                            // 47
    fundingRequirement: { type: String, optional: true }                                                              // 48
  }).validator(),                                                                                                     // 43
  run: function run(data) {                                                                                           // 50
    var ideaId = data.ideaId;                                                                                         // 51
    var idea = Ideas.findOne(ideaId);                                                                                 // 52
                                                                                                                      //
    if (!idea.editableBy(this.userId)) {                                                                              // 54
      throw new Meteor.Error('ideas.update.accessDenied', "You don't have permission to edit this idea.");            // 55
    }                                                                                                                 // 57
                                                                                                                      //
    if (idea.name !== data.name) {                                                                                    // 59
      validateIdeaName(data.name);                                                                                    // 60
    }                                                                                                                 // 61
    // XXX the security check above is not atomic, so in theory a race condition could                                //
    // result in exposing private data                                                                                //
                                                                                                                      //
    Ideas.update(ideaId, {                                                                                            // 65
      $set: data                                                                                                      // 66
    });                                                                                                               // 65
  }                                                                                                                   // 68
});                                                                                                                   // 41
                                                                                                                      //
var markAsCompleted = new ValidatedMethod({                                                                           // 71
  name: 'ideas.markAsCompleted',                                                                                      // 72
  validate: IDEA_ID_ONLY,                                                                                             // 73
  run: function run(_ref) {                                                                                           // 74
    var ideaId = _ref.ideaId;                                                                                         // 74
                                                                                                                      //
    var idea = Ideas.findOne(ideaId);                                                                                 // 75
                                                                                                                      //
    if (!idea.editableBy(this.userId)) {                                                                              // 77
      throw new Meteor.Error('ideas.remove.accessDenied', "You don't have permission to mark this idea as completed.");
    }                                                                                                                 // 80
                                                                                                                      //
    Ideas.update(ideaId, {                                                                                            // 82
      $set: { status: 'completed' }                                                                                   // 83
    });                                                                                                               // 82
  }                                                                                                                   // 85
});                                                                                                                   // 71
                                                                                                                      //
var createKanbanBoard = new ValidatedMethod({                                                                         // 88
  name: 'ideas.createKanbanBoard',                                                                                    // 89
  validate: IDEA_ID_ONLY,                                                                                             // 90
  run: function run(_ref2) {                                                                                          // 91
    var ideaId = _ref2.ideaId;                                                                                        // 91
                                                                                                                      //
    var idea = Ideas.findOne(ideaId);                                                                                 // 92
                                                                                                                      //
    if (!idea.editableBy(this.userId)) {                                                                              // 94
      throw new Meteor.Error('ideas.viewKanban.accessDenied', "You don't have permission to view the kanban board.");
    }                                                                                                                 // 97
                                                                                                                      //
    if (idea.hasKanbanBoard()) {                                                                                      // 99
      return idea.kanbanBoardId;                                                                                      // 100
    }                                                                                                                 // 101
                                                                                                                      //
    if (Meteor.isServer) {                                                                                            // 103
      var kanbanBoardId = Kanban.getBoardId(idea._id);                                                                // 104
                                                                                                                      //
      Ideas.update(ideaId, {                                                                                          // 106
        $set: { kanbanBoardId: kanbanBoardId }                                                                        // 107
      });                                                                                                             // 106
                                                                                                                      //
      return kanbanBoardId;                                                                                           // 110
    }                                                                                                                 // 111
  }                                                                                                                   // 112
});                                                                                                                   // 88
                                                                                                                      //
var remove = new ValidatedMethod({                                                                                    // 115
  name: 'ideas.remove',                                                                                               // 116
  validate: IDEA_ID_ONLY,                                                                                             // 117
  run: function run(_ref3) {                                                                                          // 118
    var ideaId = _ref3.ideaId;                                                                                        // 118
                                                                                                                      //
    var idea = Ideas.findOne(ideaId);                                                                                 // 119
                                                                                                                      //
    if (!idea.editableBy(this.userId)) {                                                                              // 121
      throw new Meteor.Error('ideas.remove.accessDenied', "You don't have permission to remove this idea.");          // 122
    }                                                                                                                 // 124
                                                                                                                      //
    Ideas.remove(ideaId);                                                                                             // 126
  }                                                                                                                   // 127
});                                                                                                                   // 115
                                                                                                                      //
// Get list of all method names on ideas                                                                              //
var ideas_METHODS = _.pluck([insert, update, remove, markAsCompleted, createKanbanBoard], 'name');                    // 131
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 139
  // Only allow 5 list operations per connection per second                                                           //
  DDPRateLimiter.addRule({                                                                                            // 141
    name: function name(_name) {                                                                                      // 142
      return _.contains(ideas_METHODS, _name);                                                                        // 143
    },                                                                                                                // 144
                                                                                                                      //
                                                                                                                      //
    // Rate limit per connection ID                                                                                   //
    connectionId: function connectionId() {                                                                           // 147
      return true;                                                                                                    // 147
    }                                                                                                                 // 147
  }, 5, 1000);                                                                                                        // 141
}                                                                                                                     // 149
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"sprints":{"server":{"publications.js":["meteor/meteor","../sprints.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/sprints/server/publications.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Sprints;module.import('../sprints.js',{"Sprints":function(v){Sprints=v}});/* eslint-disable prefer-arrow-callback */
                                                                                                                      //
                                                                                                                      // 3
                                                                                                                      //
                                                                                                                      // 5
                                                                                                                      //
Meteor.publish('sprints.public', function () {                                                                        // 7
  return Sprints.find({}, { fields: Sprints.publicFields, sort: { createdAt: 1 } });                                  // 8
});                                                                                                                   // 9
Meteor.publish('sprints.forTeam', function (teamId) {                                                                 // 10
  return Sprints.find({ teamId: teamId }, { fields: Sprints.publicFields });                                          // 11
});                                                                                                                   // 12
Meteor.publish('sprints.public.findOne', function (sprintId) {                                                        // 13
  return Sprints.find({ _id: sprintId }, { fields: Sprints.publicFields });                                           // 14
});                                                                                                                   // 15
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods.js":["meteor/meteor","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","meteor/underscore","../teams/teams.js","./sprints.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/sprints/methods.js                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({insert:function(){return insert},update:function(){return update},remove:function(){return remove}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Teams;module.import('../teams/teams.js',{"Teams":function(v){Teams=v}});var Sprints;module.import('./sprints.js',{"Sprints":function(v){Sprints=v}});
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      // 5
                                                                                                                      //
                                                                                                                      // 7
                                                                                                                      // 8
                                                                                                                      //
function validateSprintName(name) {                                                                                   // 12
  var count = Sprints.find({ name: name }).count();                                                                   // 13
  if (count > 1) {                                                                                                    // 14
    throw new Meteor.Error('sprint.name.alreadyExist', 'Sprint with the specified name already exist');               // 15
  }                                                                                                                   // 16
}                                                                                                                     // 17
                                                                                                                      //
var SPRINT_ID_ONLY = new SimpleSchema({                                                                               // 19
  sprintId: { type: String }                                                                                          // 20
}).validator();                                                                                                       // 19
                                                                                                                      //
var insert = new ValidatedMethod({                                                                                    // 23
  name: 'sprints.insert',                                                                                             // 24
  validate: new SimpleSchema({                                                                                        // 25
    name: { type: String },                                                                                           // 26
    goals: { type: String },                                                                                          // 27
    teamId: {                                                                                                         // 28
      type: String,                                                                                                   // 29
      regEx: SimpleSchema.RegEx.Id                                                                                    // 30
    },                                                                                                                // 28
    startDate: {                                                                                                      // 32
      type: Date                                                                                                      // 33
    },                                                                                                                // 32
    endDate: {                                                                                                        // 35
      type: Date                                                                                                      // 36
    }                                                                                                                 // 35
  }).validator(),                                                                                                     // 25
  run: function run(_ref) {                                                                                           // 39
    var name = _ref.name;                                                                                             // 39
    var goals = _ref.goals;                                                                                           // 39
    var teamId = _ref.teamId;                                                                                         // 39
    var startDate = _ref.startDate;                                                                                   // 39
    var endDate = _ref.endDate;                                                                                       // 39
                                                                                                                      //
    if (!this.userId) {                                                                                               // 40
      throw new Error('not-authorized');                                                                              // 40
    }                                                                                                                 // 40
                                                                                                                      //
    var team = Teams.findOne(teamId);                                                                                 // 42
                                                                                                                      //
    if (!team) {                                                                                                      // 44
      throw new Meteor.Error('sprint.create.teamNotFound', 'team not found');                                         // 45
    }                                                                                                                 // 46
                                                                                                                      //
    if (!team.editableBy(this.userId)) {                                                                              // 48
      throw new Meteor.Error('sprints.update.accessDenied', "You don't have permission to edit this team.");          // 49
    }                                                                                                                 // 51
                                                                                                                      //
    validateSprintName(name);                                                                                         // 53
                                                                                                                      //
    var newSprint = { name: name, goals: goals, teamId: teamId, startDate: startDate, endDate: endDate };             // 55
    newSprint.ownerId = this.userId;                                                                                  // 56
                                                                                                                      //
    newSprint.createdAt = Date.now();                                                                                 // 58
                                                                                                                      //
    return Sprints.insert(newSprint);                                                                                 // 61
  }                                                                                                                   // 62
});                                                                                                                   // 23
                                                                                                                      //
var update = new ValidatedMethod({                                                                                    // 65
  name: 'sprints.update',                                                                                             // 66
  validate: new SimpleSchema({                                                                                        // 67
    sprintId: { type: String, regEx: SimpleSchema.RegEx.Id },                                                         // 68
    name: { type: String, optional: true },                                                                           // 69
    goals: { type: String, optional: true },                                                                          // 70
    startDate: { type: Date, optional: true },                                                                        // 71
    endDate: { type: Date, optional: true }                                                                           // 72
  }).validator(),                                                                                                     // 67
  run: function run(_ref2) {                                                                                          // 74
    var sprintId = _ref2.sprintId;                                                                                    // 74
    var name = _ref2.name;                                                                                            // 74
    var goals = _ref2.goals;                                                                                          // 74
                                                                                                                      //
    if (!this.userId) {                                                                                               // 75
      throw new Error('not-authorized');                                                                              // 75
    }                                                                                                                 // 75
                                                                                                                      //
    var sprint = Sprints.findOne(sprintId);                                                                           // 77
                                                                                                                      //
    if (!sprint.editableBy(this.userId)) {                                                                            // 79
      throw new Meteor.Error('sprints.update.accessDenied', "You don't have permission to edit this sprint.");        // 80
    }                                                                                                                 // 82
                                                                                                                      //
    if (name !== sprint.name) {                                                                                       // 84
      validateSprintName(name);                                                                                       // 85
    }                                                                                                                 // 86
                                                                                                                      //
    var data = { name: name, goals: sprint.goals, startDate: sprint.startDate, endDate: sprint.endDate };             // 88
                                                                                                                      //
    if (goals) {                                                                                                      // 90
      data.goals = goals;                                                                                             // 91
    }                                                                                                                 // 92
                                                                                                                      //
    if (startDate) {                                                                                                  // 94
      data.startDate = startDate;                                                                                     // 95
    }                                                                                                                 // 96
                                                                                                                      //
    if (endDate) {                                                                                                    // 98
      data.endDate = endDate;                                                                                         // 99
    }                                                                                                                 // 100
                                                                                                                      //
    if (data.startDate >= data.endDate) {                                                                             // 102
      throw new Meteor.Error('sprints.startDate.validation', 'Sprint start date cannot be ahead of end date');        // 103
    }                                                                                                                 // 104
                                                                                                                      //
    // XXX the security check above is not atomic, so in theory a race condition could                                //
    // result in exposing private data                                                                                //
                                                                                                                      //
    Sprints.update(sprintId, {                                                                                        // 110
      $set: data                                                                                                      // 111
    });                                                                                                               // 110
  }                                                                                                                   // 113
});                                                                                                                   // 65
                                                                                                                      //
var remove = new ValidatedMethod({                                                                                    // 117
  name: 'sprints.remove',                                                                                             // 118
  validate: SPRINT_ID_ONLY,                                                                                           // 119
  run: function run(_ref3) {                                                                                          // 120
    var sprintId = _ref3.sprintId;                                                                                    // 120
                                                                                                                      //
    if (!this.userId) {                                                                                               // 121
      throw new Error('not-authorized');                                                                              // 121
    }                                                                                                                 // 121
                                                                                                                      //
    var sprint = Sprints.findOne(sprintId);                                                                           // 123
                                                                                                                      //
    if (!sprint.editableBy(this.userId)) {                                                                            // 125
      throw new Meteor.Error('sprints.remove.accessDenied', "You don't have permission to remove this sprint.");      // 126
    }                                                                                                                 // 128
                                                                                                                      //
    Sprints.remove(sprintId);                                                                                         // 130
  }                                                                                                                   // 131
});                                                                                                                   // 117
                                                                                                                      //
// Get list of all method names on teams                                                                              //
var teams_METHODS = _.pluck([insert, update, remove], 'name');                                                        // 135
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 141
  // Only allow 5 list operations per connection per second                                                           //
  DDPRateLimiter.addRule({                                                                                            // 143
    name: function name(_name) {                                                                                      // 144
      return _.contains(teams_METHODS, _name);                                                                        // 145
    },                                                                                                                // 146
                                                                                                                      //
                                                                                                                      //
    // Rate limit per connection ID                                                                                   //
    connectionId: function connectionId() {                                                                           // 149
      return true;                                                                                                    // 149
    }                                                                                                                 // 149
  }, 5, 1000);                                                                                                        // 143
}                                                                                                                     // 151
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"sprints.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/aldeed:simple-schema","meteor/factory","../teams/teams",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/sprints/sprints.js                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({Sprints:function(){return Sprints}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Factory;module.import('meteor/factory',{"Factory":function(v){Factory=v}});var Teams;module.import('../teams/teams',{"Teams":function(v){Teams=v}});
                                                                                                                      //
                                                                                                                      //
                                                                                                                      // 1
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      //
var SprintsCollection = function (_Mongo$Collection) {                                                                //
  _inherits(SprintsCollection, _Mongo$Collection);                                                                    //
                                                                                                                      //
  function SprintsCollection() {                                                                                      //
    _classCallCheck(this, SprintsCollection);                                                                         //
                                                                                                                      //
    return _possibleConstructorReturn(this, _Mongo$Collection.apply(this, arguments));                                //
  }                                                                                                                   //
                                                                                                                      //
  SprintsCollection.prototype.insert = function insert(sprint, callback) {                                            //
    var thisSprint = sprint;                                                                                          // 8
    return _Mongo$Collection.prototype.insert.call(this, thisSprint, callback);                                       // 9
  };                                                                                                                  // 10
                                                                                                                      //
  SprintsCollection.prototype.remove = function remove(selector, callback) {                                          //
    return _Mongo$Collection.prototype.remove.call(this, selector, callback);                                         // 12
  };                                                                                                                  // 13
                                                                                                                      //
  return SprintsCollection;                                                                                           //
}(Mongo.Collection);                                                                                                  //
                                                                                                                      //
var Sprints = new SprintsCollection('sprints');                                                                       // 16
                                                                                                                      //
// Deny all client-side updates since we will be using methods to manage this collection                              //
Sprints.deny({                                                                                                        // 19
  insert: function insert() {                                                                                         // 20
    return true;                                                                                                      // 20
  },                                                                                                                  // 20
  update: function update() {                                                                                         // 21
    return true;                                                                                                      // 21
  },                                                                                                                  // 21
  remove: function remove() {                                                                                         // 22
    return true;                                                                                                      // 22
  }                                                                                                                   // 22
});                                                                                                                   // 19
                                                                                                                      //
Sprints.schema = new SimpleSchema({                                                                                   // 25
  name: {                                                                                                             // 26
    type: String                                                                                                      // 27
  },                                                                                                                  // 26
  goals: {                                                                                                            // 29
    type: String                                                                                                      // 30
  },                                                                                                                  // 29
  teamId: {                                                                                                           // 32
    type: String,                                                                                                     // 33
    regEx: SimpleSchema.RegEx.Id,                                                                                     // 34
    denyUpdate: true                                                                                                  // 35
  },                                                                                                                  // 32
  startDate: {                                                                                                        // 37
    type: Date                                                                                                        // 38
  },                                                                                                                  // 37
  status: {                                                                                                           // 40
    type: String,                                                                                                     // 41
    defaultValue: 'created'                                                                                           // 42
  },                                                                                                                  // 40
  endDate: {                                                                                                          // 44
    type: Date                                                                                                        // 45
  },                                                                                                                  // 44
  createdAt: {                                                                                                        // 47
    type: Date                                                                                                        // 48
  },                                                                                                                  // 47
  ownerId: {                                                                                                          // 50
    type: String,                                                                                                     // 51
    regEx: SimpleSchema.RegEx.Id                                                                                      // 52
  }                                                                                                                   // 50
});                                                                                                                   // 25
                                                                                                                      //
Sprints.attachSchema(Sprints.schema);                                                                                 // 56
                                                                                                                      //
Sprints.publicFields = {                                                                                              // 58
  name: 1,                                                                                                            // 59
  teamId: 1,                                                                                                          // 60
  goals: 1,                                                                                                           // 61
  status: 1,                                                                                                          // 62
  startDate: 1,                                                                                                       // 63
  endDate: 1,                                                                                                         // 64
  createdAt: 1,                                                                                                       // 65
  ownerId: 1                                                                                                          // 66
};                                                                                                                    // 58
                                                                                                                      //
Factory.define('Sprint', Sprints, {});                                                                                // 69
                                                                                                                      //
Sprints.helpers({                                                                                                     // 71
  getOwner: function getOwner() {                                                                                     // 72
    var _Meteor$users$findOne = Meteor.users.findOne(this.ownerId);                                                   // 72
                                                                                                                      //
    var _id = _Meteor$users$findOne._id;                                                                              // 72
    var profile = _Meteor$users$findOne.profile;                                                                      // 72
                                                                                                                      //
    return { _id: _id, profile: profile };                                                                            // 74
  },                                                                                                                  // 75
  getIdea: function getIdea() {                                                                                       // 76
    return Ideas.findOne(this.ideaId);                                                                                // 77
  },                                                                                                                  // 78
  editableBy: function editableBy(userId) {                                                                           // 79
    if (!this.ownerId) {                                                                                              // 80
      return true;                                                                                                    // 81
    }                                                                                                                 // 82
                                                                                                                      //
    return this.ownerId === userId;                                                                                   // 84
  }                                                                                                                   // 85
});                                                                                                                   // 71
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"teams":{"server":{"publications.js":["meteor/meteor","../teams.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/teams/server/publications.js                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Teams;module.import('../teams.js',{"Teams":function(v){Teams=v}});/* eslint-disable prefer-arrow-callback */
                                                                                                                      //
                                                                                                                      // 3
                                                                                                                      //
                                                                                                                      // 5
                                                                                                                      //
Meteor.publish('teams.public', function () {                                                                          // 7
  return Teams.find({}, { fields: Teams.publicFields, sort: { createdAt: -1 } });                                     // 8
});                                                                                                                   // 9
Meteor.publish('teams.public.findOne', function (ideaId) {                                                            // 10
  return Teams.find({ ideaId: ideaId }, { fields: Teams.publicFields });                                              // 11
});                                                                                                                   // 12
                                                                                                                      //
Meteor.publish('account.allusers', function (ideaId) {                                                                // 14
  return Meteor.users.find({}, { fields: { profile: 1, _id: 1 } });                                                   // 15
});                                                                                                                   // 16
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods.js":["meteor/meteor","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","meteor/underscore","../ideas/ideas.js","./teams.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/teams/methods.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({insert:function(){return insert},update:function(){return update},addMember:function(){return addMember},removeMember:function(){return removeMember},remove:function(){return remove}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Ideas;module.import('../ideas/ideas.js',{"Ideas":function(v){Ideas=v}});var Teams;module.import('./teams.js',{"Teams":function(v){Teams=v}});
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      // 5
                                                                                                                      //
                                                                                                                      // 7
                                                                                                                      // 8
                                                                                                                      //
function validateTeamName(name) {                                                                                     // 10
  var count = Teams.find({ name: name }).count();                                                                     // 11
  if (count > 1) {                                                                                                    // 12
    throw new Meteor.Error('team.name.alreadyExist', 'Team with the specified name already exist');                   // 13
  }                                                                                                                   // 14
}                                                                                                                     // 15
                                                                                                                      //
var TEAM_ID_ONLY = new SimpleSchema({                                                                                 // 17
  teamId: { type: String }                                                                                            // 18
}).validator();                                                                                                       // 17
                                                                                                                      //
var insert = new ValidatedMethod({                                                                                    // 21
  name: 'teams.insert',                                                                                               // 22
  validate: new SimpleSchema({                                                                                        // 23
    name: { type: String },                                                                                           // 24
    ideaId: {                                                                                                         // 25
      type: String,                                                                                                   // 26
      regEx: SimpleSchema.RegEx.Id                                                                                    // 27
    },                                                                                                                // 25
    'members.$.memberId': {                                                                                           // 29
      type: String,                                                                                                   // 30
      regEx: SimpleSchema.RegEx.Id                                                                                    // 31
    }                                                                                                                 // 29
  }).validator(),                                                                                                     // 23
  run: function run(_ref) {                                                                                           // 34
    var name = _ref.name;                                                                                             // 34
    var ideaId = _ref.ideaId;                                                                                         // 34
    var members = _ref.members;                                                                                       // 34
                                                                                                                      //
    if (!this.userId) {                                                                                               // 35
      throw new Error('not-authorized');                                                                              // 35
    }                                                                                                                 // 35
                                                                                                                      //
    var idea = Ideas.findOne(ideaId);                                                                                 // 37
                                                                                                                      //
    if (!idea) {                                                                                                      // 39
      throw new Meteor.Error('team.create.ideaNotFound', 'idea not found');                                           // 40
    }                                                                                                                 // 41
                                                                                                                      //
    if (!idea.editableBy(this.userId)) {                                                                              // 43
      throw new Meteor.Error('teams.update.accessDenied', "You don't have permission to edit this team.");            // 44
    }                                                                                                                 // 46
                                                                                                                      //
    var existingTeam = Teams.findOne({ ideaId: ideaId });                                                             // 48
    if (existingTeam) {                                                                                               // 49
      throw new Meteor.Error('teams.insert.alreadyExist', 'The team is already been formed for this idea, please delete the existing team.');
    }                                                                                                                 // 52
                                                                                                                      //
    validateTeamName(name);                                                                                           // 54
                                                                                                                      //
    var newteam = { name: name, ideaId: ideaId };                                                                     // 56
    newteam.ownerId = this.userId;                                                                                    // 57
    newteam.ownerName = Meteor.user().profile.fullName;                                                               // 58
    newteam.createdAt = Date.now();                                                                                   // 59
    newteam.members = Meteor.users.find({ _id: { $in: members.map(function (mem) {                                    // 60
          return mem.memberId;                                                                                        // 61
        }) } }, { fields: { _id: 1, profile: 1 } }).fetch().map(function (member) {                                   // 61
      return { memberName: member.profile.fullName, memberId: member._id };                                           // 64
    });                                                                                                               // 65
                                                                                                                      //
    return Teams.insert(newteam);                                                                                     // 67
  }                                                                                                                   // 68
});                                                                                                                   // 21
                                                                                                                      //
var update = new ValidatedMethod({                                                                                    // 71
  name: 'teams.update',                                                                                               // 72
  validate: new SimpleSchema({                                                                                        // 73
    teamId: { type: String, regEx: SimpleSchema.RegEx.Id },                                                           // 74
    name: { type: String, optional: true },                                                                           // 75
    'members.$.memberId': {                                                                                           // 76
      type: String,                                                                                                   // 77
      regEx: SimpleSchema.RegEx.Id,                                                                                   // 78
      optional: true                                                                                                  // 79
    }                                                                                                                 // 76
  }).validator(),                                                                                                     // 73
  run: function run(_ref2) {                                                                                          // 82
    var teamId = _ref2.teamId;                                                                                        // 82
    var name = _ref2.name;                                                                                            // 82
    var members = _ref2.members;                                                                                      // 82
                                                                                                                      //
    if (!this.userId) {                                                                                               // 83
      throw new Error('not-authorized');                                                                              // 83
    }                                                                                                                 // 83
                                                                                                                      //
    var team = Teams.findOne(teamId);                                                                                 // 85
                                                                                                                      //
    if (!team.editableBy(this.userId)) {                                                                              // 87
      throw new Meteor.Error('teams.update.accessDenied', "You don't have permission to edit this team.");            // 88
    }                                                                                                                 // 90
                                                                                                                      //
    if (name !== team.name) {                                                                                         // 92
      validateTeamName(name);                                                                                         // 93
    }                                                                                                                 // 94
                                                                                                                      //
    var data = { name: name };                                                                                        // 96
                                                                                                                      //
    if (members) {                                                                                                    // 98
      data.members = Meteor.users.find({ _id: { $in: members.map(function (mem) {                                     // 99
            return mem.memberId;                                                                                      // 100
          }) } }, { fields: { _id: 1, profile: 1 } }).fetch().map(function (member) {                                 // 100
        return { memberName: member.profile.fullName, memberId: member._id };                                         // 103
      });                                                                                                             // 104
    }                                                                                                                 // 105
                                                                                                                      //
    // XXX the security check above is not atomic, so in theory a race condition could                                //
    // result in exposing private data                                                                                //
                                                                                                                      //
    Teams.update(teamId, {                                                                                            // 110
      $set: data                                                                                                      // 111
    });                                                                                                               // 110
  }                                                                                                                   // 113
});                                                                                                                   // 71
                                                                                                                      //
var addMember = new ValidatedMethod({                                                                                 // 116
  name: 'teams.addMember',                                                                                            // 117
  validate: new SimpleSchema({                                                                                        // 118
    'teamId': { type: String, regEx: SimpleSchema.RegEx.Id },                                                         // 119
    'userId': { type: String, regEx: SimpleSchema.RegEx.Id }                                                          // 120
  }).validator(),                                                                                                     // 118
  run: function run(_ref3) {                                                                                          // 122
    var teamId = _ref3.teamId;                                                                                        // 122
    var userId = _ref3.userId;                                                                                        // 122
                                                                                                                      //
    if (!this.userId) {                                                                                               // 123
      throw new Error('not-authorized');                                                                              // 123
    }                                                                                                                 // 123
                                                                                                                      //
    var team = Teams.findOne(teamId);                                                                                 // 125
                                                                                                                      //
    if (!team.editableBy(this.userId)) {                                                                              // 127
      throw new Meteor.Error('teams.update.accessDenied', "You don't have permission to edit this team.");            // 128
    }                                                                                                                 // 130
                                                                                                                      //
    var userToAdd = Meteor.users.findOne(userId);                                                                     // 132
                                                                                                                      //
    if (!userToAdd) {                                                                                                 // 134
      throw new Error('user not found');                                                                              // 135
    }                                                                                                                 // 136
                                                                                                                      //
    if (!_.contains(team.members, userToAdd._id)) {                                                                   // 138
      team.members.push({ memberName: userToAdd.profile.fullName, memberId: userToAdd._id });                         // 139
    }                                                                                                                 // 140
                                                                                                                      //
    // XXX the security check above is not atomic, so in theory a race condition could                                //
    // result in exposing private data                                                                                //
                                                                                                                      //
    Teams.update(teamId, {                                                                                            // 145
      $set: { members: team.members }                                                                                 // 146
    });                                                                                                               // 145
  }                                                                                                                   // 148
});                                                                                                                   // 116
                                                                                                                      //
var removeMember = new ValidatedMethod({                                                                              // 151
  name: 'teams.removeMember',                                                                                         // 152
  validate: new SimpleSchema({                                                                                        // 153
    'teamId': { type: String, regEx: SimpleSchema.RegEx.Id },                                                         // 154
    'userId': { type: String, regEx: SimpleSchema.RegEx.Id }                                                          // 155
  }).validator(),                                                                                                     // 153
  run: function run(_ref4) {                                                                                          // 157
    var teamId = _ref4.teamId;                                                                                        // 157
    var userId = _ref4.userId;                                                                                        // 157
                                                                                                                      //
    if (!this.userId) {                                                                                               // 158
      throw new Error('not-authorized');                                                                              // 158
    }                                                                                                                 // 158
                                                                                                                      //
    var team = Teams.findOne(teamId);                                                                                 // 160
                                                                                                                      //
    if (!team.editableBy(this.userId)) {                                                                              // 162
      throw new Meteor.Error('teams.update.accessDenied', "You don't have permission to edit this team.");            // 163
    }                                                                                                                 // 165
                                                                                                                      //
    var userToRemove = Meteor.users.findOne(userId);                                                                  // 167
                                                                                                                      //
    if (!userToRemove) {                                                                                              // 169
      throw new Error('user not found');                                                                              // 170
    }                                                                                                                 // 171
                                                                                                                      //
    if (!_.contains(team.members, userToRemove._id)) {                                                                // 173
      throw new Error('user not a member already');                                                                   // 174
    }                                                                                                                 // 175
                                                                                                                      //
    var memberToRemove = _.findWhere(team.members, { memberId: userToRemove._id });                                   // 177
    var index = team.members.indexOf(memberToRemove);                                                                 // 178
                                                                                                                      //
    team.members.splice(index, 1);                                                                                    // 180
                                                                                                                      //
    // XXX the security check above is not atomic, so in theory a race condition could                                //
    // result in exposing private data                                                                                //
                                                                                                                      //
    Teams.update(teamId, {                                                                                            // 185
      $set: { members: team.members }                                                                                 // 186
    });                                                                                                               // 185
  }                                                                                                                   // 188
});                                                                                                                   // 151
                                                                                                                      //
var remove = new ValidatedMethod({                                                                                    // 191
  name: 'teams.remove',                                                                                               // 192
  validate: TEAM_ID_ONLY,                                                                                             // 193
  run: function run(_ref5) {                                                                                          // 194
    var teamId = _ref5.teamId;                                                                                        // 194
                                                                                                                      //
    if (!this.userId) {                                                                                               // 195
      throw new Error('not-authorized');                                                                              // 195
    }                                                                                                                 // 195
                                                                                                                      //
    var team = Teams.findOne(teamId);                                                                                 // 197
                                                                                                                      //
    if (!team.editableBy(this.userId)) {                                                                              // 199
      throw new Meteor.Error('teams.remove.accessDenied', "You don't have permission to remove this team.");          // 200
    }                                                                                                                 // 202
                                                                                                                      //
    Teams.remove(teamId);                                                                                             // 204
  }                                                                                                                   // 205
});                                                                                                                   // 191
                                                                                                                      //
// Get list of all method names on teams                                                                              //
var teams_METHODS = _.pluck([insert, update, remove], 'name');                                                        // 209
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 215
  // Only allow 5 list operations per connection per second                                                           //
  DDPRateLimiter.addRule({                                                                                            // 217
    name: function name(_name) {                                                                                      // 218
      return _.contains(teams_METHODS, _name);                                                                        // 219
    },                                                                                                                // 220
                                                                                                                      //
                                                                                                                      //
    // Rate limit per connection ID                                                                                   //
    connectionId: function connectionId() {                                                                           // 223
      return true;                                                                                                    // 223
    }                                                                                                                 // 223
  }, 5, 1000);                                                                                                        // 217
}                                                                                                                     // 225
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"teams.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/aldeed:simple-schema","meteor/factory","../ideas/ideas",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/teams/teams.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({Teams:function(){return Teams}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Factory;module.import('meteor/factory',{"Factory":function(v){Factory=v}});var Ideas;module.import('../ideas/ideas',{"Ideas":function(v){Ideas=v}});
                                                                                                                      //
                                                                                                                      //
                                                                                                                      // 1
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      //
var TeamsCollection = function (_Mongo$Collection) {                                                                  //
  _inherits(TeamsCollection, _Mongo$Collection);                                                                      //
                                                                                                                      //
  function TeamsCollection() {                                                                                        //
    _classCallCheck(this, TeamsCollection);                                                                           //
                                                                                                                      //
    return _possibleConstructorReturn(this, _Mongo$Collection.apply(this, arguments));                                //
  }                                                                                                                   //
                                                                                                                      //
  TeamsCollection.prototype.insert = function insert(team, callback) {                                                //
    var ourTeam = team;                                                                                               // 8
    return _Mongo$Collection.prototype.insert.call(this, ourTeam, callback);                                          // 9
  };                                                                                                                  // 10
                                                                                                                      //
  TeamsCollection.prototype.remove = function remove(selector, callback) {                                            //
    return _Mongo$Collection.prototype.remove.call(this, selector, callback);                                         // 12
  };                                                                                                                  // 13
                                                                                                                      //
  return TeamsCollection;                                                                                             //
}(Mongo.Collection);                                                                                                  //
                                                                                                                      //
var Teams = new TeamsCollection('Teams');                                                                             // 16
                                                                                                                      //
// Deny all client-side updates since we will be using methods to manage this collection                              //
Teams.deny({                                                                                                          // 19
  insert: function insert() {                                                                                         // 20
    return true;                                                                                                      // 20
  },                                                                                                                  // 20
  update: function update() {                                                                                         // 21
    return true;                                                                                                      // 21
  },                                                                                                                  // 21
  remove: function remove() {                                                                                         // 22
    return true;                                                                                                      // 22
  }                                                                                                                   // 22
});                                                                                                                   // 19
                                                                                                                      //
Teams.schema = new SimpleSchema({                                                                                     // 25
  name: {                                                                                                             // 26
    type: String                                                                                                      // 27
  },                                                                                                                  // 26
  'members.$.memberId': {                                                                                             // 29
    type: String,                                                                                                     // 30
    regEx: SimpleSchema.RegEx.Id                                                                                      // 31
  },                                                                                                                  // 29
  'members.$.memberName': {                                                                                           // 33
    type: String                                                                                                      // 34
  },                                                                                                                  // 33
  ideaId: {                                                                                                           // 36
    type: String,                                                                                                     // 37
    regEx: SimpleSchema.RegEx.Id,                                                                                     // 38
    denyUpdate: true                                                                                                  // 39
  },                                                                                                                  // 36
  createdAt: {                                                                                                        // 41
    type: Date                                                                                                        // 42
  },                                                                                                                  // 41
  ownerId: {                                                                                                          // 44
    type: String,                                                                                                     // 45
    regEx: SimpleSchema.RegEx.Id                                                                                      // 46
  }                                                                                                                   // 44
});                                                                                                                   // 25
                                                                                                                      //
Teams.attachSchema(Teams.schema);                                                                                     // 50
                                                                                                                      //
Teams.publicFields = {                                                                                                // 52
  name: 1,                                                                                                            // 53
  ideaId: 1,                                                                                                          // 54
  members: 1,                                                                                                         // 55
  createdAt: 1,                                                                                                       // 56
  ownerId: 1                                                                                                          // 57
};                                                                                                                    // 52
                                                                                                                      //
Factory.define('Team', Teams, {});                                                                                    // 60
                                                                                                                      //
Teams.helpers({                                                                                                       // 62
  owner: function owner() {                                                                                           // 63
    var _Meteor$users$findOne = Meteor.users.findOne(this.ownerId);                                                   // 63
                                                                                                                      //
    var _id = _Meteor$users$findOne._id;                                                                              // 63
    var profile = _Meteor$users$findOne.profile;                                                                      // 63
                                                                                                                      //
    return { _id: _id, profile: profile };                                                                            // 65
  },                                                                                                                  // 66
  getIdea: function getIdea() {                                                                                       // 67
    return Ideas.findOne(this.ideaId);                                                                                // 68
  },                                                                                                                  // 69
  editableBy: function editableBy(userId) {                                                                           // 70
    if (!this.ownerId) {                                                                                              // 71
      return true;                                                                                                    // 72
    }                                                                                                                 // 73
                                                                                                                      //
    return this.ownerId === userId;                                                                                   // 75
  }                                                                                                                   // 76
});                                                                                                                   // 62
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"votes":{"methods.js":["meteor/meteor","meteor/underscore","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","./votes","../ideas/ideas",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/votes/methods.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({cast:function(){return cast}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var Votes;module.import('./votes',{"Votes":function(v){Votes=v}});var Ideas;module.import('../ideas/ideas',{"Ideas":function(v){Ideas=v}});
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      // 5
                                                                                                                      //
                                                                                                                      // 7
                                                                                                                      // 8
                                                                                                                      //
var cast = new ValidatedMethod({                                                                                      // 10
  name: 'votes.cast',                                                                                                 // 11
  validate: new SimpleSchema({                                                                                        // 12
    ideaId: { type: String },                                                                                         // 13
    isUpVote: { type: Boolean }                                                                                       // 14
  }).validator(),                                                                                                     // 12
  run: function run(_ref) {                                                                                           // 16
    var ideaId = _ref.ideaId;                                                                                         // 16
    var isUpVote = _ref.isUpVote;                                                                                     // 16
                                                                                                                      //
    var idea = Ideas.findOne(ideaId);                                                                                 // 17
    if (!idea) {                                                                                                      // 18
      throw new Meteor.Error('idea-not-found');                                                                       // 19
    }                                                                                                                 // 20
                                                                                                                      //
    var castedVote = Votes.findOne({ ideaId: ideaId, ownerId: this.userId });                                         // 22
    if (!castedVote) {                                                                                                // 23
      var ownerName = Meteor.user().profile.fullName;                                                                 // 24
      var ownerId = this.userId;                                                                                      // 25
      var vote = { ideaId: ideaId, isUpVote: isUpVote, ownerId: ownerId, ownerName: ownerName };                      // 26
      Votes.insert(vote);                                                                                             // 27
    } else {                                                                                                          // 28
      Votes.update({ _id: castedVote._id }, { $set: { isUpVote: isUpVote } });                                        // 29
    }                                                                                                                 // 30
  }                                                                                                                   // 31
});                                                                                                                   // 10
                                                                                                                      //
// Get list of all method names on Todos                                                                              //
var VOTES_METHODS = _.pluck([cast], 'name');                                                                          // 35
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 37
  // Only allow 5 todos operations per connection per second                                                          //
  DDPRateLimiter.addRule({                                                                                            // 39
    name: function name(_name) {                                                                                      // 40
      return _.contains(VOTES_METHODS, _name);                                                                        // 41
    },                                                                                                                // 42
                                                                                                                      //
                                                                                                                      //
    // Rate limit per connection ID                                                                                   //
    connectionId: function connectionId() {                                                                           // 45
      return true;                                                                                                    // 45
    }                                                                                                                 // 45
  }, 5, 1000);                                                                                                        // 39
}                                                                                                                     // 47
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"votes.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/check","meteor/factory","faker","./votesCountDenormalizer","meteor/aldeed:simple-schema",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/votes/votes.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({Votes:function(){return Votes}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Factory;module.import('meteor/factory',{"Factory":function(v){Factory=v}});var faker;module.import('faker',{"default":function(v){faker=v}});var votesCountDenormalizer;module.import('./votesCountDenormalizer',{"default":function(v){votesCountDenormalizer=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});
                                                                                                                      //
                                                                                                                      //
                                                                                                                      // 1
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      //
                                                                                                                      // 6
                                                                                                                      // 7
                                                                                                                      //
var VotesCollection = function (_Mongo$Collection) {                                                                  //
  _inherits(VotesCollection, _Mongo$Collection);                                                                      //
                                                                                                                      //
  function VotesCollection() {                                                                                        //
    _classCallCheck(this, VotesCollection);                                                                           //
                                                                                                                      //
    return _possibleConstructorReturn(this, _Mongo$Collection.apply(this, arguments));                                //
  }                                                                                                                   //
                                                                                                                      //
  VotesCollection.prototype.insert = function insert(doc, callback) {                                                 //
    var ourDoc = doc;                                                                                                 // 14
    ourDoc.createdAt = ourDoc.createdAt || new Date();                                                                // 15
    var result = _Mongo$Collection.prototype.insert.call(this, ourDoc, callback);                                     // 16
    votesCountDenormalizer.afterInsertVote(ourDoc);                                                                   // 17
    return result;                                                                                                    // 18
  };                                                                                                                  // 19
                                                                                                                      //
  VotesCollection.prototype.update = function update(selector, modifier) {                                            //
    var result = _Mongo$Collection.prototype.update.call(this, selector, modifier);                                   // 21
    votesCountDenormalizer.afterUpdateVote(selector, modifier);                                                       // 22
    return result;                                                                                                    // 23
  };                                                                                                                  // 24
                                                                                                                      //
  VotesCollection.prototype.remove = function remove(selector) {                                                      //
    var comments = this.find(selector).fetch();                                                                       // 26
    var result = _Mongo$Collection.prototype.remove.call(this, selector);                                             // 27
    votesCountDenormalizer.afterRemoveVotes(comments);                                                                // 28
    return result;                                                                                                    // 29
  };                                                                                                                  // 30
                                                                                                                      //
  return VotesCollection;                                                                                             //
}(Mongo.Collection);                                                                                                  //
                                                                                                                      //
var Votes = new VotesCollection('votes');                                                                             // 33
                                                                                                                      //
Votes.schema = new SimpleSchema({                                                                                     // 35
  ideaId: {                                                                                                           // 36
    type: String,                                                                                                     // 37
    regEx: SimpleSchema.RegEx.Id,                                                                                     // 38
    denyUpdate: true                                                                                                  // 39
  },                                                                                                                  // 36
  isUpVote: {                                                                                                         // 41
    type: Boolean                                                                                                     // 42
  },                                                                                                                  // 41
  createdAt: {                                                                                                        // 44
    type: Date,                                                                                                       // 45
    denyUpdate: true                                                                                                  // 46
  },                                                                                                                  // 44
  ownerId: {                                                                                                          // 48
    type: String,                                                                                                     // 49
    regEx: SimpleSchema.RegEx.Id,                                                                                     // 50
    denyUpdate: true                                                                                                  // 51
  },                                                                                                                  // 48
  ownerName: {                                                                                                        // 53
    type: String,                                                                                                     // 54
    denyUpdate: true                                                                                                  // 55
  }                                                                                                                   // 53
});                                                                                                                   // 35
                                                                                                                      //
Votes.attachSchema(Votes.schema);                                                                                     // 59
                                                                                                                      //
// Deny all client-side updates since we will be using methods to manage this collection                              //
Votes.deny({                                                                                                          // 62
  insert: function insert() {                                                                                         // 63
    return true;                                                                                                      // 63
  },                                                                                                                  // 63
  update: function update() {                                                                                         // 64
    return true;                                                                                                      // 64
  },                                                                                                                  // 64
  remove: function remove() {                                                                                         // 65
    return true;                                                                                                      // 65
  }                                                                                                                   // 65
});                                                                                                                   // 62
                                                                                                                      //
Factory.define('Vote', Votes, {});                                                                                    // 68
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"votesCountDenormalizer.js":["meteor/underscore","meteor/check","./votes","../ideas/ideas",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/votes/votesCountDenormalizer.js                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _;module.import('meteor/underscore',{"_":function(v){_=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Votes;module.import('./votes',{"Votes":function(v){Votes=v}});var Ideas;module.import('../ideas/ideas',{"Ideas":function(v){Ideas=v}});
                                                                                                                      // 2
                                                                                                                      //
                                                                                                                      // 4
                                                                                                                      // 5
                                                                                                                      //
function getVotesCount(ideaId, isUpVote) {                                                                            // 7
  return Votes.find({ ideaId: ideaId, isUpVote: isUpVote }).count();                                                  // 8
}                                                                                                                     // 9
                                                                                                                      //
var votesCountDenormalizer = {                                                                                        // 11
  _updateIdea: function _updateIdea(ideaId) {                                                                         // 12
    // Recalculate the correct incomplete count direct from MongoDB                                                   //
    var stats = { upVotes: getVotesCount(ideaId, true), downVotes: getVotesCount(ideaId, false) };                    // 14
    Ideas.update(ideaId, { $set: stats });                                                                            // 15
  },                                                                                                                  // 16
  afterInsertVote: function afterInsertVote(vote) {                                                                   // 17
    this._updateIdea(vote.ideaId);                                                                                    // 18
  },                                                                                                                  // 19
  afterUpdateVote: function afterUpdateVote(selector, modifier) {                                                     // 20
    var _this = this;                                                                                                 // 20
                                                                                                                      //
    // We only support very limited operations on todos                                                               //
    check(modifier, { $set: Object });                                                                                // 22
                                                                                                                      //
    var votes = Votes.find(selector);                                                                                 // 24
    votes.forEach(function (vote) {                                                                                   // 25
      return _this._updateIdea(vote.ideaId);                                                                          // 25
    });                                                                                                               // 25
  },                                                                                                                  // 26
                                                                                                                      //
  // Here we need to take the list of todos being removed, selected *before* the update                               //
  // because otherwise we can't figure out the relevant list id(s) (if the todo has been deleted)                     //
  afterRemoveVotes: function afterRemoveVotes(votes) {                                                                // 29
    var _this2 = this;                                                                                                // 29
                                                                                                                      //
    votes.forEach(function (vote) {                                                                                   // 30
      return _this2._updateIdea(vote.ideaId);                                                                         // 30
    });                                                                                                               // 30
  }                                                                                                                   // 31
};                                                                                                                    // 11
                                                                                                                      //
module.export("default",exports.default=(votesCountDenormalizer));                                                    // 34
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"startup":{"server":{"fixtures.js":["meteor/meteor","../../api/ideas/ideas","../../api/idea-comments/idea-comments","../../api/votes/votes",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/startup/server/fixtures.js                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Ideas;module.import('../../api/ideas/ideas',{"Ideas":function(v){Ideas=v}});var IdeaComments;module.import('../../api/idea-comments/idea-comments',{"IdeaComments":function(v){IdeaComments=v}});var Votes;module.import('../../api/votes/votes',{"Votes":function(v){Votes=v}});
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      //
Meteor.startup(function () {});                                                                                       // 8
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./fixtures.js","./reset-password-email.js","./security.js","./register-api.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/startup/server/index.js                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.import('./fixtures.js');module.import('./reset-password-email.js');module.import('./security.js');module.import('./register-api.js');// This defines a starting set of data to be loaded if the app is loaded with an empty db.
                                                                                                                      // 2
                                                                                                                      //
// This file configures the Accounts package to define the UI of the reset password email.                            //
                                                                                                                      // 5
                                                                                                                      //
// Set up some rate limiting and other important security settings.                                                   //
                                                                                                                      // 8
                                                                                                                      //
// This defines all the collections, publications and methods that the application provides                           //
// as an API to the client.                                                                                           //
                                                                                                                      // 12
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"register-api.js":["../../api/ideas/methods.js","../../api/ideas/server/publications.js","../../api/teams/methods.js","../../api/teams/server/publications.js","../../api/sprints/methods.js","../../api/sprints/server/publications.js","../../api/idea-comments/methods.js","../../api/idea-comments/server/publications.js","../../api/votes/methods.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/startup/server/register-api.js                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.import('../../api/ideas/methods.js');module.import('../../api/ideas/server/publications.js');module.import('../../api/teams/methods.js');module.import('../../api/teams/server/publications.js');module.import('../../api/sprints/methods.js');module.import('../../api/sprints/server/publications.js');module.import('../../api/idea-comments/methods.js');module.import('../../api/idea-comments/server/publications.js');module.import('../../api/votes/methods.js');
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      // 5
                                                                                                                      // 6
                                                                                                                      // 7
                                                                                                                      // 8
                                                                                                                      // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"reset-password-email.js":["meteor/accounts-base",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/startup/server/reset-password-email.js                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});                              // 1
                                                                                                                      //
Accounts.emailTemplates.siteName = 'Idea Dashboard';                                                                  // 4
Accounts.emailTemplates.from = 'Ideas Dashboard <accounts@example.com>';                                              // 5
                                                                                                                      //
Accounts.emailTemplates.resetPassword = {                                                                             // 7
  subject: function subject() {                                                                                       // 8
    return 'Reset your password on Idea Dashboard';                                                                   // 9
  },                                                                                                                  // 10
  text: function text(user, url) {                                                                                    // 11
    return 'Hello!\n\nClick the link below to reset your password on Idea Dashboard.\n\n' + url + '\n\nIf you didn\'t request this email, please ignore it.\n\nThanks,\nThe Idea Dashboard Team\n';
  }                                                                                                                   // 23
};                                                                                                                    // 7
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"security.js":["meteor/meteor","meteor/ddp-rate-limiter","meteor/underscore",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/startup/server/security.js                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      //
// Don't let people write arbitrary data to their 'profile' field from the client                                     //
Meteor.users.deny({                                                                                                   // 6
  update: function update() {                                                                                         // 7
    return true;                                                                                                      // 8
  }                                                                                                                   // 9
});                                                                                                                   // 6
                                                                                                                      //
// Get a list of all accounts methods by running `Meteor.server.method_handlers` in meteor shell                      //
var AUTH_METHODS = ['login', 'logout', 'logoutOtherClients', 'getNewToken', 'removeOtherTokens', 'configureLoginService', 'changePassword', 'forgotPassword', 'resetPassword', 'verifyEmail', 'createUser', 'ATRemoveService', 'ATCreateUserServer', 'ATResendVerificationEmail'];
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 30
  // Only allow 2 login attempts per connection per 5 seconds                                                         //
  DDPRateLimiter.addRule({                                                                                            // 32
    name: function name(_name) {                                                                                      // 33
      return _.contains(AUTH_METHODS, _name);                                                                         // 34
    },                                                                                                                // 35
                                                                                                                      //
                                                                                                                      //
    // Rate limit per connection ID                                                                                   //
    connectionId: function connectionId() {                                                                           // 38
      return true;                                                                                                    // 38
    }                                                                                                                 // 38
  }, 2, 5000);                                                                                                        // 32
}                                                                                                                     // 40
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}},"i18n":{"en.i18n.json":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// i18n/en.i18n.json                                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n._enable({"helper_name":"_","supported_languages":null,"i18n_files_route":"/tap-i18n","preloaded_langs":[],"cdn_path":null});
TAPi18n.languages_names["en"] = ["English","English"];
// integrate the fallback language translations 
translations = {};
translations[namespace] = {"lists":{"makePrivate":{"notLoggedIn":"Must be logged in to make private lists.","lastPublicList":"Cannot make the last public list private."},"makePublic":{"notLoggedIn":"Must be logged in.","accessDenied":"You don't have permission to edit this list."},"updateName":{"accessDenied":"You don't have permission to edit this list."},"remove":{"accessDenied":"'You don't have permission to remove this list.'","lastPublicList":"Cannot delete the last public list."}},"todos":{"insert":{"accessDenied":"Cannot add todos to a private list that is not yours"},"setCheckedStatus":{"accessDenied":"Cannot edit todos in a private list that is not yours"},"updateText":{"accessDenied":"Cannot edit todos in a private list that is not yours"},"remove":{"accessDenied":"Cannot remove todos in a private list that is not yours"}}};
TAPi18n._loadLangFileObject("en", translations);
TAPi18n._registerServerTranslator("en", namespace);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":["/imports/startup/server",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.import('/imports/startup/server');                                                                             // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./i18n/en.i18n.json");
require("./server/main.js");
//# sourceMappingURL=app.js.map
