var require = meteorInstall({"imports":{"api":{"activities":{"server":{"publications.js":["meteor/meteor","../activities",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/activities/server/publications.js                                                                   //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Activities;module.import('../activities',{"Activities":function(v){Activities=v}});/* eslint-disable prefer-arrow-callback */
                                                                                                                   //
                                                                                                                   // 3
                                                                                                                   //
                                                                                                                   // 5
                                                                                                                   //
Meteor.publish('activities.public', function (ownerId) {                                                           // 7
  return Activities.find({ $or: [{ ownerId: ownerId }, { targetOwnerId: ownerId }, { itemOwnerId: ownerId }] }, { fields: Activities.publicFields, sort: { createdAt: -1 } });
});                                                                                                                // 9
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"receiver.js":["../../events","../methods",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/activities/server/receiver.js                                                                       //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var emitter;module.import('../../events',{"default":function(v){emitter=v}});var add;module.import('../methods',{"add":function(v){add=v}});
                                                                                                                   // 2
                                                                                                                   //
var IDEAS_CREATE = 'ideas.create';                                                                                 // 4
var IDEAS_COMMENTS_CREATE = 'ideas.comments.create';                                                               // 5
var IDEAS_VOTES = 'ideas.votes';                                                                                   // 6
                                                                                                                   //
emitter.on(IDEAS_CREATE, function (idea) {                                                                         // 8
    add({                                                                                                          // 9
        type: IDEAS_CREATE,                                                                                        // 10
        body: idea.name,                                                                                           // 11
        itemId: idea._id,                                                                                          // 12
        itemOwnerId: idea.ownerId                                                                                  // 13
    }, function (err) {                                                                                            // 9
        return function (err) {                                                                                    // 14
            return console.error(err);                                                                             // 14
        };                                                                                                         // 14
    });                                                                                                            // 14
});                                                                                                                // 15
                                                                                                                   //
emitter.on(IDEAS_COMMENTS_CREATE, function (comment) {                                                             // 17
    add({                                                                                                          // 18
        type: IDEAS_COMMENTS_CREATE,                                                                               // 19
        body: comment.text,                                                                                        // 20
        itemId: comment._id,                                                                                       // 21
        itemOwnerId: comment.ownerId,                                                                              // 22
        itemDetails: { ideaId: comment.ideaId },                                                                   // 23
        targetOwnerId: comment.getIdea().ownerId                                                                   // 24
    }, function (err) {                                                                                            // 18
        return function (err) {                                                                                    // 25
            return console.error(err);                                                                             // 25
        };                                                                                                         // 25
    });                                                                                                            // 25
});                                                                                                                // 26
                                                                                                                   //
emitter.on(IDEAS_VOTES, function (vote) {                                                                          // 28
    add({                                                                                                          // 29
        type: IDEAS_VOTES,                                                                                         // 30
        body: '',                                                                                                  // 31
        itemId: vote._id,                                                                                          // 32
        itemOwnerId: vote.ownerId,                                                                                 // 33
        itemDetails: { ideaId: vote.ideaId, isUpVote: vote.isUpVote },                                             // 34
        targetOwnerId: vote.getIdea().ownerId                                                                      // 35
    }, function (err) {                                                                                            // 29
        return function (err) {                                                                                    // 36
            return console.error(err);                                                                             // 36
        };                                                                                                         // 36
    });                                                                                                            // 36
});                                                                                                                // 37
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"activities.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/aldeed:simple-schema","meteor/factory",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/activities/activities.js                                                                            //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({Activities:function(){return Activities}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Factory;module.import('meteor/factory',{"Factory":function(v){Factory=v}});
                                                                                                                   //
                                                                                                                   //
                                                                                                                   // 1
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   //
var ActivitiesCollection = function (_Mongo$Collection) {                                                          //
  _inherits(ActivitiesCollection, _Mongo$Collection);                                                              //
                                                                                                                   //
  function ActivitiesCollection() {                                                                                //
    _classCallCheck(this, ActivitiesCollection);                                                                   //
                                                                                                                   //
    return _possibleConstructorReturn(this, _Mongo$Collection.apply(this, arguments));                             //
  }                                                                                                                //
                                                                                                                   //
  ActivitiesCollection.prototype.remove = function () {                                                            //
    function remove(selector, callback) {                                                                          //
      return _Mongo$Collection.prototype.remove.call(this, selector, callback);                                    // 8
    }                                                                                                              // 9
                                                                                                                   //
    return remove;                                                                                                 //
  }();                                                                                                             //
                                                                                                                   //
  return ActivitiesCollection;                                                                                     //
}(Mongo.Collection);                                                                                               //
                                                                                                                   //
var Activities = new ActivitiesCollection('activities');                                                           // 12
                                                                                                                   //
// Deny all client-side updates since we will be using methods to manage this collection                           // 14
Activities.deny({                                                                                                  // 15
  insert: function () {                                                                                            // 16
    function insert() {                                                                                            // 15
      return true;                                                                                                 // 16
    }                                                                                                              // 16
                                                                                                                   //
    return insert;                                                                                                 // 15
  }(),                                                                                                             // 15
  update: function () {                                                                                            // 17
    function update() {                                                                                            // 15
      return true;                                                                                                 // 17
    }                                                                                                              // 17
                                                                                                                   //
    return update;                                                                                                 // 15
  }(),                                                                                                             // 15
  remove: function () {                                                                                            // 18
    function remove() {                                                                                            // 15
      return true;                                                                                                 // 18
    }                                                                                                              // 18
                                                                                                                   //
    return remove;                                                                                                 // 15
  }()                                                                                                              // 15
});                                                                                                                // 15
                                                                                                                   //
Activities.schema = new SimpleSchema({                                                                             // 21
  body: {                                                                                                          // 22
    type: String,                                                                                                  // 23
    defaultValue: ''                                                                                               // 24
  },                                                                                                               // 22
  type: {                                                                                                          // 26
    type: String,                                                                                                  // 27
    defaultValue: ''                                                                                               // 28
  },                                                                                                               // 26
  itemId: {                                                                                                        // 30
    type: String,                                                                                                  // 31
    regEx: SimpleSchema.RegEx.Id                                                                                   // 32
  },                                                                                                               // 30
  itemOwnerId: {                                                                                                   // 34
    type: String,                                                                                                  // 35
    regEx: SimpleSchema.RegEx.Id                                                                                   // 36
  },                                                                                                               // 34
  itemDetails: {                                                                                                   // 38
    type: Object,                                                                                                  // 39
    optional: true,                                                                                                // 40
    blackbox: true                                                                                                 // 41
  },                                                                                                               // 38
  targetOwnerId: {                                                                                                 // 43
    type: String,                                                                                                  // 44
    regEx: SimpleSchema.RegEx.Id,                                                                                  // 45
    optional: true,                                                                                                // 46
    denyUpdate: true                                                                                               // 47
  },                                                                                                               // 43
  ownerId: {                                                                                                       // 49
    type: String,                                                                                                  // 50
    regEx: SimpleSchema.RegEx.Id,                                                                                  // 51
    denyUpdate: true                                                                                               // 52
  },                                                                                                               // 49
  ownerName: {                                                                                                     // 54
    type: String,                                                                                                  // 55
    denyUpdate: true                                                                                               // 56
  },                                                                                                               // 54
  createdAt: {                                                                                                     // 58
    type: Date                                                                                                     // 59
  }                                                                                                                // 58
});                                                                                                                // 21
                                                                                                                   //
Activities.attachSchema(Activities.schema);                                                                        // 63
                                                                                                                   //
Activities.publicFields = {                                                                                        // 65
  body: 1,                                                                                                         // 66
  type: 1,                                                                                                         // 67
  ownerId: 1,                                                                                                      // 68
  ownerName: 1,                                                                                                    // 69
  itemId: 1,                                                                                                       // 70
  itemOwnerId: 1,                                                                                                  // 71
  itemDetails: 1,                                                                                                  // 72
  createdAt: 1                                                                                                     // 73
};                                                                                                                 // 65
                                                                                                                   //
Factory.define('Actiivity', Activities, {});                                                                       // 76
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["meteor/meteor","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","meteor/underscore","./activities",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/activities/methods.js                                                                               //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({add:function(){return add}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Activities;module.import('./activities',{"Activities":function(v){Activities=v}});
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   // 4
                                                                                                                   // 5
                                                                                                                   //
                                                                                                                   // 7
                                                                                                                   //
function add(_ref) {                                                                                               // 9
  var body = _ref.body;                                                                                            // 9
  var type = _ref.type;                                                                                            // 9
  var itemId = _ref.itemId;                                                                                        // 9
  var itemOwnerId = _ref.itemOwnerId;                                                                              // 9
  var itemDetails = _ref.itemDetails;                                                                              // 9
                                                                                                                   //
                                                                                                                   //
  var userId = Meteor.user()._id;                                                                                  // 11
  if (!userId) {                                                                                                   // 12
    throw new Error('not-authorized');                                                                             // 12
  }                                                                                                                // 12
                                                                                                                   //
  return Activities.insert({                                                                                       // 14
    body: body,                                                                                                    // 15
    type: type,                                                                                                    // 16
    itemId: itemId,                                                                                                // 17
    itemOwnerId: itemOwnerId,                                                                                      // 18
    itemDetails: itemDetails,                                                                                      // 19
    ownerId: userId,                                                                                               // 20
    ownerName: Meteor.user().profile.fullName,                                                                     // 21
    createdAt: new Date()                                                                                          // 22
  });                                                                                                              // 14
}                                                                                                                  // 24
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"followers":{"server":{"publications.js":["meteor/meteor","../followers",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/followers/server/publications.js                                                                    //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Followers;module.import('../followers',{"Followers":function(v){Followers=v}});/* eslint-disable prefer-arrow-callback */
                                                                                                                   //
                                                                                                                   // 3
                                                                                                                   //
                                                                                                                   // 5
                                                                                                                   //
Meteor.publish('followers', function (userId) {                                                                    // 7
	check(userId, String);                                                                                            // 8
	return Followers.find({                                                                                           // 9
		followee: userId                                                                                                 // 10
	});                                                                                                               // 9
});                                                                                                                // 12
                                                                                                                   //
Meteor.publish('following', function (userId) {                                                                    // 14
	check(userId, String);                                                                                            // 15
	return Followers.find({                                                                                           // 16
		follower: userId                                                                                                 // 17
	});                                                                                                               // 16
});                                                                                                                // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"followers.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/aldeed:simple-schema","meteor/factory","./followersCountDenormalizer",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/followers/followers.js                                                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({Followers:function(){return Followers}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Factory;module.import('meteor/factory',{"Factory":function(v){Factory=v}});var followersCountDenormalizer;module.import('./followersCountDenormalizer',{"default":function(v){followersCountDenormalizer=v}});
                                                                                                                   //
                                                                                                                   //
                                                                                                                   // 1
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   //
                                                                                                                   // 5
                                                                                                                   //
function runDenormalizations(selector) {                                                                           // 7
  console.log('updating followers count!!', selector);                                                             // 8
  var entry = Followers.findOne(selector);                                                                         // 9
  if (!entry) {                                                                                                    // 10
    return;                                                                                                        // 10
  }                                                                                                                // 10
  followersCountDenormalizer.updateFollowersCount(entry.follower);                                                 // 11
  followersCountDenormalizer.updateFollowersCount(entry.followee);                                                 // 12
}                                                                                                                  // 13
                                                                                                                   //
var FollowersCollection = function (_Mongo$Collection) {                                                           //
  _inherits(FollowersCollection, _Mongo$Collection);                                                               //
                                                                                                                   //
  function FollowersCollection() {                                                                                 //
    _classCallCheck(this, FollowersCollection);                                                                    //
                                                                                                                   //
    return _possibleConstructorReturn(this, _Mongo$Collection.apply(this, arguments));                             //
  }                                                                                                                //
                                                                                                                   //
  FollowersCollection.prototype.insert = function () {                                                             //
    function insert(follower, callback) {                                                                          //
      var result = _Mongo$Collection.prototype.insert.call(this, follower, callback);                              // 17
      runDenormalizations({ _id: result });                                                                        // 18
      return result;                                                                                               // 19
    }                                                                                                              // 20
                                                                                                                   //
    return insert;                                                                                                 //
  }();                                                                                                             //
                                                                                                                   //
  FollowersCollection.prototype.update = function () {                                                             //
    function update(selector) {                                                                                    //
      var _Mongo$Collection$pro;                                                                                   // 21
                                                                                                                   //
      var result = (_Mongo$Collection$pro = _Mongo$Collection.prototype.update).call.apply(_Mongo$Collection$pro, [this].concat(Array.prototype.slice.call(arguments)));
      runDenormalizations(selector);                                                                               // 23
      return result;                                                                                               // 24
    }                                                                                                              // 25
                                                                                                                   //
    return update;                                                                                                 //
  }();                                                                                                             //
                                                                                                                   //
  FollowersCollection.prototype.remove = function () {                                                             //
    function remove(selector, callback) {                                                                          //
      var entries = _Mongo$Collection.prototype.find.call(this, selector).fetch();                                 // 27
      var result = _Mongo$Collection.prototype.remove.call(this, selector, callback);                              // 28
                                                                                                                   //
      entries.forEach(function (entry) {                                                                           // 30
        followersCountDenormalizer.updateFollowersCount(entry.follower);                                           // 31
        followersCountDenormalizer.updateFollowersCount(entry.followee);                                           // 32
      });                                                                                                          // 33
                                                                                                                   //
      return result;                                                                                               // 35
    }                                                                                                              // 36
                                                                                                                   //
    return remove;                                                                                                 //
  }();                                                                                                             //
                                                                                                                   //
  return FollowersCollection;                                                                                      //
}(Mongo.Collection);                                                                                               //
                                                                                                                   //
var Followers = new FollowersCollection('followers');                                                              // 39
                                                                                                                   //
// Deny all client-side updates since we will be using methods to manage this collection                           // 41
Followers.deny({                                                                                                   // 42
  insert: function () {                                                                                            // 43
    function insert() {                                                                                            // 42
      return true;                                                                                                 // 43
    }                                                                                                              // 43
                                                                                                                   //
    return insert;                                                                                                 // 42
  }(),                                                                                                             // 42
  update: function () {                                                                                            // 44
    function update() {                                                                                            // 42
      return true;                                                                                                 // 44
    }                                                                                                              // 44
                                                                                                                   //
    return update;                                                                                                 // 42
  }(),                                                                                                             // 42
  remove: function () {                                                                                            // 45
    function remove() {                                                                                            // 42
      return true;                                                                                                 // 45
    }                                                                                                              // 45
                                                                                                                   //
    return remove;                                                                                                 // 42
  }()                                                                                                              // 42
});                                                                                                                // 42
                                                                                                                   //
Followers.schema = new SimpleSchema({                                                                              // 48
  followee: {                                                                                                      // 49
    type: String,                                                                                                  // 50
    regEx: SimpleSchema.RegEx.Id                                                                                   // 51
  },                                                                                                               // 49
  follower: {                                                                                                      // 53
    type: String,                                                                                                  // 54
    regEx: SimpleSchema.RegEx.Id                                                                                   // 55
  }                                                                                                                // 53
});                                                                                                                // 48
                                                                                                                   //
Followers.attachSchema(Followers.schema);                                                                          // 59
                                                                                                                   //
Followers.publicFields = {                                                                                         // 61
  followee: 0,                                                                                                     // 62
  follower: 0                                                                                                      // 63
};                                                                                                                 // 61
                                                                                                                   //
Factory.define('Follower', Followers, {});                                                                         // 66
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"followersCountDenormalizer.js":["meteor/underscore","meteor/check","./followers","../profiles/profiles.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/followers/followersCountDenormalizer.js                                                             //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var _;module.import('meteor/underscore',{"_":function(v){_=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Followers;module.import('./followers',{"Followers":function(v){Followers=v}});var Profiles;module.import('../profiles/profiles.js',{"Profiles":function(v){Profiles=v}});
                                                                                                                   // 2
                                                                                                                   //
                                                                                                                   // 4
                                                                                                                   // 5
                                                                                                                   //
function getFollowersCount(uid) {                                                                                  // 7
  return Followers.find({                                                                                          // 8
    followee: uid                                                                                                  // 9
  }).count();                                                                                                      // 8
}                                                                                                                  // 11
                                                                                                                   //
function getFollowingCount(uid) {                                                                                  // 13
  return Followers.find({                                                                                          // 14
    follower: uid                                                                                                  // 15
  }).count();                                                                                                      // 14
}                                                                                                                  // 17
                                                                                                                   //
var followersCountDenormalizer = {                                                                                 // 19
  _updateProfile: function () {                                                                                    // 20
    function _updateProfile(ownerId) {                                                                             // 19
      // Recalculate the correct incomplete count direct from MongoDB                                              // 20
                                                                                                                   //
      var followersCount = getFollowersCount(ownerId);                                                             // 22
      var followingCount = getFollowingCount(ownerId);                                                             // 23
      Profiles.update({ ownerId: ownerId }, { $set: { followersCount: followersCount, followingCount: followingCount } });
      console.log('update profile ', { ownerId: ownerId }, ' with ', { followersCount: followersCount, followingCount: followingCount });
    }                                                                                                              // 26
                                                                                                                   //
    return _updateProfile;                                                                                         // 19
  }(),                                                                                                             // 19
  updateFollowersCount: function () {                                                                              // 27
    function updateFollowersCount(ownerId) {                                                                       // 19
      this._updateProfile(ownerId);                                                                                // 28
    }                                                                                                              // 29
                                                                                                                   //
    return updateFollowersCount;                                                                                   // 19
  }()                                                                                                              // 19
};                                                                                                                 // 19
                                                                                                                   //
module.export("default",exports.default=(followersCountDenormalizer));                                             // 32
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["meteor/meteor","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","meteor/underscore","./followers",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/followers/methods.js                                                                                //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({follow:function(){return follow},unfollow:function(){return unfollow},unfollowAll:function(){return unfollowAll},getFollowers:function(){return getFollowers},getFollowersCount:function(){return getFollowersCount},getFollowing:function(){return getFollowing},getFollowingCount:function(){return getFollowingCount},checkIfFollowing:function(){return checkIfFollowing}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Followers;module.import('./followers',{"Followers":function(v){Followers=v}});
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   // 4
                                                                                                                   // 5
                                                                                                                   //
                                                                                                                   // 8
                                                                                                                   //
var USER_ID_ONLY = new SimpleSchema({                                                                              // 10
  uid: {                                                                                                           // 11
    type: String,                                                                                                  // 12
    regEx: SimpleSchema.RegEx.Id                                                                                   // 13
  }                                                                                                                // 11
}).validator();                                                                                                    // 10
                                                                                                                   //
var follow = new ValidatedMethod({                                                                                 // 17
  name: 'followers.follow',                                                                                        // 18
  validate: USER_ID_ONLY,                                                                                          // 19
  run: function () {                                                                                               // 20
    function run(_ref) {                                                                                           // 17
      var uid = _ref.uid;                                                                                          // 20
                                                                                                                   //
      return Followers.update({                                                                                    // 21
        followee: uid,                                                                                             // 22
        follower: this.userId                                                                                      // 23
      }, {                                                                                                         // 21
        $set: {                                                                                                    // 25
          invalidatedAt: undefined                                                                                 // 26
        },                                                                                                         // 25
        $setOnInsert: {                                                                                            // 28
          followee: uid,                                                                                           // 29
          follower: this.userId,                                                                                   // 30
          invalidatedAt: undefined                                                                                 // 31
        }                                                                                                          // 28
      }, {                                                                                                         // 24
        upsert: true                                                                                               // 34
      });                                                                                                          // 33
    }                                                                                                              // 36
                                                                                                                   //
    return run;                                                                                                    // 17
  }()                                                                                                              // 17
});                                                                                                                // 17
                                                                                                                   //
var unfollow = new ValidatedMethod({                                                                               // 39
  name: 'followers.unfollow',                                                                                      // 40
  validate: USER_ID_ONLY,                                                                                          // 41
  run: function () {                                                                                               // 42
    function run(_ref2) {                                                                                          // 39
      var uid = _ref2.uid;                                                                                         // 42
                                                                                                                   //
      check(uid, String);                                                                                          // 43
      return Followers.remove({                                                                                    // 44
        followee: uid,                                                                                             // 45
        follower: this.userId                                                                                      // 46
      });                                                                                                          // 44
    }                                                                                                              // 48
                                                                                                                   //
    return run;                                                                                                    // 39
  }()                                                                                                              // 39
});                                                                                                                // 39
                                                                                                                   //
var unfollowAll = new ValidatedMethod({                                                                            // 51
  name: 'followers.unfollowAll',                                                                                   // 52
  validate: USER_ID_ONLY,                                                                                          // 53
  run: function () {                                                                                               // 54
    function run(_ref3) {                                                                                          // 51
      var uid = _ref3.uid;                                                                                         // 54
                                                                                                                   //
      return Followers.remove({                                                                                    // 55
        follower: this.userId                                                                                      // 56
      });                                                                                                          // 55
    }                                                                                                              // 58
                                                                                                                   //
    return run;                                                                                                    // 51
  }()                                                                                                              // 51
});                                                                                                                // 51
                                                                                                                   //
var getFollowers = new ValidatedMethod({                                                                           // 61
  name: 'followers.getFollowers',                                                                                  // 62
  validate: USER_ID_ONLY,                                                                                          // 63
  run: function () {                                                                                               // 64
    function run(_ref4) {                                                                                          // 61
      var uid = _ref4.uid;                                                                                         // 64
                                                                                                                   //
      var followers = Followers.find({                                                                             // 65
        followee: uid                                                                                              // 66
      }).fetch();                                                                                                  // 65
      return _.map(followers, function (value, index, list) {                                                      // 68
        return value.follower;                                                                                     // 69
      });                                                                                                          // 70
    }                                                                                                              // 71
                                                                                                                   //
    return run;                                                                                                    // 61
  }()                                                                                                              // 61
});                                                                                                                // 61
                                                                                                                   //
var getFollowersCount = new ValidatedMethod({                                                                      // 74
  name: 'followers.getFollowersCount',                                                                             // 75
  validate: USER_ID_ONLY,                                                                                          // 76
  run: function () {                                                                                               // 77
    function run(_ref5) {                                                                                          // 74
      var uid = _ref5.uid;                                                                                         // 77
                                                                                                                   //
      return Followers.find({                                                                                      // 78
        followee: uid                                                                                              // 79
      }).count();                                                                                                  // 78
    }                                                                                                              // 81
                                                                                                                   //
    return run;                                                                                                    // 74
  }()                                                                                                              // 74
});                                                                                                                // 74
                                                                                                                   //
var getFollowing = new ValidatedMethod({                                                                           // 84
  name: 'followers.getFollowing',                                                                                  // 85
  validate: USER_ID_ONLY,                                                                                          // 86
  run: function () {                                                                                               // 87
    function run(_ref6) {                                                                                          // 84
      var uid = _ref6.uid;                                                                                         // 87
                                                                                                                   //
      check(uid, String);                                                                                          // 88
      var following = Followers.find({                                                                             // 89
        follower: uid                                                                                              // 90
      }).fetch();                                                                                                  // 89
      return _.map(following, function (value, index, list) {                                                      // 92
        return value.followee;                                                                                     // 93
      });                                                                                                          // 94
    }                                                                                                              // 95
                                                                                                                   //
    return run;                                                                                                    // 84
  }()                                                                                                              // 84
});                                                                                                                // 84
                                                                                                                   //
var getFollowingCount = new ValidatedMethod({                                                                      // 98
  name: 'followers.getFolloweringCount',                                                                           // 99
  validate: USER_ID_ONLY,                                                                                          // 100
  run: function () {                                                                                               // 101
    function run(_ref7) {                                                                                          // 98
      var uid = _ref7.uid;                                                                                         // 101
                                                                                                                   //
      return Followers.find({                                                                                      // 102
        follower: uid                                                                                              // 103
      }).count();                                                                                                  // 102
    }                                                                                                              // 105
                                                                                                                   //
    return run;                                                                                                    // 98
  }()                                                                                                              // 98
});                                                                                                                // 98
                                                                                                                   //
var checkIfFollowing = new ValidatedMethod({                                                                       // 108
  name: 'followers.checkIfFollowing',                                                                              // 109
  validate: USER_ID_ONLY,                                                                                          // 110
  run: function () {                                                                                               // 111
    function run(_ref8) {                                                                                          // 108
      var uid = _ref8.uid;                                                                                         // 111
                                                                                                                   //
      return !!Followers.findOne({                                                                                 // 112
        followee: uid,                                                                                             // 113
        follower: this.userId                                                                                      // 114
      });                                                                                                          // 112
    }                                                                                                              // 116
                                                                                                                   //
    return run;                                                                                                    // 108
  }()                                                                                                              // 108
});                                                                                                                // 108
                                                                                                                   //
if (Meteor.isServer) {module.export({deleteUserData:function(){return deleteUserData}});                           // 119
                                                                                                                   //
  var deleteUserData = new ValidatedMethod({                                                                       // 121
    name: 'followers.deleteUserData',                                                                              // 122
    validate: USER_ID_ONLY,                                                                                        // 123
    run: function () {                                                                                             // 124
      function run(_ref9) {                                                                                        // 121
        var uid = _ref9.uid;                                                                                       // 124
                                                                                                                   //
        return Followers.remove({                                                                                  // 125
          $or: [{ followee: uid }, { follower: this.userId }]                                                      // 126
        });                                                                                                        // 125
      }                                                                                                            // 131
                                                                                                                   //
      return run;                                                                                                  // 121
    }()                                                                                                            // 121
  });                                                                                                              // 121
}                                                                                                                  // 133
                                                                                                                   //
// Get list of all method names on ideas                                                                           // 135
var followers_METHODS = _.pluck([follow, unfollow, unfollowAll, getFollowers, getFollowersCount, getFollowing, getFollowingCount, checkIfFollowing], 'name');
                                                                                                                   //
if (Meteor.isServer) {                                                                                             // 148
  // Only allow 5 list operations per connection per second                                                        // 149
  DDPRateLimiter.addRule({                                                                                         // 150
    name: function () {                                                                                            // 151
      function name(_name) {                                                                                       // 150
        return _.contains(followers_METHODS, _name);                                                               // 152
      }                                                                                                            // 153
                                                                                                                   //
      return name;                                                                                                 // 150
    }(),                                                                                                           // 150
                                                                                                                   //
                                                                                                                   //
    // Rate limit per connection ID                                                                                // 155
    connectionId: function () {                                                                                    // 156
      function connectionId() {                                                                                    // 150
        return true;                                                                                               // 156
      }                                                                                                            // 156
                                                                                                                   //
      return connectionId;                                                                                         // 150
    }()                                                                                                            // 150
  }, 5, 1000);                                                                                                     // 150
}                                                                                                                  // 158
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"idea-comments":{"server":{"publications.js":["meteor/meteor","meteor/aldeed:simple-schema","../idea-comments",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/idea-comments/server/publications.js                                                                //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var IdeaComments;module.import('../idea-comments',{"IdeaComments":function(v){IdeaComments=v}});/* eslint-disable prefer-arrow-callback */
                                                                                                                   //
                                                                                                                   // 3
                                                                                                                   // 4
                                                                                                                   //
                                                                                                                   // 6
                                                                                                                   //
Meteor.publish('idea-comments.public', function (ideaId) {                                                         // 8
  check(ideaId, String);                                                                                           // 9
  return IdeaComments.find({ ideaId: ideaId }, { sort: { createdAt: -1 } });                                       // 10
});                                                                                                                // 11
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"commentsCountDenormalizer.js":["meteor/underscore","meteor/check","./idea-comments.js","../ideas/ideas.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/idea-comments/commentsCountDenormalizer.js                                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var _;module.import('meteor/underscore',{"_":function(v){_=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var IdeaComments;module.import('./idea-comments.js',{"IdeaComments":function(v){IdeaComments=v}});var Ideas;module.import('../ideas/ideas.js',{"Ideas":function(v){Ideas=v}});
                                                                                                                   // 2
                                                                                                                   //
                                                                                                                   // 4
                                                                                                                   // 5
                                                                                                                   //
var commentsCountDenormalizer = {                                                                                  // 7
  _updateIdea: function () {                                                                                       // 8
    function _updateIdea(ideaId) {                                                                                 // 7
      // Recalculate the correct incomplete count direct from MongoDB                                              // 9
      var comments = IdeaComments.find({ ideaId: ideaId }).count();                                                // 10
                                                                                                                   //
      Ideas.update(ideaId, { $set: { comments: comments } });                                                      // 12
    }                                                                                                              // 13
                                                                                                                   //
    return _updateIdea;                                                                                            // 7
  }(),                                                                                                             // 7
  afterInsertComment: function () {                                                                                // 14
    function afterInsertComment(comment) {                                                                         // 7
      this._updateIdea(comment.ideaId);                                                                            // 15
    }                                                                                                              // 16
                                                                                                                   //
    return afterInsertComment;                                                                                     // 7
  }(),                                                                                                             // 7
  afterUpdateComment: function () {                                                                                // 17
    function afterUpdateComment(selector, modifier) {                                                              // 7
      // We only support very limited operations on todos                                                          // 18
      check(modifier, { $set: Object });                                                                           // 19
    }                                                                                                              // 21
                                                                                                                   //
    return afterUpdateComment;                                                                                     // 7
  }(),                                                                                                             // 7
                                                                                                                   //
  // Here we need to take the list of todos being removed, selected *before* the update                            // 22
  // because otherwise we can't figure out the relevant list id(s) (if the todo has been deleted)                  // 23
  afterRemoveComments: function () {                                                                               // 24
    function afterRemoveComments(comments) {                                                                       // 7
      var _this = this;                                                                                            // 24
                                                                                                                   //
      comments.forEach(function (comment) {                                                                        // 25
        return _this._updateIdea(comment.ideaId);                                                                  // 25
      });                                                                                                          // 25
    }                                                                                                              // 26
                                                                                                                   //
    return afterRemoveComments;                                                                                    // 7
  }()                                                                                                              // 7
};                                                                                                                 // 7
                                                                                                                   //
module.export("default",exports.default=(commentsCountDenormalizer));                                              // 29
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"idea-comments.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/factory","faker","./commentsCountDenormalizer","meteor/aldeed:simple-schema","../ideas/ideas","../events",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/idea-comments/idea-comments.js                                                                      //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({IdeaComments:function(){return IdeaComments}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var Factory;module.import('meteor/factory',{"Factory":function(v){Factory=v}});var faker;module.import('faker',{"default":function(v){faker=v}});var commentsCountDenormalizer;module.import('./commentsCountDenormalizer',{"default":function(v){commentsCountDenormalizer=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Ideas;module.import('../ideas/ideas',{"Ideas":function(v){Ideas=v}});var emitter;module.import('../events',{"default":function(v){emitter=v}});
                                                                                                                   //
                                                                                                                   //
                                                                                                                   // 1
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   //
                                                                                                                   // 5
                                                                                                                   // 6
                                                                                                                   // 7
                                                                                                                   //
                                                                                                                   // 9
                                                                                                                   //
var IdeaCommentsCollection = function (_Mongo$Collection) {                                                        //
  _inherits(IdeaCommentsCollection, _Mongo$Collection);                                                            //
                                                                                                                   //
  function IdeaCommentsCollection() {                                                                              //
    _classCallCheck(this, IdeaCommentsCollection);                                                                 //
                                                                                                                   //
    return _possibleConstructorReturn(this, _Mongo$Collection.apply(this, arguments));                             //
  }                                                                                                                //
                                                                                                                   //
  IdeaCommentsCollection.prototype.insert = function () {                                                          //
    function insert(doc, callback) {                                                                               //
      var ourDoc = doc;                                                                                            // 14
      ourDoc.createdAt = ourDoc.createdAt || new Date();                                                           // 15
      var result = _Mongo$Collection.prototype.insert.call(this, ourDoc, callback);                                // 16
      commentsCountDenormalizer.afterInsertComment(ourDoc);                                                        // 17
      emitter.emit('ideas.comments.create', _Mongo$Collection.prototype.findOne.call(this, { _id: result }));      // 18
                                                                                                                   //
      return result;                                                                                               // 20
    }                                                                                                              // 21
                                                                                                                   //
    return insert;                                                                                                 //
  }();                                                                                                             //
                                                                                                                   //
  IdeaCommentsCollection.prototype.update = function () {                                                          //
    function update(selector, modifier) {                                                                          //
      var result = _Mongo$Collection.prototype.update.call(this, selector, modifier);                              // 23
      commentsCountDenormalizer.afterUpdateComment(selector, modifier);                                            // 24
      return result;                                                                                               // 25
    }                                                                                                              // 26
                                                                                                                   //
    return update;                                                                                                 //
  }();                                                                                                             //
                                                                                                                   //
  IdeaCommentsCollection.prototype.remove = function () {                                                          //
    function remove(selector) {                                                                                    //
      var comments = this.find(selector).fetch();                                                                  // 28
      var result = _Mongo$Collection.prototype.remove.call(this, selector);                                        // 29
      commentsCountDenormalizer.afterRemoveComments(comments);                                                     // 30
      return result;                                                                                               // 31
    }                                                                                                              // 32
                                                                                                                   //
    return remove;                                                                                                 //
  }();                                                                                                             //
                                                                                                                   //
  return IdeaCommentsCollection;                                                                                   //
}(Mongo.Collection);                                                                                               //
                                                                                                                   //
var IdeaComments = new IdeaCommentsCollection('idea-comments');                                                    // 35
                                                                                                                   //
IdeaComments.schema = new SimpleSchema({                                                                           // 37
  ideaId: {                                                                                                        // 38
    type: String,                                                                                                  // 39
    regEx: SimpleSchema.RegEx.Id,                                                                                  // 40
    denyUpdate: true                                                                                               // 41
  },                                                                                                               // 38
  text: {                                                                                                          // 43
    type: String                                                                                                   // 44
  },                                                                                                               // 43
  createdAt: {                                                                                                     // 46
    type: Date,                                                                                                    // 47
    denyUpdate: true                                                                                               // 48
  },                                                                                                               // 46
  updatedOn: {                                                                                                     // 50
    type: Date,                                                                                                    // 51
    optional: true                                                                                                 // 52
  },                                                                                                               // 50
  ownerId: {                                                                                                       // 54
    type: String,                                                                                                  // 55
    regEx: SimpleSchema.RegEx.Id,                                                                                  // 56
    denyUpdate: true                                                                                               // 57
  },                                                                                                               // 54
  ownerName: {                                                                                                     // 59
    type: String,                                                                                                  // 60
    denyUpdate: true                                                                                               // 61
  }                                                                                                                // 59
});                                                                                                                // 37
                                                                                                                   //
// Deny all client-side updates since we will be using methods to manage this collection                           // 65
IdeaComments.deny({                                                                                                // 66
  insert: function () {                                                                                            // 67
    function insert() {                                                                                            // 66
      return true;                                                                                                 // 67
    }                                                                                                              // 67
                                                                                                                   //
    return insert;                                                                                                 // 66
  }(),                                                                                                             // 66
  update: function () {                                                                                            // 68
    function update() {                                                                                            // 66
      return true;                                                                                                 // 68
    }                                                                                                              // 68
                                                                                                                   //
    return update;                                                                                                 // 66
  }(),                                                                                                             // 66
  remove: function () {                                                                                            // 69
    function remove() {                                                                                            // 66
      return true;                                                                                                 // 69
    }                                                                                                              // 69
                                                                                                                   //
    return remove;                                                                                                 // 66
  }()                                                                                                              // 66
});                                                                                                                // 66
                                                                                                                   //
IdeaComments.attachSchema(IdeaComments.schema);                                                                    // 73
                                                                                                                   //
// This represents the keys from Lists objects that should be published                                            // 75
// to the client. If we add secret properties to List objects, don't list                                          // 76
// them here to keep them private to the server.                                                                   // 77
IdeaComments.publicFields = {                                                                                      // 78
  ideaId: 1,                                                                                                       // 79
  text: 1,                                                                                                         // 80
  ownerId: 1,                                                                                                      // 81
  ownerName: 1                                                                                                     // 82
};                                                                                                                 // 78
                                                                                                                   //
// TODO This factory has a name - do we have a code style for this?                                                // 85
//   - usually I've used the singular, sometimes you have more than one though, like                               // 86
//   'todo', 'emptyTodo', 'checkedTodo'                                                                            // 87
Factory.define('idea-comment', IdeaComments, {                                                                     // 88
  ideaId: function () {                                                                                            // 89
    function ideaId() {                                                                                            // 89
      return Factory.get('ideas');                                                                                 // 89
    }                                                                                                              // 89
                                                                                                                   //
    return ideaId;                                                                                                 // 89
  }(),                                                                                                             // 89
  text: function () {                                                                                              // 90
    function text() {                                                                                              // 90
      return faker.lorem.sentence();                                                                               // 90
    }                                                                                                              // 90
                                                                                                                   //
    return text;                                                                                                   // 90
  }(),                                                                                                             // 90
  createdAt: function () {                                                                                         // 91
    function createdAt() {                                                                                         // 91
      return new Date();                                                                                           // 91
    }                                                                                                              // 91
                                                                                                                   //
    return createdAt;                                                                                              // 91
  }()                                                                                                              // 91
});                                                                                                                // 88
                                                                                                                   //
IdeaComments.helpers({                                                                                             // 94
  getIdea: function () {                                                                                           // 95
    function getIdea() {                                                                                           // 94
      return Ideas.findOne(this.ideaId);                                                                           // 96
    }                                                                                                              // 97
                                                                                                                   //
    return getIdea;                                                                                                // 94
  }(),                                                                                                             // 94
  editableBy: function () {                                                                                        // 98
    function editableBy(userId) {                                                                                  // 94
      if (!this.ownerId) {                                                                                         // 99
        return true;                                                                                               // 100
      }                                                                                                            // 101
                                                                                                                   //
      return this.ownerId === userId;                                                                              // 103
    }                                                                                                              // 104
                                                                                                                   //
    return editableBy;                                                                                             // 94
  }()                                                                                                              // 94
});                                                                                                                // 94
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["meteor/meteor","meteor/underscore","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","./idea-comments","../ideas/ideas",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/idea-comments/methods.js                                                                            //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({insert:function(){return insert},updateText:function(){return updateText},remove:function(){return remove}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var IdeaComments;module.import('./idea-comments',{"IdeaComments":function(v){IdeaComments=v}});var Ideas;module.import('../ideas/ideas',{"Ideas":function(v){Ideas=v}});
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   // 4
                                                                                                                   // 5
                                                                                                                   //
                                                                                                                   // 7
                                                                                                                   // 8
                                                                                                                   //
var insert = new ValidatedMethod({                                                                                 // 11
  name: 'idea-comments.insert',                                                                                    // 12
  validate: new SimpleSchema({                                                                                     // 13
    ideaId: { type: String },                                                                                      // 14
    text: { type: String }                                                                                         // 15
  }).validator(),                                                                                                  // 13
  run: function () {                                                                                               // 17
    function run(_ref) {                                                                                           // 11
      var ideaId = _ref.ideaId;                                                                                    // 17
      var text = _ref.text;                                                                                        // 17
                                                                                                                   //
      var list = Ideas.findOne(ideaId);                                                                            // 18
                                                                                                                   //
      var idea = Ideas.findOne(ideaId);                                                                            // 20
      if (!idea) {                                                                                                 // 21
        throw new Meteor.Error('idea-not-found');                                                                  // 22
      }                                                                                                            // 23
                                                                                                                   //
      var ownerName = Meteor.user().profile.fullName;                                                              // 25
                                                                                                                   //
      IdeaComments.insert({ ideaId: ideaId, text: text, ownerId: this.userId, ownerName: ownerName });             // 27
    }                                                                                                              // 28
                                                                                                                   //
    return run;                                                                                                    // 11
  }()                                                                                                              // 11
});                                                                                                                // 11
                                                                                                                   //
var updateText = new ValidatedMethod({                                                                             // 31
  name: 'idea-comments.updateText',                                                                                // 32
  validate: new SimpleSchema({                                                                                     // 33
    commentId: { type: String },                                                                                   // 34
    text: { type: String }                                                                                         // 35
  }).validator(),                                                                                                  // 33
  run: function () {                                                                                               // 37
    function run(_ref2) {                                                                                          // 31
      var commentId = _ref2.commentId;                                                                             // 37
      var text = _ref2.text;                                                                                       // 37
                                                                                                                   //
      // This is complex auth stuff - perhaps denormalizing a userId onto todos                                    // 38
      // would be correct here?                                                                                    // 39
      var ideaComment = IdeaComments.findOne(commentId);                                                           // 40
                                                                                                                   //
      if (!ideaComment.editableBy(this.userId)) {                                                                  // 42
        throw new Meteor.Error('ideaComments.updateText.accessDenied', 'Cannot edit comment that is not yours');   // 43
      }                                                                                                            // 45
                                                                                                                   //
      var updatedOn = Date.now();                                                                                  // 47
                                                                                                                   //
      IdeaComments.update(commentId, {                                                                             // 49
        $set: { text: text, updatedOn: updatedOn }                                                                 // 50
      });                                                                                                          // 49
    }                                                                                                              // 52
                                                                                                                   //
    return run;                                                                                                    // 31
  }()                                                                                                              // 31
});                                                                                                                // 31
                                                                                                                   //
var remove = new ValidatedMethod({                                                                                 // 55
  name: 'idea-comments.remove',                                                                                    // 56
  validate: new SimpleSchema({                                                                                     // 57
    commentId: { type: String }                                                                                    // 58
  }).validator(),                                                                                                  // 57
  run: function () {                                                                                               // 60
    function run(_ref3) {                                                                                          // 55
      var commentId = _ref3.commentId;                                                                             // 60
                                                                                                                   //
      var comment = IdeaComments.findOne(commentId);                                                               // 61
                                                                                                                   //
      if (!comment.editableBy(this.userId)) {                                                                      // 63
        throw new Meteor.Error('ideaComments.remove.accessDenied', 'Cannot remove comment that is not yours');     // 64
      }                                                                                                            // 66
                                                                                                                   //
      IdeaComments.remove(commentId);                                                                              // 68
    }                                                                                                              // 69
                                                                                                                   //
    return run;                                                                                                    // 55
  }()                                                                                                              // 55
});                                                                                                                // 55
                                                                                                                   //
// Get list of all method names on Todos                                                                           // 72
var IDEA_COMMENTS_METHODS = _.pluck([insert, updateText, remove], 'name');                                         // 73
                                                                                                                   //
if (Meteor.isServer) {                                                                                             // 79
  // Only allow 5 todos operations per connection per second                                                       // 80
  DDPRateLimiter.addRule({                                                                                         // 81
    name: function () {                                                                                            // 82
      function name(_name) {                                                                                       // 81
        return _.contains(IDEA_COMMENTS_METHODS, _name);                                                           // 83
      }                                                                                                            // 84
                                                                                                                   //
      return name;                                                                                                 // 81
    }(),                                                                                                           // 81
                                                                                                                   //
                                                                                                                   //
    // Rate limit per connection ID                                                                                // 86
    connectionId: function () {                                                                                    // 87
      function connectionId() {                                                                                    // 81
        return true;                                                                                               // 87
      }                                                                                                            // 87
                                                                                                                   //
      return connectionId;                                                                                         // 81
    }()                                                                                                            // 81
  }, 5, 1000);                                                                                                     // 81
}                                                                                                                  // 89
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"ideas":{"server":{"publications.js":["meteor/meteor","../ideas.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/ideas/server/publications.js                                                                        //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Ideas;module.import('../ideas.js',{"Ideas":function(v){Ideas=v}});/* eslint-disable prefer-arrow-callback */
                                                                                                                   //
                                                                                                                   // 3
                                                                                                                   //
                                                                                                                   // 5
                                                                                                                   //
Meteor.publish('ideas.public', function () {                                                                       // 7
  return Ideas.find({}, { fields: Ideas.publicFields, sort: { createdAt: -1 } });                                  // 8
});                                                                                                                // 9
Meteor.publish('ideas.public.findOne', function (ideaId) {                                                         // 10
  return Ideas.find({ _id: ideaId }, { fields: Ideas.publicFields });                                              // 11
});                                                                                                                // 12
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"ideas.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/aldeed:simple-schema","meteor/factory","../teams/teams","../events",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/ideas/ideas.js                                                                                      //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({Ideas:function(){return Ideas}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Factory;module.import('meteor/factory',{"Factory":function(v){Factory=v}});var Teams;module.import('../teams/teams',{"Teams":function(v){Teams=v}});var emitter;module.import('../events',{"default":function(v){emitter=v}});
                                                                                                                   //
                                                                                                                   //
                                                                                                                   // 1
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   // 4
                                                                                                                   //
                                                                                                                   // 6
                                                                                                                   //
var IdeasCollection = function (_Mongo$Collection) {                                                               //
  _inherits(IdeasCollection, _Mongo$Collection);                                                                   //
                                                                                                                   //
  function IdeasCollection() {                                                                                     //
    _classCallCheck(this, IdeasCollection);                                                                        //
                                                                                                                   //
    return _possibleConstructorReturn(this, _Mongo$Collection.apply(this, arguments));                             //
  }                                                                                                                //
                                                                                                                   //
  IdeasCollection.prototype.insert = function () {                                                                 //
    function insert(Idea, callback) {                                                                              //
      var ourIdea = Idea;                                                                                          // 10
      if (!ourIdea.name) {                                                                                         // 11
        var nextLetter = 'A';                                                                                      // 12
        ourIdea.name = 'Idea ' + nextLetter;                                                                       // 13
                                                                                                                   //
        while (!!this.findOne({ name: ourIdea.name })) {                                                           // 15
          // not going to be too smart here, can go past Z                                                         // 16
          nextLetter = String.fromCharCode(nextLetter.charCodeAt(0) + 1);                                          // 17
          ourIdea.name = 'Idea ' + nextLetter;                                                                     // 18
        }                                                                                                          // 19
      }                                                                                                            // 20
      var result = _Mongo$Collection.prototype.insert.call(this, ourIdea, callback);                               // 21
      emitter.emit('ideas.create', _Mongo$Collection.prototype.findOne.call(this, { _id: result }));               // 22
      return result;                                                                                               // 23
    }                                                                                                              // 24
                                                                                                                   //
    return insert;                                                                                                 //
  }();                                                                                                             //
                                                                                                                   //
  IdeasCollection.prototype.remove = function () {                                                                 //
    function remove(selector, callback) {                                                                          //
      return _Mongo$Collection.prototype.remove.call(this, selector, callback);                                    // 26
    }                                                                                                              // 27
                                                                                                                   //
    return remove;                                                                                                 //
  }();                                                                                                             //
                                                                                                                   //
  return IdeasCollection;                                                                                          //
}(Mongo.Collection);                                                                                               //
                                                                                                                   //
var Ideas = new IdeasCollection('Ideas');                                                                          // 30
                                                                                                                   //
// Deny all client-side updates since we will be using methods to manage this collection                           // 32
Ideas.deny({                                                                                                       // 33
  insert: function () {                                                                                            // 34
    function insert() {                                                                                            // 33
      return true;                                                                                                 // 34
    }                                                                                                              // 34
                                                                                                                   //
    return insert;                                                                                                 // 33
  }(),                                                                                                             // 33
  update: function () {                                                                                            // 35
    function update() {                                                                                            // 33
      return true;                                                                                                 // 35
    }                                                                                                              // 35
                                                                                                                   //
    return update;                                                                                                 // 33
  }(),                                                                                                             // 33
  remove: function () {                                                                                            // 36
    function remove() {                                                                                            // 33
      return true;                                                                                                 // 36
    }                                                                                                              // 36
                                                                                                                   //
    return remove;                                                                                                 // 33
  }()                                                                                                              // 33
});                                                                                                                // 33
                                                                                                                   //
Ideas.schema = new SimpleSchema({                                                                                  // 39
  name: {                                                                                                          // 40
    type: String                                                                                                   // 41
  },                                                                                                               // 40
  businessValue: {                                                                                                 // 43
    type: String,                                                                                                  // 44
    defaultValue: ''                                                                                               // 45
  },                                                                                                               // 43
  definitionOfSuccess: {                                                                                           // 47
    type: String,                                                                                                  // 48
    optional: true,                                                                                                // 49
    defaultValue: ''                                                                                               // 50
  },                                                                                                               // 47
  fundingRequirement: {                                                                                            // 52
    type: String,                                                                                                  // 53
    optional: true,                                                                                                // 54
    defaultValue: ''                                                                                               // 55
  },                                                                                                               // 52
  createdAt: {                                                                                                     // 57
    type: Date                                                                                                     // 58
  },                                                                                                               // 57
  ownerId: {                                                                                                       // 60
    type: String,                                                                                                  // 61
    regEx: SimpleSchema.RegEx.Id                                                                                   // 62
  },                                                                                                               // 60
  ownerName: {                                                                                                     // 64
    type: String                                                                                                   // 65
  },                                                                                                               // 64
  status: {                                                                                                        // 67
    type: String,                                                                                                  // 68
    allowedValues: ['new', 'completed'],                                                                           // 69
    defaultValue: 'new'                                                                                            // 70
  },                                                                                                               // 67
  kanbanBoardId: {                                                                                                 // 72
    type: String,                                                                                                  // 73
    regEx: SimpleSchema.RegEx.Id,                                                                                  // 74
    optional: true                                                                                                 // 75
  },                                                                                                               // 72
  comments: {                                                                                                      // 77
    type: Number,                                                                                                  // 78
    optional: true,                                                                                                // 79
    defaultValue: 0                                                                                                // 80
  },                                                                                                               // 77
  upVotes: {                                                                                                       // 82
    type: Number,                                                                                                  // 83
    optional: true,                                                                                                // 84
    defaultValue: 0                                                                                                // 85
  },                                                                                                               // 82
  downVotes: {                                                                                                     // 87
    type: Number,                                                                                                  // 88
    optional: true,                                                                                                // 89
    defaultValue: 0                                                                                                // 90
  }                                                                                                                // 87
});                                                                                                                // 39
                                                                                                                   //
Ideas.attachSchema(Ideas.schema);                                                                                  // 94
                                                                                                                   //
Ideas.publicFields = {                                                                                             // 96
  name: 1,                                                                                                         // 97
  businessValue: 1,                                                                                                // 98
  definitionOfSuccess: 1,                                                                                          // 99
  fundingRequirement: 1,                                                                                           // 100
  createdAt: 1,                                                                                                    // 101
  ownerId: 1,                                                                                                      // 102
  ownerName: 1,                                                                                                    // 103
  status: 1,                                                                                                       // 104
  kanbanBoardId: 1,                                                                                                // 105
  comments: 1,                                                                                                     // 106
  upVotes: 1,                                                                                                      // 107
  downVotes: 1                                                                                                     // 108
};                                                                                                                 // 96
                                                                                                                   //
Factory.define('Idea', Ideas, {});                                                                                 // 111
                                                                                                                   //
Ideas.helpers({                                                                                                    // 113
  // A Idea is considered to be private if it has a userId set                                                     // 114
  isPrivate: function () {                                                                                         // 115
    function isPrivate() {                                                                                         // 113
      return !!this.ownerId;                                                                                       // 116
    }                                                                                                              // 117
                                                                                                                   //
    return isPrivate;                                                                                              // 113
  }(),                                                                                                             // 113
  isCompleted: function () {                                                                                       // 118
    function isCompleted() {                                                                                       // 113
      return this.status === 'completed';                                                                          // 119
    }                                                                                                              // 120
                                                                                                                   //
    return isCompleted;                                                                                            // 113
  }(),                                                                                                             // 113
  getTeam: function () {                                                                                           // 121
    function getTeam() {                                                                                           // 113
      return Teams.find({ ideaId: this._id });                                                                     // 122
    }                                                                                                              // 123
                                                                                                                   //
    return getTeam;                                                                                                // 113
  }(),                                                                                                             // 113
  hasKanbanBoard: function () {                                                                                    // 124
    function hasKanbanBoard(userId) {                                                                              // 113
      return !!this.kanbanBoardId;                                                                                 // 125
    }                                                                                                              // 126
                                                                                                                   //
    return hasKanbanBoard;                                                                                         // 113
  }(),                                                                                                             // 113
  editableBy: function () {                                                                                        // 127
    function editableBy(userId) {                                                                                  // 113
      if (!this.ownerId) {                                                                                         // 128
        return true;                                                                                               // 129
      }                                                                                                            // 130
                                                                                                                   //
      return this.ownerId === userId;                                                                              // 132
    }                                                                                                              // 133
                                                                                                                   //
    return editableBy;                                                                                             // 113
  }(),                                                                                                             // 113
  comments: function () {                                                                                          // 134
    function comments() {                                                                                          // 113
      return Comments.find({ ideaId: this._id }, { sort: { createdAt: -1 } });                                     // 135
    }                                                                                                              // 136
                                                                                                                   //
    return comments;                                                                                               // 113
  }()                                                                                                              // 113
});                                                                                                                // 113
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["meteor/meteor","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","meteor/underscore","meteor/pro-ideas:kanban","./ideas.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/ideas/methods.js                                                                                    //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({insert:function(){return insert},update:function(){return update},markAsCompleted:function(){return markAsCompleted},createKanbanBoard:function(){return createKanbanBoard},remove:function(){return remove}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Kanban;module.import('meteor/pro-ideas:kanban',{"default":function(v){Kanban=v}});var Ideas;module.import('./ideas.js',{"Ideas":function(v){Ideas=v}});
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   // 4
                                                                                                                   // 5
                                                                                                                   // 6
                                                                                                                   //
                                                                                                                   // 8
                                                                                                                   //
function validateIdeaName(name) {                                                                                  // 10
  var count = Ideas.find({ name: name }).count();                                                                  // 11
  if (count > 1) {                                                                                                 // 12
    throw new Meteor.Error('idea.name.alreadyExist', 'Idea with the specified name already exist');                // 13
  }                                                                                                                // 14
}                                                                                                                  // 15
                                                                                                                   //
var IDEA_ID_ONLY = new SimpleSchema({                                                                              // 17
  ideaId: { type: String }                                                                                         // 18
}).validator();                                                                                                    // 17
                                                                                                                   //
var insert = new ValidatedMethod({                                                                                 // 21
  name: 'ideas.insert',                                                                                            // 22
  validate: new SimpleSchema({                                                                                     // 23
    name: { type: String, optional: true },                                                                        // 24
    businessValue: { type: String, optional: true },                                                               // 25
    definitionOfSuccess: { type: String, optional: true },                                                         // 26
    fundingRequirement: { type: String, optional: true }                                                           // 27
  }).validator(),                                                                                                  // 23
  run: function () {                                                                                               // 29
    function run(newIdea) {                                                                                        // 21
      if (!this.userId) {                                                                                          // 30
        throw new Error('not-authorized');                                                                         // 30
      }                                                                                                            // 30
                                                                                                                   //
      validateIdeaName(newIdea.name);                                                                              // 32
                                                                                                                   //
      newIdea.ownerId = this.userId;                                                                               // 34
      newIdea.ownerName = Meteor.user().profile.fullName;                                                          // 35
      newIdea.createdAt = Date.now();                                                                              // 36
      return Ideas.insert(newIdea);                                                                                // 37
    }                                                                                                              // 38
                                                                                                                   //
    return run;                                                                                                    // 21
  }()                                                                                                              // 21
});                                                                                                                // 21
                                                                                                                   //
var update = new ValidatedMethod({                                                                                 // 41
  name: 'ideas.update',                                                                                            // 42
  validate: new SimpleSchema({                                                                                     // 43
    ideaId: { type: String },                                                                                      // 44
    name: { type: String, optional: true },                                                                        // 45
    businessValue: { type: String, optional: true },                                                               // 46
    definitionOfSuccess: { type: String, optional: true },                                                         // 47
    fundingRequirement: { type: String, optional: true }                                                           // 48
  }).validator(),                                                                                                  // 43
  run: function () {                                                                                               // 50
    function run(data) {                                                                                           // 41
      var ideaId = data.ideaId;                                                                                    // 51
      var idea = Ideas.findOne(ideaId);                                                                            // 52
                                                                                                                   //
      if (!idea.editableBy(this.userId)) {                                                                         // 54
        throw new Meteor.Error('ideas.update.accessDenied', "You don't have permission to edit this idea.");       // 55
      }                                                                                                            // 57
                                                                                                                   //
      if (idea.name !== data.name) {                                                                               // 59
        validateIdeaName(data.name);                                                                               // 60
      }                                                                                                            // 61
      // XXX the security check above is not atomic, so in theory a race condition could                           // 62
      // result in exposing private data                                                                           // 63
                                                                                                                   //
      Ideas.update(ideaId, {                                                                                       // 65
        $set: data                                                                                                 // 66
      });                                                                                                          // 65
    }                                                                                                              // 68
                                                                                                                   //
    return run;                                                                                                    // 41
  }()                                                                                                              // 41
});                                                                                                                // 41
                                                                                                                   //
var markAsCompleted = new ValidatedMethod({                                                                        // 71
  name: 'ideas.markAsCompleted',                                                                                   // 72
  validate: IDEA_ID_ONLY,                                                                                          // 73
  run: function () {                                                                                               // 74
    function run(_ref) {                                                                                           // 71
      var ideaId = _ref.ideaId;                                                                                    // 74
                                                                                                                   //
      var idea = Ideas.findOne(ideaId);                                                                            // 75
                                                                                                                   //
      if (!idea.editableBy(this.userId)) {                                                                         // 77
        throw new Meteor.Error('ideas.remove.accessDenied', "You don't have permission to mark this idea as completed.");
      }                                                                                                            // 80
                                                                                                                   //
      Ideas.update(ideaId, {                                                                                       // 82
        $set: { status: 'completed' }                                                                              // 83
      });                                                                                                          // 82
    }                                                                                                              // 85
                                                                                                                   //
    return run;                                                                                                    // 71
  }()                                                                                                              // 71
});                                                                                                                // 71
                                                                                                                   //
var createKanbanBoard = new ValidatedMethod({                                                                      // 88
  name: 'ideas.createKanbanBoard',                                                                                 // 89
  validate: IDEA_ID_ONLY,                                                                                          // 90
  run: function () {                                                                                               // 91
    function run(_ref2) {                                                                                          // 88
      var ideaId = _ref2.ideaId;                                                                                   // 91
                                                                                                                   //
      var idea = Ideas.findOne(ideaId);                                                                            // 92
                                                                                                                   //
      if (!idea.editableBy(this.userId)) {                                                                         // 94
        throw new Meteor.Error('ideas.viewKanban.accessDenied', "You don't have permission to view the kanban board.");
      }                                                                                                            // 97
                                                                                                                   //
      if (idea.hasKanbanBoard()) {                                                                                 // 99
        return idea.kanbanBoardId;                                                                                 // 100
      }                                                                                                            // 101
                                                                                                                   //
      if (Meteor.isServer) {                                                                                       // 103
        var kanbanBoardId = Kanban.getBoardId(idea._id);                                                           // 104
                                                                                                                   //
        Ideas.update(ideaId, {                                                                                     // 106
          $set: { kanbanBoardId: kanbanBoardId }                                                                   // 107
        });                                                                                                        // 106
                                                                                                                   //
        return kanbanBoardId;                                                                                      // 110
      }                                                                                                            // 111
    }                                                                                                              // 112
                                                                                                                   //
    return run;                                                                                                    // 88
  }()                                                                                                              // 88
});                                                                                                                // 88
                                                                                                                   //
var remove = new ValidatedMethod({                                                                                 // 115
  name: 'ideas.remove',                                                                                            // 116
  validate: IDEA_ID_ONLY,                                                                                          // 117
  run: function () {                                                                                               // 118
    function run(_ref3) {                                                                                          // 115
      var ideaId = _ref3.ideaId;                                                                                   // 118
                                                                                                                   //
      var idea = Ideas.findOne(ideaId);                                                                            // 119
                                                                                                                   //
      if (!idea.editableBy(this.userId)) {                                                                         // 121
        throw new Meteor.Error('ideas.remove.accessDenied', "You don't have permission to remove this idea.");     // 122
      }                                                                                                            // 124
                                                                                                                   //
      Ideas.remove(ideaId);                                                                                        // 126
    }                                                                                                              // 127
                                                                                                                   //
    return run;                                                                                                    // 115
  }()                                                                                                              // 115
});                                                                                                                // 115
                                                                                                                   //
// Get list of all method names on ideas                                                                           // 130
var ideas_METHODS = _.pluck([insert, update, remove, markAsCompleted, createKanbanBoard], 'name');                 // 131
                                                                                                                   //
if (Meteor.isServer) {                                                                                             // 139
  // Only allow 5 list operations per connection per second                                                        // 140
  DDPRateLimiter.addRule({                                                                                         // 141
    name: function () {                                                                                            // 142
      function name(_name) {                                                                                       // 141
        return _.contains(ideas_METHODS, _name);                                                                   // 143
      }                                                                                                            // 144
                                                                                                                   //
      return name;                                                                                                 // 141
    }(),                                                                                                           // 141
                                                                                                                   //
                                                                                                                   //
    // Rate limit per connection ID                                                                                // 146
    connectionId: function () {                                                                                    // 147
      function connectionId() {                                                                                    // 141
        return true;                                                                                               // 147
      }                                                                                                            // 147
                                                                                                                   //
      return connectionId;                                                                                         // 141
    }()                                                                                                            // 141
  }, 5, 1000);                                                                                                     // 141
}                                                                                                                  // 149
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"profiles":{"server":{"publications.js":["meteor/meteor","../profiles",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/profiles/server/publications.js                                                                     //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Profiles;module.import('../profiles',{"Profiles":function(v){Profiles=v}});/* eslint-disable prefer-arrow-callback */
                                                                                                                   //
                                                                                                                   // 3
                                                                                                                   //
                                                                                                                   // 5
                                                                                                                   //
Meteor.publish('profiles.public', function () {                                                                    // 7
  return Profiles.find({}, { fields: Profiles.publicFields, sort: { createdAt: -1 } });                            // 8
});                                                                                                                // 9
Meteor.publish('profiles.users.public', function () {                                                              // 10
  return Meteor.users.find({}, { fields: { profile: 1, emails: 1 } });                                             // 11
});                                                                                                                // 12
Meteor.publish('profiles.public.findOne', function (ownerId) {                                                     // 13
  return Profiles.find({ ownerId: ownerId }, { fields: Profiles.publicFields });                                   // 14
});                                                                                                                // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods.js":["meteor/meteor","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","meteor/underscore","./profiles.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/profiles/methods.js                                                                                 //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({update:function(){return update}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Profiles;module.import('./profiles.js',{"Profiles":function(v){Profiles=v}});
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   // 4
                                                                                                                   // 5
                                                                                                                   //
                                                                                                                   // 8
                                                                                                                   //
function validateUserName(userName) {                                                                              // 10
  var count = Profiles.find({ userName: userName }).count();                                                       // 11
  if (count > 1) {                                                                                                 // 12
    throw new Meteor.Error('profile.userName.alreadyExist', 'Profile name is not available');                      // 13
  }                                                                                                                // 14
}                                                                                                                  // 15
                                                                                                                   //
var update = new ValidatedMethod({                                                                                 // 17
  name: 'profiles.update',                                                                                         // 18
  validate: new SimpleSchema({                                                                                     // 19
    userName: { type: String },                                                                                    // 20
    location: { type: String, optional: true }                                                                     // 21
  }).validator(),                                                                                                  // 19
  run: function () {                                                                                               // 23
    function run(_ref) {                                                                                           // 17
      var userName = _ref.userName;                                                                                // 23
      var location = _ref.location;                                                                                // 23
      var skills = _ref.skills;                                                                                    // 23
                                                                                                                   //
      if (!this.userId) {                                                                                          // 24
        throw new Error('not-authorized');                                                                         // 24
      }                                                                                                            // 24
                                                                                                                   //
      validateUserName(userName);                                                                                  // 26
                                                                                                                   //
      return Profiles.upsert({ ownerId: this.userId }, {                                                           // 28
        $set: {                                                                                                    // 29
          userName: userName,                                                                                      // 30
          location: location,                                                                                      // 31
          ownerId: this.userId                                                                                     // 32
        }                                                                                                          // 29
      });                                                                                                          // 28
    }                                                                                                              // 35
                                                                                                                   //
    return run;                                                                                                    // 17
  }()                                                                                                              // 17
});                                                                                                                // 17
                                                                                                                   //
// Get list of all method names on ideas                                                                           // 38
var profiles_METHODS = _.pluck([update], 'name');                                                                  // 39
                                                                                                                   //
if (Meteor.isServer) {                                                                                             // 44
  // Only allow 5 list operations per connection per second                                                        // 45
  DDPRateLimiter.addRule({                                                                                         // 46
    name: function () {                                                                                            // 47
      function name(_name) {                                                                                       // 46
        return _.contains(profiles_METHODS, _name);                                                                // 48
      }                                                                                                            // 49
                                                                                                                   //
      return name;                                                                                                 // 46
    }(),                                                                                                           // 46
                                                                                                                   //
                                                                                                                   //
    // Rate limit per connection ID                                                                                // 51
    connectionId: function () {                                                                                    // 52
      function connectionId() {                                                                                    // 46
        return true;                                                                                               // 52
      }                                                                                                            // 52
                                                                                                                   //
      return connectionId;                                                                                         // 46
    }()                                                                                                            // 46
  }, 5, 1000);                                                                                                     // 46
}                                                                                                                  // 54
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"profiles.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/aldeed:simple-schema","meteor/factory",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/profiles/profiles.js                                                                                //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({Profiles:function(){return Profiles}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Factory;module.import('meteor/factory',{"Factory":function(v){Factory=v}});
                                                                                                                   //
                                                                                                                   //
                                                                                                                   // 1
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   //
var ProfilesCollection = function (_Mongo$Collection) {                                                            //
  _inherits(ProfilesCollection, _Mongo$Collection);                                                                //
                                                                                                                   //
  function ProfilesCollection() {                                                                                  //
    _classCallCheck(this, ProfilesCollection);                                                                     //
                                                                                                                   //
    return _possibleConstructorReturn(this, _Mongo$Collection.apply(this, arguments));                             //
  }                                                                                                                //
                                                                                                                   //
  ProfilesCollection.prototype.remove = function () {                                                              //
    function remove(selector, callback) {                                                                          //
      return _Mongo$Collection.prototype.remove.call(this, selector, callback);                                    // 8
    }                                                                                                              // 9
                                                                                                                   //
    return remove;                                                                                                 //
  }();                                                                                                             //
                                                                                                                   //
  return ProfilesCollection;                                                                                       //
}(Mongo.Collection);                                                                                               //
                                                                                                                   //
var Profiles = new ProfilesCollection('profiles');                                                                 // 12
                                                                                                                   //
// Deny all client-side updates since we will be using methods to manage this collection                           // 14
Profiles.deny({                                                                                                    // 15
  insert: function () {                                                                                            // 16
    function insert() {                                                                                            // 15
      return true;                                                                                                 // 16
    }                                                                                                              // 16
                                                                                                                   //
    return insert;                                                                                                 // 15
  }(),                                                                                                             // 15
  update: function () {                                                                                            // 17
    function update() {                                                                                            // 15
      return true;                                                                                                 // 17
    }                                                                                                              // 17
                                                                                                                   //
    return update;                                                                                                 // 15
  }(),                                                                                                             // 15
  remove: function () {                                                                                            // 18
    function remove() {                                                                                            // 15
      return true;                                                                                                 // 18
    }                                                                                                              // 18
                                                                                                                   //
    return remove;                                                                                                 // 15
  }()                                                                                                              // 15
});                                                                                                                // 15
                                                                                                                   //
Profiles.schema = new SimpleSchema({                                                                               // 21
  userName: {                                                                                                      // 22
    type: String,                                                                                                  // 23
    defaultValue: ''                                                                                               // 24
  },                                                                                                               // 22
  education: {                                                                                                     // 26
    type: String,                                                                                                  // 27
    optional: true,                                                                                                // 28
    defaultValue: ''                                                                                               // 29
  },                                                                                                               // 26
  location: {                                                                                                      // 31
    type: String,                                                                                                  // 32
    optional: true,                                                                                                // 33
    defaultValue: ''                                                                                               // 34
  },                                                                                                               // 31
  ownerId: {                                                                                                       // 36
    type: String,                                                                                                  // 37
    regEx: SimpleSchema.RegEx.Id,                                                                                  // 38
    denyUpdate: true                                                                                               // 39
  },                                                                                                               // 36
  profileImage: {                                                                                                  // 41
    type: String,                                                                                                  // 42
    optional: true,                                                                                                // 43
    defaultValue: 'https://www.gravatar.com/avatar/00000000000000000000000000000000'                               // 44
  },                                                                                                               // 41
  ideasCount: {                                                                                                    // 46
    type: Number,                                                                                                  // 47
    optional: true,                                                                                                // 48
    defaultValue: 0                                                                                                // 49
  },                                                                                                               // 46
  followersCount: {                                                                                                // 51
    type: Number,                                                                                                  // 52
    optional: true,                                                                                                // 53
    defaultValue: 0                                                                                                // 54
  },                                                                                                               // 51
  followingCount: {                                                                                                // 56
    type: Number,                                                                                                  // 57
    optional: true,                                                                                                // 58
    defaultValue: 0                                                                                                // 59
  }                                                                                                                // 56
});                                                                                                                // 21
                                                                                                                   //
Profiles.attachSchema(Profiles.schema);                                                                            // 63
                                                                                                                   //
Profiles.publicFields = {                                                                                          // 65
  userName: 1,                                                                                                     // 66
  education: 1,                                                                                                    // 67
  location: 1,                                                                                                     // 68
  ownerId: 1,                                                                                                      // 69
  profileImage: 1,                                                                                                 // 70
                                                                                                                   //
  ideasCount: 1,                                                                                                   // 72
  followersCount: 1,                                                                                               // 73
  followingCount: 1                                                                                                // 74
};                                                                                                                 // 65
                                                                                                                   //
Factory.define('Profile', Profiles, {});                                                                           // 77
                                                                                                                   //
Profiles.helpers({                                                                                                 // 79
  editableBy: function () {                                                                                        // 81
    function editableBy(userId) {                                                                                  // 79
      if (!this.ownerId) {                                                                                         // 82
        return true;                                                                                               // 83
      }                                                                                                            // 84
                                                                                                                   //
      return this.ownerId === userId;                                                                              // 86
    }                                                                                                              // 87
                                                                                                                   //
    return editableBy;                                                                                             // 79
  }()                                                                                                              // 79
});                                                                                                                // 79
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"sprints":{"server":{"publications.js":["meteor/meteor","../sprints.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/sprints/server/publications.js                                                                      //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Sprints;module.import('../sprints.js',{"Sprints":function(v){Sprints=v}});/* eslint-disable prefer-arrow-callback */
                                                                                                                   //
                                                                                                                   // 3
                                                                                                                   //
                                                                                                                   // 5
                                                                                                                   //
Meteor.publish('sprints.public', function () {                                                                     // 7
  return Sprints.find({}, { fields: Sprints.publicFields, sort: { createdAt: 1 } });                               // 8
});                                                                                                                // 9
Meteor.publish('sprints.forTeam', function (teamId) {                                                              // 10
  return Sprints.find({ teamId: teamId }, { fields: Sprints.publicFields });                                       // 11
});                                                                                                                // 12
Meteor.publish('sprints.public.findOne', function (sprintId) {                                                     // 13
  return Sprints.find({ _id: sprintId }, { fields: Sprints.publicFields });                                        // 14
});                                                                                                                // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods.js":["meteor/meteor","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","meteor/underscore","../teams/teams.js","./sprints.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/sprints/methods.js                                                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({insert:function(){return insert},update:function(){return update},remove:function(){return remove}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Teams;module.import('../teams/teams.js',{"Teams":function(v){Teams=v}});var Sprints;module.import('./sprints.js',{"Sprints":function(v){Sprints=v}});
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   // 4
                                                                                                                   // 5
                                                                                                                   //
                                                                                                                   // 7
                                                                                                                   // 8
                                                                                                                   //
function validateSprintName(name) {                                                                                // 12
  var count = Sprints.find({ name: name }).count();                                                                // 13
  if (count > 1) {                                                                                                 // 14
    throw new Meteor.Error('sprint.name.alreadyExist', 'Sprint with the specified name already exist');            // 15
  }                                                                                                                // 16
}                                                                                                                  // 17
                                                                                                                   //
var SPRINT_ID_ONLY = new SimpleSchema({                                                                            // 19
  sprintId: { type: String }                                                                                       // 20
}).validator();                                                                                                    // 19
                                                                                                                   //
var insert = new ValidatedMethod({                                                                                 // 23
  name: 'sprints.insert',                                                                                          // 24
  validate: new SimpleSchema({                                                                                     // 25
    name: { type: String },                                                                                        // 26
    goals: { type: String },                                                                                       // 27
    teamId: {                                                                                                      // 28
      type: String,                                                                                                // 29
      regEx: SimpleSchema.RegEx.Id                                                                                 // 30
    },                                                                                                             // 28
    startDate: {                                                                                                   // 32
      type: Date                                                                                                   // 33
    },                                                                                                             // 32
    endDate: {                                                                                                     // 35
      type: Date                                                                                                   // 36
    }                                                                                                              // 35
  }).validator(),                                                                                                  // 25
  run: function () {                                                                                               // 39
    function run(_ref) {                                                                                           // 23
      var name = _ref.name;                                                                                        // 39
      var goals = _ref.goals;                                                                                      // 39
      var teamId = _ref.teamId;                                                                                    // 39
      var startDate = _ref.startDate;                                                                              // 39
      var endDate = _ref.endDate;                                                                                  // 39
                                                                                                                   //
      if (!this.userId) {                                                                                          // 40
        throw new Error('not-authorized');                                                                         // 40
      }                                                                                                            // 40
                                                                                                                   //
      var team = Teams.findOne(teamId);                                                                            // 42
                                                                                                                   //
      if (!team) {                                                                                                 // 44
        throw new Meteor.Error('sprint.create.teamNotFound', 'team not found');                                    // 45
      }                                                                                                            // 46
                                                                                                                   //
      if (!team.editableBy(this.userId)) {                                                                         // 48
        throw new Meteor.Error('sprints.update.accessDenied', "You don't have permission to edit this team.");     // 49
      }                                                                                                            // 51
                                                                                                                   //
      validateSprintName(name);                                                                                    // 53
                                                                                                                   //
      var newSprint = { name: name, goals: goals, teamId: teamId, startDate: startDate, endDate: endDate };        // 55
      newSprint.ownerId = this.userId;                                                                             // 56
                                                                                                                   //
      newSprint.createdAt = Date.now();                                                                            // 58
                                                                                                                   //
      return Sprints.insert(newSprint);                                                                            // 61
    }                                                                                                              // 62
                                                                                                                   //
    return run;                                                                                                    // 23
  }()                                                                                                              // 23
});                                                                                                                // 23
                                                                                                                   //
var update = new ValidatedMethod({                                                                                 // 65
  name: 'sprints.update',                                                                                          // 66
  validate: new SimpleSchema({                                                                                     // 67
    sprintId: { type: String, regEx: SimpleSchema.RegEx.Id },                                                      // 68
    name: { type: String, optional: true },                                                                        // 69
    goals: { type: String, optional: true },                                                                       // 70
    startDate: { type: Date, optional: true },                                                                     // 71
    endDate: { type: Date, optional: true }                                                                        // 72
  }).validator(),                                                                                                  // 67
  run: function () {                                                                                               // 74
    function run(_ref2) {                                                                                          // 65
      var sprintId = _ref2.sprintId;                                                                               // 74
      var name = _ref2.name;                                                                                       // 74
      var goals = _ref2.goals;                                                                                     // 74
                                                                                                                   //
      if (!this.userId) {                                                                                          // 75
        throw new Error('not-authorized');                                                                         // 75
      }                                                                                                            // 75
                                                                                                                   //
      var sprint = Sprints.findOne(sprintId);                                                                      // 77
                                                                                                                   //
      if (!sprint.editableBy(this.userId)) {                                                                       // 79
        throw new Meteor.Error('sprints.update.accessDenied', "You don't have permission to edit this sprint.");   // 80
      }                                                                                                            // 82
                                                                                                                   //
      if (name !== sprint.name) {                                                                                  // 84
        validateSprintName(name);                                                                                  // 85
      }                                                                                                            // 86
                                                                                                                   //
      var data = { name: name, goals: sprint.goals, startDate: sprint.startDate, endDate: sprint.endDate };        // 88
                                                                                                                   //
      if (goals) {                                                                                                 // 90
        data.goals = goals;                                                                                        // 91
      }                                                                                                            // 92
                                                                                                                   //
      if (startDate) {                                                                                             // 94
        data.startDate = startDate;                                                                                // 95
      }                                                                                                            // 96
                                                                                                                   //
      if (endDate) {                                                                                               // 98
        data.endDate = endDate;                                                                                    // 99
      }                                                                                                            // 100
                                                                                                                   //
      if (data.startDate >= data.endDate) {                                                                        // 102
        throw new Meteor.Error('sprints.startDate.validation', 'Sprint start date cannot be ahead of end date');   // 103
      }                                                                                                            // 104
                                                                                                                   //
      // XXX the security check above is not atomic, so in theory a race condition could                           // 107
      // result in exposing private data                                                                           // 108
                                                                                                                   //
      Sprints.update(sprintId, {                                                                                   // 110
        $set: data                                                                                                 // 111
      });                                                                                                          // 110
    }                                                                                                              // 113
                                                                                                                   //
    return run;                                                                                                    // 65
  }()                                                                                                              // 65
});                                                                                                                // 65
                                                                                                                   //
var remove = new ValidatedMethod({                                                                                 // 117
  name: 'sprints.remove',                                                                                          // 118
  validate: SPRINT_ID_ONLY,                                                                                        // 119
  run: function () {                                                                                               // 120
    function run(_ref3) {                                                                                          // 117
      var sprintId = _ref3.sprintId;                                                                               // 120
                                                                                                                   //
      if (!this.userId) {                                                                                          // 121
        throw new Error('not-authorized');                                                                         // 121
      }                                                                                                            // 121
                                                                                                                   //
      var sprint = Sprints.findOne(sprintId);                                                                      // 123
                                                                                                                   //
      if (!sprint.editableBy(this.userId)) {                                                                       // 125
        throw new Meteor.Error('sprints.remove.accessDenied', "You don't have permission to remove this sprint.");
      }                                                                                                            // 128
                                                                                                                   //
      Sprints.remove(sprintId);                                                                                    // 130
    }                                                                                                              // 131
                                                                                                                   //
    return run;                                                                                                    // 117
  }()                                                                                                              // 117
});                                                                                                                // 117
                                                                                                                   //
// Get list of all method names on teams                                                                           // 134
var teams_METHODS = _.pluck([insert, update, remove], 'name');                                                     // 135
                                                                                                                   //
if (Meteor.isServer) {                                                                                             // 141
  // Only allow 5 list operations per connection per second                                                        // 142
  DDPRateLimiter.addRule({                                                                                         // 143
    name: function () {                                                                                            // 144
      function name(_name) {                                                                                       // 143
        return _.contains(teams_METHODS, _name);                                                                   // 145
      }                                                                                                            // 146
                                                                                                                   //
      return name;                                                                                                 // 143
    }(),                                                                                                           // 143
                                                                                                                   //
                                                                                                                   //
    // Rate limit per connection ID                                                                                // 148
    connectionId: function () {                                                                                    // 149
      function connectionId() {                                                                                    // 143
        return true;                                                                                               // 149
      }                                                                                                            // 149
                                                                                                                   //
      return connectionId;                                                                                         // 143
    }()                                                                                                            // 143
  }, 5, 1000);                                                                                                     // 143
}                                                                                                                  // 151
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"sprints.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/aldeed:simple-schema","meteor/factory","../teams/teams",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/sprints/sprints.js                                                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({Sprints:function(){return Sprints}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Factory;module.import('meteor/factory',{"Factory":function(v){Factory=v}});var Teams;module.import('../teams/teams',{"Teams":function(v){Teams=v}});
                                                                                                                   //
                                                                                                                   //
                                                                                                                   // 1
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   // 4
                                                                                                                   //
var SprintsCollection = function (_Mongo$Collection) {                                                             //
  _inherits(SprintsCollection, _Mongo$Collection);                                                                 //
                                                                                                                   //
  function SprintsCollection() {                                                                                   //
    _classCallCheck(this, SprintsCollection);                                                                      //
                                                                                                                   //
    return _possibleConstructorReturn(this, _Mongo$Collection.apply(this, arguments));                             //
  }                                                                                                                //
                                                                                                                   //
  SprintsCollection.prototype.insert = function () {                                                               //
    function insert(sprint, callback) {                                                                            //
      var thisSprint = sprint;                                                                                     // 8
      return _Mongo$Collection.prototype.insert.call(this, thisSprint, callback);                                  // 9
    }                                                                                                              // 10
                                                                                                                   //
    return insert;                                                                                                 //
  }();                                                                                                             //
                                                                                                                   //
  SprintsCollection.prototype.remove = function () {                                                               //
    function remove(selector, callback) {                                                                          //
      return _Mongo$Collection.prototype.remove.call(this, selector, callback);                                    // 12
    }                                                                                                              // 13
                                                                                                                   //
    return remove;                                                                                                 //
  }();                                                                                                             //
                                                                                                                   //
  return SprintsCollection;                                                                                        //
}(Mongo.Collection);                                                                                               //
                                                                                                                   //
var Sprints = new SprintsCollection('sprints');                                                                    // 16
                                                                                                                   //
// Deny all client-side updates since we will be using methods to manage this collection                           // 18
Sprints.deny({                                                                                                     // 19
  insert: function () {                                                                                            // 20
    function insert() {                                                                                            // 19
      return true;                                                                                                 // 20
    }                                                                                                              // 20
                                                                                                                   //
    return insert;                                                                                                 // 19
  }(),                                                                                                             // 19
  update: function () {                                                                                            // 21
    function update() {                                                                                            // 19
      return true;                                                                                                 // 21
    }                                                                                                              // 21
                                                                                                                   //
    return update;                                                                                                 // 19
  }(),                                                                                                             // 19
  remove: function () {                                                                                            // 22
    function remove() {                                                                                            // 19
      return true;                                                                                                 // 22
    }                                                                                                              // 22
                                                                                                                   //
    return remove;                                                                                                 // 19
  }()                                                                                                              // 19
});                                                                                                                // 19
                                                                                                                   //
Sprints.schema = new SimpleSchema({                                                                                // 25
  name: {                                                                                                          // 26
    type: String                                                                                                   // 27
  },                                                                                                               // 26
  goals: {                                                                                                         // 29
    type: String                                                                                                   // 30
  },                                                                                                               // 29
  teamId: {                                                                                                        // 32
    type: String,                                                                                                  // 33
    regEx: SimpleSchema.RegEx.Id,                                                                                  // 34
    denyUpdate: true                                                                                               // 35
  },                                                                                                               // 32
  startDate: {                                                                                                     // 37
    type: Date                                                                                                     // 38
  },                                                                                                               // 37
  status: {                                                                                                        // 40
    type: String,                                                                                                  // 41
    defaultValue: 'created'                                                                                        // 42
  },                                                                                                               // 40
  endDate: {                                                                                                       // 44
    type: Date                                                                                                     // 45
  },                                                                                                               // 44
  createdAt: {                                                                                                     // 47
    type: Date                                                                                                     // 48
  },                                                                                                               // 47
  ownerId: {                                                                                                       // 50
    type: String,                                                                                                  // 51
    regEx: SimpleSchema.RegEx.Id                                                                                   // 52
  }                                                                                                                // 50
});                                                                                                                // 25
                                                                                                                   //
Sprints.attachSchema(Sprints.schema);                                                                              // 56
                                                                                                                   //
Sprints.publicFields = {                                                                                           // 58
  name: 1,                                                                                                         // 59
  teamId: 1,                                                                                                       // 60
  goals: 1,                                                                                                        // 61
  status: 1,                                                                                                       // 62
  startDate: 1,                                                                                                    // 63
  endDate: 1,                                                                                                      // 64
  createdAt: 1,                                                                                                    // 65
  ownerId: 1                                                                                                       // 66
};                                                                                                                 // 58
                                                                                                                   //
Factory.define('Sprint', Sprints, {});                                                                             // 69
                                                                                                                   //
Sprints.helpers({                                                                                                  // 71
  getOwner: function () {                                                                                          // 72
    function getOwner() {                                                                                          // 71
      var _Meteor$users$findOne = Meteor.users.findOne(this.ownerId);                                              // 72
                                                                                                                   //
      var _id = _Meteor$users$findOne._id;                                                                         // 72
      var profile = _Meteor$users$findOne.profile;                                                                 // 72
                                                                                                                   //
      return { _id: _id, profile: profile };                                                                       // 74
    }                                                                                                              // 75
                                                                                                                   //
    return getOwner;                                                                                               // 71
  }(),                                                                                                             // 71
  getIdea: function () {                                                                                           // 76
    function getIdea() {                                                                                           // 71
      return Ideas.findOne(this.ideaId);                                                                           // 77
    }                                                                                                              // 78
                                                                                                                   //
    return getIdea;                                                                                                // 71
  }(),                                                                                                             // 71
  editableBy: function () {                                                                                        // 79
    function editableBy(userId) {                                                                                  // 71
      if (!this.ownerId) {                                                                                         // 80
        return true;                                                                                               // 81
      }                                                                                                            // 82
                                                                                                                   //
      return this.ownerId === userId;                                                                              // 84
    }                                                                                                              // 85
                                                                                                                   //
    return editableBy;                                                                                             // 71
  }()                                                                                                              // 71
});                                                                                                                // 71
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"teams":{"server":{"publications.js":["meteor/meteor","../teams.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/teams/server/publications.js                                                                        //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Teams;module.import('../teams.js',{"Teams":function(v){Teams=v}});/* eslint-disable prefer-arrow-callback */
                                                                                                                   //
                                                                                                                   // 3
                                                                                                                   //
                                                                                                                   // 5
                                                                                                                   //
Meteor.publish('teams.public', function () {                                                                       // 7
  return Teams.find({}, { fields: Teams.publicFields, sort: { createdAt: -1 } });                                  // 8
});                                                                                                                // 9
Meteor.publish('teams.public.findOne', function (ideaId) {                                                         // 10
  return Teams.find({ ideaId: ideaId }, { fields: Teams.publicFields });                                           // 11
});                                                                                                                // 12
                                                                                                                   //
Meteor.publish('account.allusers', function (ideaId) {                                                             // 14
  return Meteor.users.find({}, { fields: { profile: 1, _id: 1 } });                                                // 15
});                                                                                                                // 16
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods.js":["meteor/meteor","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","meteor/underscore","../ideas/ideas.js","./teams.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/teams/methods.js                                                                                    //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({insert:function(){return insert},update:function(){return update},addMember:function(){return addMember},removeMember:function(){return removeMember},remove:function(){return remove}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Ideas;module.import('../ideas/ideas.js',{"Ideas":function(v){Ideas=v}});var Teams;module.import('./teams.js',{"Teams":function(v){Teams=v}});
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   // 4
                                                                                                                   // 5
                                                                                                                   //
                                                                                                                   // 7
                                                                                                                   // 8
                                                                                                                   //
function validateTeamName(name) {                                                                                  // 10
  var count = Teams.find({ name: name }).count();                                                                  // 11
  if (count > 1) {                                                                                                 // 12
    throw new Meteor.Error('team.name.alreadyExist', 'Team with the specified name already exist');                // 13
  }                                                                                                                // 14
}                                                                                                                  // 15
                                                                                                                   //
var TEAM_ID_ONLY = new SimpleSchema({                                                                              // 17
  teamId: { type: String }                                                                                         // 18
}).validator();                                                                                                    // 17
                                                                                                                   //
var insert = new ValidatedMethod({                                                                                 // 21
  name: 'teams.insert',                                                                                            // 22
  validate: new SimpleSchema({                                                                                     // 23
    name: { type: String },                                                                                        // 24
    ideaId: {                                                                                                      // 25
      type: String,                                                                                                // 26
      regEx: SimpleSchema.RegEx.Id                                                                                 // 27
    },                                                                                                             // 25
    'members.$.memberId': {                                                                                        // 29
      type: String,                                                                                                // 30
      regEx: SimpleSchema.RegEx.Id                                                                                 // 31
    }                                                                                                              // 29
  }).validator(),                                                                                                  // 23
  run: function () {                                                                                               // 34
    function run(_ref) {                                                                                           // 21
      var name = _ref.name;                                                                                        // 34
      var ideaId = _ref.ideaId;                                                                                    // 34
      var members = _ref.members;                                                                                  // 34
                                                                                                                   //
      if (!this.userId) {                                                                                          // 35
        throw new Error('not-authorized');                                                                         // 35
      }                                                                                                            // 35
                                                                                                                   //
      var idea = Ideas.findOne(ideaId);                                                                            // 37
                                                                                                                   //
      if (!idea) {                                                                                                 // 39
        throw new Meteor.Error('team.create.ideaNotFound', 'idea not found');                                      // 40
      }                                                                                                            // 41
                                                                                                                   //
      if (!idea.editableBy(this.userId)) {                                                                         // 43
        throw new Meteor.Error('teams.update.accessDenied', "You don't have permission to edit this team.");       // 44
      }                                                                                                            // 46
                                                                                                                   //
      var existingTeam = Teams.findOne({ ideaId: ideaId });                                                        // 48
      if (existingTeam) {                                                                                          // 49
        throw new Meteor.Error('teams.insert.alreadyExist', 'The team is already been formed for this idea, please delete the existing team.');
      }                                                                                                            // 52
                                                                                                                   //
      validateTeamName(name);                                                                                      // 54
                                                                                                                   //
      var newteam = { name: name, ideaId: ideaId };                                                                // 56
      newteam.ownerId = this.userId;                                                                               // 57
      newteam.ownerName = Meteor.user().profile.fullName;                                                          // 58
      newteam.createdAt = Date.now();                                                                              // 59
      newteam.members = Meteor.users.find({ _id: { $in: members.map(function (mem) {                               // 60
            return mem.memberId;                                                                                   // 61
          }) } }, { fields: { _id: 1, profile: 1 } }).fetch().map(function (member) {                              // 61
        return { memberName: member.profile.fullName, memberId: member._id };                                      // 64
      });                                                                                                          // 65
                                                                                                                   //
      return Teams.insert(newteam);                                                                                // 67
    }                                                                                                              // 68
                                                                                                                   //
    return run;                                                                                                    // 21
  }()                                                                                                              // 21
});                                                                                                                // 21
                                                                                                                   //
var update = new ValidatedMethod({                                                                                 // 71
  name: 'teams.update',                                                                                            // 72
  validate: new SimpleSchema({                                                                                     // 73
    teamId: { type: String, regEx: SimpleSchema.RegEx.Id },                                                        // 74
    name: { type: String, optional: true },                                                                        // 75
    'members.$.memberId': {                                                                                        // 76
      type: String,                                                                                                // 77
      regEx: SimpleSchema.RegEx.Id,                                                                                // 78
      optional: true                                                                                               // 79
    }                                                                                                              // 76
  }).validator(),                                                                                                  // 73
  run: function () {                                                                                               // 82
    function run(_ref2) {                                                                                          // 71
      var teamId = _ref2.teamId;                                                                                   // 82
      var name = _ref2.name;                                                                                       // 82
      var members = _ref2.members;                                                                                 // 82
                                                                                                                   //
      if (!this.userId) {                                                                                          // 83
        throw new Error('not-authorized');                                                                         // 83
      }                                                                                                            // 83
                                                                                                                   //
      var team = Teams.findOne(teamId);                                                                            // 85
                                                                                                                   //
      if (!team.editableBy(this.userId)) {                                                                         // 87
        throw new Meteor.Error('teams.update.accessDenied', "You don't have permission to edit this team.");       // 88
      }                                                                                                            // 90
                                                                                                                   //
      if (name !== team.name) {                                                                                    // 92
        validateTeamName(name);                                                                                    // 93
      }                                                                                                            // 94
                                                                                                                   //
      var data = { name: name };                                                                                   // 96
                                                                                                                   //
      if (members) {                                                                                               // 98
        data.members = Meteor.users.find({ _id: { $in: members.map(function (mem) {                                // 99
              return mem.memberId;                                                                                 // 100
            }) } }, { fields: { _id: 1, profile: 1 } }).fetch().map(function (member) {                            // 100
          return { memberName: member.profile.fullName, memberId: member._id };                                    // 103
        });                                                                                                        // 104
      }                                                                                                            // 105
                                                                                                                   //
      // XXX the security check above is not atomic, so in theory a race condition could                           // 107
      // result in exposing private data                                                                           // 108
                                                                                                                   //
      Teams.update(teamId, {                                                                                       // 110
        $set: data                                                                                                 // 111
      });                                                                                                          // 110
    }                                                                                                              // 113
                                                                                                                   //
    return run;                                                                                                    // 71
  }()                                                                                                              // 71
});                                                                                                                // 71
                                                                                                                   //
var addMember = new ValidatedMethod({                                                                              // 116
  name: 'teams.addMember',                                                                                         // 117
  validate: new SimpleSchema({                                                                                     // 118
    'teamId': { type: String, regEx: SimpleSchema.RegEx.Id },                                                      // 119
    'userId': { type: String, regEx: SimpleSchema.RegEx.Id }                                                       // 120
  }).validator(),                                                                                                  // 118
  run: function () {                                                                                               // 122
    function run(_ref3) {                                                                                          // 116
      var teamId = _ref3.teamId;                                                                                   // 122
      var userId = _ref3.userId;                                                                                   // 122
                                                                                                                   //
      if (!this.userId) {                                                                                          // 123
        throw new Error('not-authorized');                                                                         // 123
      }                                                                                                            // 123
                                                                                                                   //
      var team = Teams.findOne(teamId);                                                                            // 125
                                                                                                                   //
      if (!team.editableBy(this.userId)) {                                                                         // 127
        throw new Meteor.Error('teams.update.accessDenied', "You don't have permission to edit this team.");       // 128
      }                                                                                                            // 130
                                                                                                                   //
      var userToAdd = Meteor.users.findOne(userId);                                                                // 132
                                                                                                                   //
      if (!userToAdd) {                                                                                            // 134
        throw new Error('user not found');                                                                         // 135
      }                                                                                                            // 136
                                                                                                                   //
      if (!_.contains(team.members, userToAdd._id)) {                                                              // 138
        team.members.push({ memberName: userToAdd.profile.fullName, memberId: userToAdd._id });                    // 139
      }                                                                                                            // 140
                                                                                                                   //
      // XXX the security check above is not atomic, so in theory a race condition could                           // 142
      // result in exposing private data                                                                           // 143
                                                                                                                   //
      Teams.update(teamId, {                                                                                       // 145
        $set: { members: team.members }                                                                            // 146
      });                                                                                                          // 145
    }                                                                                                              // 148
                                                                                                                   //
    return run;                                                                                                    // 116
  }()                                                                                                              // 116
});                                                                                                                // 116
                                                                                                                   //
var removeMember = new ValidatedMethod({                                                                           // 151
  name: 'teams.removeMember',                                                                                      // 152
  validate: new SimpleSchema({                                                                                     // 153
    'teamId': { type: String, regEx: SimpleSchema.RegEx.Id },                                                      // 154
    'userId': { type: String, regEx: SimpleSchema.RegEx.Id }                                                       // 155
  }).validator(),                                                                                                  // 153
  run: function () {                                                                                               // 157
    function run(_ref4) {                                                                                          // 151
      var teamId = _ref4.teamId;                                                                                   // 157
      var userId = _ref4.userId;                                                                                   // 157
                                                                                                                   //
      if (!this.userId) {                                                                                          // 158
        throw new Error('not-authorized');                                                                         // 158
      }                                                                                                            // 158
                                                                                                                   //
      var team = Teams.findOne(teamId);                                                                            // 160
                                                                                                                   //
      if (!team.editableBy(this.userId)) {                                                                         // 162
        throw new Meteor.Error('teams.update.accessDenied', "You don't have permission to edit this team.");       // 163
      }                                                                                                            // 165
                                                                                                                   //
      var userToRemove = Meteor.users.findOne(userId);                                                             // 167
                                                                                                                   //
      if (!userToRemove) {                                                                                         // 169
        throw new Error('user not found');                                                                         // 170
      }                                                                                                            // 171
                                                                                                                   //
      if (!_.contains(team.members, userToRemove._id)) {                                                           // 173
        throw new Error('user not a member already');                                                              // 174
      }                                                                                                            // 175
                                                                                                                   //
      var memberToRemove = _.findWhere(team.members, { memberId: userToRemove._id });                              // 177
      var index = team.members.indexOf(memberToRemove);                                                            // 178
                                                                                                                   //
      team.members.splice(index, 1);                                                                               // 180
                                                                                                                   //
      // XXX the security check above is not atomic, so in theory a race condition could                           // 182
      // result in exposing private data                                                                           // 183
                                                                                                                   //
      Teams.update(teamId, {                                                                                       // 185
        $set: { members: team.members }                                                                            // 186
      });                                                                                                          // 185
    }                                                                                                              // 188
                                                                                                                   //
    return run;                                                                                                    // 151
  }()                                                                                                              // 151
});                                                                                                                // 151
                                                                                                                   //
var remove = new ValidatedMethod({                                                                                 // 191
  name: 'teams.remove',                                                                                            // 192
  validate: TEAM_ID_ONLY,                                                                                          // 193
  run: function () {                                                                                               // 194
    function run(_ref5) {                                                                                          // 191
      var teamId = _ref5.teamId;                                                                                   // 194
                                                                                                                   //
      if (!this.userId) {                                                                                          // 195
        throw new Error('not-authorized');                                                                         // 195
      }                                                                                                            // 195
                                                                                                                   //
      var team = Teams.findOne(teamId);                                                                            // 197
                                                                                                                   //
      if (!team.editableBy(this.userId)) {                                                                         // 199
        throw new Meteor.Error('teams.remove.accessDenied', "You don't have permission to remove this team.");     // 200
      }                                                                                                            // 202
                                                                                                                   //
      Teams.remove(teamId);                                                                                        // 204
    }                                                                                                              // 205
                                                                                                                   //
    return run;                                                                                                    // 191
  }()                                                                                                              // 191
});                                                                                                                // 191
                                                                                                                   //
// Get list of all method names on teams                                                                           // 208
var teams_METHODS = _.pluck([insert, update, remove], 'name');                                                     // 209
                                                                                                                   //
if (Meteor.isServer) {                                                                                             // 215
  // Only allow 5 list operations per connection per second                                                        // 216
  DDPRateLimiter.addRule({                                                                                         // 217
    name: function () {                                                                                            // 218
      function name(_name) {                                                                                       // 217
        return _.contains(teams_METHODS, _name);                                                                   // 219
      }                                                                                                            // 220
                                                                                                                   //
      return name;                                                                                                 // 217
    }(),                                                                                                           // 217
                                                                                                                   //
                                                                                                                   //
    // Rate limit per connection ID                                                                                // 222
    connectionId: function () {                                                                                    // 223
      function connectionId() {                                                                                    // 217
        return true;                                                                                               // 223
      }                                                                                                            // 223
                                                                                                                   //
      return connectionId;                                                                                         // 217
    }()                                                                                                            // 217
  }, 5, 1000);                                                                                                     // 217
}                                                                                                                  // 225
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"teams.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/aldeed:simple-schema","meteor/factory","../ideas/ideas",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/teams/teams.js                                                                                      //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({Teams:function(){return Teams}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Factory;module.import('meteor/factory',{"Factory":function(v){Factory=v}});var Ideas;module.import('../ideas/ideas',{"Ideas":function(v){Ideas=v}});
                                                                                                                   //
                                                                                                                   //
                                                                                                                   // 1
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   // 4
                                                                                                                   //
var TeamsCollection = function (_Mongo$Collection) {                                                               //
  _inherits(TeamsCollection, _Mongo$Collection);                                                                   //
                                                                                                                   //
  function TeamsCollection() {                                                                                     //
    _classCallCheck(this, TeamsCollection);                                                                        //
                                                                                                                   //
    return _possibleConstructorReturn(this, _Mongo$Collection.apply(this, arguments));                             //
  }                                                                                                                //
                                                                                                                   //
  TeamsCollection.prototype.insert = function () {                                                                 //
    function insert(team, callback) {                                                                              //
      var ourTeam = team;                                                                                          // 8
      return _Mongo$Collection.prototype.insert.call(this, ourTeam, callback);                                     // 9
    }                                                                                                              // 10
                                                                                                                   //
    return insert;                                                                                                 //
  }();                                                                                                             //
                                                                                                                   //
  TeamsCollection.prototype.remove = function () {                                                                 //
    function remove(selector, callback) {                                                                          //
      return _Mongo$Collection.prototype.remove.call(this, selector, callback);                                    // 12
    }                                                                                                              // 13
                                                                                                                   //
    return remove;                                                                                                 //
  }();                                                                                                             //
                                                                                                                   //
  return TeamsCollection;                                                                                          //
}(Mongo.Collection);                                                                                               //
                                                                                                                   //
var Teams = new TeamsCollection('Teams');                                                                          // 16
                                                                                                                   //
// Deny all client-side updates since we will be using methods to manage this collection                           // 18
Teams.deny({                                                                                                       // 19
  insert: function () {                                                                                            // 20
    function insert() {                                                                                            // 19
      return true;                                                                                                 // 20
    }                                                                                                              // 20
                                                                                                                   //
    return insert;                                                                                                 // 19
  }(),                                                                                                             // 19
  update: function () {                                                                                            // 21
    function update() {                                                                                            // 19
      return true;                                                                                                 // 21
    }                                                                                                              // 21
                                                                                                                   //
    return update;                                                                                                 // 19
  }(),                                                                                                             // 19
  remove: function () {                                                                                            // 22
    function remove() {                                                                                            // 19
      return true;                                                                                                 // 22
    }                                                                                                              // 22
                                                                                                                   //
    return remove;                                                                                                 // 19
  }()                                                                                                              // 19
});                                                                                                                // 19
                                                                                                                   //
Teams.schema = new SimpleSchema({                                                                                  // 25
  name: {                                                                                                          // 26
    type: String                                                                                                   // 27
  },                                                                                                               // 26
  'members.$.memberId': {                                                                                          // 29
    type: String,                                                                                                  // 30
    regEx: SimpleSchema.RegEx.Id                                                                                   // 31
  },                                                                                                               // 29
  'members.$.memberName': {                                                                                        // 33
    type: String                                                                                                   // 34
  },                                                                                                               // 33
  ideaId: {                                                                                                        // 36
    type: String,                                                                                                  // 37
    regEx: SimpleSchema.RegEx.Id,                                                                                  // 38
    denyUpdate: true                                                                                               // 39
  },                                                                                                               // 36
  createdAt: {                                                                                                     // 41
    type: Date                                                                                                     // 42
  },                                                                                                               // 41
  ownerId: {                                                                                                       // 44
    type: String,                                                                                                  // 45
    regEx: SimpleSchema.RegEx.Id                                                                                   // 46
  }                                                                                                                // 44
});                                                                                                                // 25
                                                                                                                   //
Teams.attachSchema(Teams.schema);                                                                                  // 50
                                                                                                                   //
Teams.publicFields = {                                                                                             // 52
  name: 1,                                                                                                         // 53
  ideaId: 1,                                                                                                       // 54
  members: 1,                                                                                                      // 55
  createdAt: 1,                                                                                                    // 56
  ownerId: 1                                                                                                       // 57
};                                                                                                                 // 52
                                                                                                                   //
Factory.define('Team', Teams, {});                                                                                 // 60
                                                                                                                   //
Teams.helpers({                                                                                                    // 62
  owner: function () {                                                                                             // 63
    function owner() {                                                                                             // 62
      var _Meteor$users$findOne = Meteor.users.findOne(this.ownerId);                                              // 63
                                                                                                                   //
      var _id = _Meteor$users$findOne._id;                                                                         // 63
      var profile = _Meteor$users$findOne.profile;                                                                 // 63
                                                                                                                   //
      return { _id: _id, profile: profile };                                                                       // 65
    }                                                                                                              // 66
                                                                                                                   //
    return owner;                                                                                                  // 62
  }(),                                                                                                             // 62
  getIdea: function () {                                                                                           // 67
    function getIdea() {                                                                                           // 62
      return Ideas.findOne(this.ideaId);                                                                           // 68
    }                                                                                                              // 69
                                                                                                                   //
    return getIdea;                                                                                                // 62
  }(),                                                                                                             // 62
  editableBy: function () {                                                                                        // 70
    function editableBy(userId) {                                                                                  // 62
      if (!this.ownerId) {                                                                                         // 71
        return true;                                                                                               // 72
      }                                                                                                            // 73
                                                                                                                   //
      return this.ownerId === userId;                                                                              // 75
    }                                                                                                              // 76
                                                                                                                   //
    return editableBy;                                                                                             // 62
  }()                                                                                                              // 62
});                                                                                                                // 62
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"votes":{"methods.js":["meteor/meteor","meteor/underscore","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","./votes","../ideas/ideas",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/votes/methods.js                                                                                    //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({cast:function(){return cast}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var Votes;module.import('./votes',{"Votes":function(v){Votes=v}});var Ideas;module.import('../ideas/ideas',{"Ideas":function(v){Ideas=v}});
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   // 4
                                                                                                                   // 5
                                                                                                                   //
                                                                                                                   // 7
                                                                                                                   // 8
                                                                                                                   //
var cast = new ValidatedMethod({                                                                                   // 10
  name: 'votes.cast',                                                                                              // 11
  validate: new SimpleSchema({                                                                                     // 12
    ideaId: { type: String },                                                                                      // 13
    isUpVote: { type: Boolean }                                                                                    // 14
  }).validator(),                                                                                                  // 12
  run: function () {                                                                                               // 16
    function run(_ref) {                                                                                           // 10
      var ideaId = _ref.ideaId;                                                                                    // 16
      var isUpVote = _ref.isUpVote;                                                                                // 16
                                                                                                                   //
      var idea = Ideas.findOne(ideaId);                                                                            // 17
      if (!idea) {                                                                                                 // 18
        throw new Meteor.Error('idea-not-found');                                                                  // 19
      }                                                                                                            // 20
                                                                                                                   //
      var castedVote = Votes.findOne({ ideaId: ideaId, ownerId: this.userId });                                    // 22
      if (!castedVote) {                                                                                           // 23
        var ownerName = Meteor.user().profile.fullName;                                                            // 24
        var ownerId = this.userId;                                                                                 // 25
        var vote = { ideaId: ideaId, isUpVote: isUpVote, ownerId: ownerId, ownerName: ownerName };                 // 26
        Votes.insert(vote);                                                                                        // 27
      } else {                                                                                                     // 28
        Votes.update({ _id: castedVote._id }, { $set: { isUpVote: isUpVote } });                                   // 29
      }                                                                                                            // 30
    }                                                                                                              // 31
                                                                                                                   //
    return run;                                                                                                    // 10
  }()                                                                                                              // 10
});                                                                                                                // 10
                                                                                                                   //
// Get list of all method names on Todos                                                                           // 34
var VOTES_METHODS = _.pluck([cast], 'name');                                                                       // 35
                                                                                                                   //
if (Meteor.isServer) {                                                                                             // 37
  // Only allow 5 todos operations per connection per second                                                       // 38
  DDPRateLimiter.addRule({                                                                                         // 39
    name: function () {                                                                                            // 40
      function name(_name) {                                                                                       // 39
        return _.contains(VOTES_METHODS, _name);                                                                   // 41
      }                                                                                                            // 42
                                                                                                                   //
      return name;                                                                                                 // 39
    }(),                                                                                                           // 39
                                                                                                                   //
                                                                                                                   //
    // Rate limit per connection ID                                                                                // 44
    connectionId: function () {                                                                                    // 45
      function connectionId() {                                                                                    // 39
        return true;                                                                                               // 45
      }                                                                                                            // 45
                                                                                                                   //
      return connectionId;                                                                                         // 39
    }()                                                                                                            // 39
  }, 5, 1000);                                                                                                     // 39
}                                                                                                                  // 47
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"votes.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/check","meteor/factory","faker","./votesCountDenormalizer","meteor/aldeed:simple-schema","../events","../ideas/ideas",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/votes/votes.js                                                                                      //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({Votes:function(){return Votes}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Factory;module.import('meteor/factory',{"Factory":function(v){Factory=v}});var faker;module.import('faker',{"default":function(v){faker=v}});var votesCountDenormalizer;module.import('./votesCountDenormalizer',{"default":function(v){votesCountDenormalizer=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var emitter;module.import('../events',{"default":function(v){emitter=v}});var Ideas;module.import('../ideas/ideas',{"Ideas":function(v){Ideas=v}});
                                                                                                                   //
                                                                                                                   //
                                                                                                                   // 1
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   // 4
                                                                                                                   //
                                                                                                                   // 6
                                                                                                                   // 7
                                                                                                                   //
                                                                                                                   // 9
                                                                                                                   //
                                                                                                                   // 11
                                                                                                                   //
var VotesCollection = function (_Mongo$Collection) {                                                               //
  _inherits(VotesCollection, _Mongo$Collection);                                                                   //
                                                                                                                   //
  function VotesCollection() {                                                                                     //
    _classCallCheck(this, VotesCollection);                                                                        //
                                                                                                                   //
    return _possibleConstructorReturn(this, _Mongo$Collection.apply(this, arguments));                             //
  }                                                                                                                //
                                                                                                                   //
  VotesCollection.prototype.insert = function () {                                                                 //
    function insert(doc, callback) {                                                                               //
      var ourDoc = doc;                                                                                            // 16
      ourDoc.createdAt = ourDoc.createdAt || new Date();                                                           // 17
      var result = _Mongo$Collection.prototype.insert.call(this, ourDoc, callback);                                // 18
      votesCountDenormalizer.afterInsertVote(ourDoc);                                                              // 19
                                                                                                                   //
      emitter.emit('ideas.votes', _Mongo$Collection.prototype.findOne.call(this, { _id: result }));                // 21
                                                                                                                   //
      return result;                                                                                               // 23
    }                                                                                                              // 24
                                                                                                                   //
    return insert;                                                                                                 //
  }();                                                                                                             //
                                                                                                                   //
  VotesCollection.prototype.update = function () {                                                                 //
    function update(selector, modifier) {                                                                          //
      var result = _Mongo$Collection.prototype.update.call(this, selector, modifier);                              // 26
      votesCountDenormalizer.afterUpdateVote(selector, modifier);                                                  // 27
                                                                                                                   //
      emitter.emit('ideas.votes', _Mongo$Collection.prototype.findOne.call(this, selector));                       // 29
                                                                                                                   //
      return result;                                                                                               // 31
    }                                                                                                              // 32
                                                                                                                   //
    return update;                                                                                                 //
  }();                                                                                                             //
                                                                                                                   //
  VotesCollection.prototype.remove = function () {                                                                 //
    function remove(selector) {                                                                                    //
      var comments = this.find(selector).fetch();                                                                  // 34
      var result = _Mongo$Collection.prototype.remove.call(this, selector);                                        // 35
      votesCountDenormalizer.afterRemoveVotes(comments);                                                           // 36
      return result;                                                                                               // 37
    }                                                                                                              // 38
                                                                                                                   //
    return remove;                                                                                                 //
  }();                                                                                                             //
                                                                                                                   //
  return VotesCollection;                                                                                          //
}(Mongo.Collection);                                                                                               //
                                                                                                                   //
var Votes = new VotesCollection('votes');                                                                          // 41
                                                                                                                   //
Votes.schema = new SimpleSchema({                                                                                  // 43
  ideaId: {                                                                                                        // 44
    type: String,                                                                                                  // 45
    regEx: SimpleSchema.RegEx.Id,                                                                                  // 46
    denyUpdate: true                                                                                               // 47
  },                                                                                                               // 44
  isUpVote: {                                                                                                      // 49
    type: Boolean                                                                                                  // 50
  },                                                                                                               // 49
  createdAt: {                                                                                                     // 52
    type: Date,                                                                                                    // 53
    denyUpdate: true                                                                                               // 54
  },                                                                                                               // 52
  ownerId: {                                                                                                       // 56
    type: String,                                                                                                  // 57
    regEx: SimpleSchema.RegEx.Id,                                                                                  // 58
    denyUpdate: true                                                                                               // 59
  },                                                                                                               // 56
  ownerName: {                                                                                                     // 61
    type: String,                                                                                                  // 62
    denyUpdate: true                                                                                               // 63
  }                                                                                                                // 61
});                                                                                                                // 43
                                                                                                                   //
Votes.attachSchema(Votes.schema);                                                                                  // 67
                                                                                                                   //
// Deny all client-side updates since we will be using methods to manage this collection                           // 69
Votes.deny({                                                                                                       // 70
  insert: function () {                                                                                            // 71
    function insert() {                                                                                            // 70
      return true;                                                                                                 // 71
    }                                                                                                              // 71
                                                                                                                   //
    return insert;                                                                                                 // 70
  }(),                                                                                                             // 70
  update: function () {                                                                                            // 72
    function update() {                                                                                            // 70
      return true;                                                                                                 // 72
    }                                                                                                              // 72
                                                                                                                   //
    return update;                                                                                                 // 70
  }(),                                                                                                             // 70
  remove: function () {                                                                                            // 73
    function remove() {                                                                                            // 70
      return true;                                                                                                 // 73
    }                                                                                                              // 73
                                                                                                                   //
    return remove;                                                                                                 // 70
  }()                                                                                                              // 70
});                                                                                                                // 70
                                                                                                                   //
Factory.define('Vote', Votes, {});                                                                                 // 76
                                                                                                                   //
Votes.helpers({                                                                                                    // 79
  getIdea: function () {                                                                                           // 80
    function getIdea() {                                                                                           // 79
      return Ideas.findOne(this.ideaId);                                                                           // 81
    }                                                                                                              // 82
                                                                                                                   //
    return getIdea;                                                                                                // 79
  }()                                                                                                              // 79
});                                                                                                                // 79
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"votesCountDenormalizer.js":["meteor/underscore","meteor/check","./votes","../ideas/ideas",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/votes/votesCountDenormalizer.js                                                                     //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var _;module.import('meteor/underscore',{"_":function(v){_=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Votes;module.import('./votes',{"Votes":function(v){Votes=v}});var Ideas;module.import('../ideas/ideas',{"Ideas":function(v){Ideas=v}});
                                                                                                                   // 2
                                                                                                                   //
                                                                                                                   // 4
                                                                                                                   // 5
                                                                                                                   //
function getVotesCount(ideaId, isUpVote) {                                                                         // 7
  return Votes.find({ ideaId: ideaId, isUpVote: isUpVote }).count();                                               // 8
}                                                                                                                  // 9
                                                                                                                   //
var votesCountDenormalizer = {                                                                                     // 11
  _updateIdea: function () {                                                                                       // 12
    function _updateIdea(ideaId) {                                                                                 // 11
      // Recalculate the correct incomplete count direct from MongoDB                                              // 13
      var stats = { upVotes: getVotesCount(ideaId, true), downVotes: getVotesCount(ideaId, false) };               // 14
      Ideas.update(ideaId, { $set: stats });                                                                       // 15
    }                                                                                                              // 16
                                                                                                                   //
    return _updateIdea;                                                                                            // 11
  }(),                                                                                                             // 11
  afterInsertVote: function () {                                                                                   // 17
    function afterInsertVote(vote) {                                                                               // 11
      this._updateIdea(vote.ideaId);                                                                               // 18
    }                                                                                                              // 19
                                                                                                                   //
    return afterInsertVote;                                                                                        // 11
  }(),                                                                                                             // 11
  afterUpdateVote: function () {                                                                                   // 20
    function afterUpdateVote(selector, modifier) {                                                                 // 11
      var _this = this;                                                                                            // 20
                                                                                                                   //
      // We only support very limited operations on todos                                                          // 21
      check(modifier, { $set: Object });                                                                           // 22
                                                                                                                   //
      var votes = Votes.find(selector);                                                                            // 24
      votes.forEach(function (vote) {                                                                              // 25
        return _this._updateIdea(vote.ideaId);                                                                     // 25
      });                                                                                                          // 25
    }                                                                                                              // 26
                                                                                                                   //
    return afterUpdateVote;                                                                                        // 11
  }(),                                                                                                             // 11
                                                                                                                   //
  // Here we need to take the list of todos being removed, selected *before* the update                            // 27
  // because otherwise we can't figure out the relevant list id(s) (if the todo has been deleted)                  // 28
  afterRemoveVotes: function () {                                                                                  // 29
    function afterRemoveVotes(votes) {                                                                             // 11
      var _this2 = this;                                                                                           // 29
                                                                                                                   //
      votes.forEach(function (vote) {                                                                              // 30
        return _this2._updateIdea(vote.ideaId);                                                                    // 30
      });                                                                                                          // 30
    }                                                                                                              // 31
                                                                                                                   //
    return afterRemoveVotes;                                                                                       // 11
  }()                                                                                                              // 11
};                                                                                                                 // 11
                                                                                                                   //
module.export("default",exports.default=(votesCountDenormalizer));                                                 // 34
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"events.js":["events","meteor-node-stubs/deps/events",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/events.js                                                                                           //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var EventEmitter;module.import('events',{"default":function(v){EventEmitter=v}});                                  // 1
module.export("default",exports.default=(new EventEmitter()));                                                     // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"startup":{"server":{"authentication":{"auth-service-providers.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","./base-auth-service-provider",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/startup/server/authentication/auth-service-providers.js                                                 //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({FacebookAuthServiceProvider:function(){return FacebookAuthServiceProvider},GoogleAuthServiceProvider:function(){return GoogleAuthServiceProvider},GitHubAuthServiceProvider:function(){return GitHubAuthServiceProvider}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var BaseAuthServiceProvider;module.import('./base-auth-service-provider',{"BaseAuthServiceProvider":function(v){BaseAuthServiceProvider=v}});
                                                                                                                   //
                                                                                                                   //
                                                                                                                   // 1
                                                                                                                   //
var FacebookAuthServiceProvider = function (_BaseAuthServiceProvi) {                                               // 3
    _inherits(FacebookAuthServiceProvider, _BaseAuthServiceProvi);                                                 // 3
                                                                                                                   //
    function FacebookAuthServiceProvider() {                                                                       // 4
        _classCallCheck(this, FacebookAuthServiceProvider);                                                        // 4
                                                                                                                   //
        return _possibleConstructorReturn(this, _BaseAuthServiceProvi.call(this, 'facebook'));                     // 4
    }                                                                                                              // 6
                                                                                                                   //
    FacebookAuthServiceProvider.prototype.configure = function () {                                                // 3
        function configure() {                                                                                     // 3
            ServiceConfiguration.configurations.upsert({ service: this.serviceProviderName }, {                    // 9
                $set: {                                                                                            // 12
                    appId: process.env.FACEBOOK_CLIENTID,                                                          // 13
                    loginStyle: process.env.LOGIN_STYLE,                                                           // 14
                    secret: process.env.FACEBOOK_CLIENTSECRET                                                      // 15
                }                                                                                                  // 12
            });                                                                                                    // 11
        }                                                                                                          // 18
                                                                                                                   //
        return configure;                                                                                          // 3
    }();                                                                                                           // 3
                                                                                                                   //
    return FacebookAuthServiceProvider;                                                                            // 3
}(BaseAuthServiceProvider);                                                                                        // 3
                                                                                                                   //
var GoogleAuthServiceProvider = function (_BaseAuthServiceProvi2) {                                                // 22
    _inherits(GoogleAuthServiceProvider, _BaseAuthServiceProvi2);                                                  // 22
                                                                                                                   //
    function GoogleAuthServiceProvider() {                                                                         // 23
        _classCallCheck(this, GoogleAuthServiceProvider);                                                          // 23
                                                                                                                   //
        return _possibleConstructorReturn(this, _BaseAuthServiceProvi2.call(this, 'google'));                      // 23
    }                                                                                                              // 25
                                                                                                                   //
    GoogleAuthServiceProvider.prototype.configure = function () {                                                  // 22
        function configure() {                                                                                     // 22
            ServiceConfiguration.configurations.upsert({ service: this.serviceProviderName }, {                    // 28
                $set: {                                                                                            // 31
                    appId: process.env.GOOGLE_CLIENTID,                                                            // 32
                    loginStyle: process.env.LOGIN_STYLE,                                                           // 33
                    secret: process.env.GOOGLE_CLIENTSECRET                                                        // 34
                }                                                                                                  // 31
            });                                                                                                    // 30
        }                                                                                                          // 37
                                                                                                                   //
        return configure;                                                                                          // 22
    }();                                                                                                           // 22
                                                                                                                   //
    return GoogleAuthServiceProvider;                                                                              // 22
}(BaseAuthServiceProvider);                                                                                        // 22
                                                                                                                   //
var GitHubAuthServiceProvider = function (_BaseAuthServiceProvi3) {                                                // 40
    _inherits(GitHubAuthServiceProvider, _BaseAuthServiceProvi3);                                                  // 40
                                                                                                                   //
    function GitHubAuthServiceProvider() {                                                                         // 41
        _classCallCheck(this, GitHubAuthServiceProvider);                                                          // 41
                                                                                                                   //
        return _possibleConstructorReturn(this, _BaseAuthServiceProvi3.call(this, 'github'));                      // 41
    }                                                                                                              // 43
                                                                                                                   //
    GitHubAuthServiceProvider.prototype.configure = function () {                                                  // 40
        function configure() {                                                                                     // 40
            ServiceConfiguration.configurations.upsert({ service: this.serviceProviderName }, {                    // 46
                $set: {                                                                                            // 49
                    appId: process.env.GITHUB_CLIENTID,                                                            // 50
                    loginStyle: process.env.LOGIN_STYLE,                                                           // 51
                    secret: process.env.GITHUB_CLIENTSECRET                                                        // 52
                }                                                                                                  // 49
            });                                                                                                    // 48
        }                                                                                                          // 55
                                                                                                                   //
        return configure;                                                                                          // 40
    }();                                                                                                           // 40
                                                                                                                   //
    return GitHubAuthServiceProvider;                                                                              // 40
}(BaseAuthServiceProvider);                                                                                        // 40
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"base-auth-service-provider.js":["babel-runtime/helpers/classCallCheck",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/startup/server/authentication/base-auth-service-provider.js                                             //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({BaseAuthServiceProvider:function(){return BaseAuthServiceProvider}});var _classCallCheck;module.import("babel-runtime/helpers/classCallCheck",{"default":function(v){_classCallCheck=v}});
var BaseAuthServiceProvider = function () {                                                                        // 1
    function BaseAuthServiceProvider(serviceProviderName) {                                                        // 3
        _classCallCheck(this, BaseAuthServiceProvider);                                                            // 3
                                                                                                                   //
        this.serviceProviderName = serviceProviderName;                                                            // 4
    }                                                                                                              // 5
                                                                                                                   //
    BaseAuthServiceProvider.prototype.configure = function () {                                                    // 1
        function configure() {}                                                                                    // 1
                                                                                                                   //
        return configure;                                                                                          // 1
    }();                                                                                                           // 1
                                                                                                                   //
    BaseAuthServiceProvider.prototype.getUser = function () {                                                      // 1
        function getUser(options, user) {                                                                          // 1
                                                                                                                   //
            //Modules.server.sendWelcomeEmail(user, profile);                                                      // 13
                                                                                                                   //
            var details = this.getUserDetails(options, user);                                                      // 15
                                                                                                                   //
            if (details.fullName) {                                                                                // 17
                var profile = options.profile;                                                                     // 18
                                                                                                                   //
                profile && (profile.fullName = details.fullName);                                                  // 20
                                                                                                                   //
                user.profile = profile;                                                                            // 22
            }                                                                                                      // 23
                                                                                                                   //
            if (details.email) {                                                                                   // 25
                user.emails = [{                                                                                   // 26
                    address: details.email,                                                                        // 27
                    verified: false                                                                                // 28
                }];                                                                                                // 26
            }                                                                                                      // 30
                                                                                                                   //
            return user;                                                                                           // 32
        }                                                                                                          // 33
                                                                                                                   //
        return getUser;                                                                                            // 1
    }();                                                                                                           // 1
                                                                                                                   //
    BaseAuthServiceProvider.prototype.getUserDetails = function () {                                               // 1
        function getUserDetails(options, user) {                                                                   // 1
            var profile = options.profile;                                                                         // 36
                                                                                                                   //
            var fullName = profile && profile.name;                                                                // 38
                                                                                                                   //
            var detailsFromService = this.getService(user);                                                        // 40
            var email = detailsFromService && detailsFromService.email;                                            // 41
                                                                                                                   //
            return { fullName: fullName, email: email };                                                           // 43
        }                                                                                                          // 44
                                                                                                                   //
        return getUserDetails;                                                                                     // 1
    }();                                                                                                           // 1
                                                                                                                   //
    BaseAuthServiceProvider.prototype.getService = function () {                                                   // 1
        function getService(user) {                                                                                // 1
            return user && user.services && user.services[this.serviceProviderName] || {};                         // 47
        }                                                                                                          // 48
                                                                                                                   //
        return getService;                                                                                         // 1
    }();                                                                                                           // 1
                                                                                                                   //
    return BaseAuthServiceProvider;                                                                                // 1
}();                                                                                                               // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"migrations":{"1.js":["../../../api/profiles/profiles","../../../api/profiles/methods","../../../api/ideas/ideas",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/startup/server/migrations/1.js                                                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var Profiles;module.import('../../../api/profiles/profiles',{"Profiles":function(v){Profiles=v}});var update;module.import('../../../api/profiles/methods',{"update":function(v){update=v}});var Ideas;module.import('../../../api/ideas/ideas',{"Ideas":function(v){Ideas=v}});
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   //
Migrations.add({                                                                                                   // 6
    version: 1,                                                                                                    // 7
    up: function () {                                                                                              // 8
        function up() {                                                                                            // 8
            console.log('creating user profiles');                                                                 // 9
                                                                                                                   //
            Meteor.users.find({}).forEach(function (user) {                                                        // 11
                                                                                                                   //
                var profile = Profiles.findOne({ ownerId: user._id });                                             // 13
                                                                                                                   //
                if (profile) {                                                                                     // 15
                    return;                                                                                        // 15
                }                                                                                                  // 15
                                                                                                                   //
                var ideasCount = Ideas.find({ ownerId: user._id }).count();                                        // 17
                                                                                                                   //
                Profiles.insert({                                                                                  // 19
                    userName: user.emails[0].address.split('@')[0],                                                // 20
                    ownerId: user._id,                                                                             // 21
                    ideasCount: ideasCount                                                                         // 22
                });                                                                                                // 19
            });                                                                                                    // 24
        }                                                                                                          // 25
                                                                                                                   //
        return up;                                                                                                 // 8
    }()                                                                                                            // 8
});                                                                                                                // 6
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"2.js":["../../../api/activities/activities","../../../api/ideas/ideas","../../../api/idea-comments/idea-comments","../../../api/votes/votes",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/startup/server/migrations/2.js                                                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var Activities;module.import('../../../api/activities/activities',{"Activities":function(v){Activities=v}});var Ideas;module.import('../../../api/ideas/ideas',{"Ideas":function(v){Ideas=v}});var IdeaComments;module.import('../../../api/idea-comments/idea-comments',{"IdeaComments":function(v){IdeaComments=v}});var Votes;module.import('../../../api/votes/votes',{"Votes":function(v){Votes=v}});
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   // 4
                                                                                                                   //
Migrations.add({                                                                                                   // 8
    version: 2,                                                                                                    // 9
    up: function () {                                                                                              // 10
        function up() {                                                                                            // 10
                                                                                                                   //
            Meteor.users.find({}).forEach(function (user) {                                                        // 12
                                                                                                                   //
                console.log('generating activity timeline for ideas');                                             // 14
                generateActivityTimelineForIdeas(user);                                                            // 15
                                                                                                                   //
                console.log('generating activity timeline for idea comments');                                     // 17
                generateActivityTimelineForIdeaComments(user);                                                     // 18
                                                                                                                   //
                console.log('generating activity timeline for idea likes/dislikes');                               // 20
                generateActivityTimelineForIdeaEmotions(user);                                                     // 21
            });                                                                                                    // 23
        }                                                                                                          // 24
                                                                                                                   //
        return up;                                                                                                 // 10
    }()                                                                                                            // 10
});                                                                                                                // 8
                                                                                                                   //
function generateActivityTimelineForIdeas(user) {                                                                  // 27
    Ideas.find({ ownerId: user._id }).forEach(function (idea) {                                                    // 28
        Activities.insert({                                                                                        // 29
            type: 'ideas.create',                                                                                  // 30
            body: idea.name,                                                                                       // 31
            itemId: idea._id,                                                                                      // 32
            itemOwnerId: idea.ownerId,                                                                             // 33
            ownerId: user._id,                                                                                     // 34
            ownerName: user.profile.fullName,                                                                      // 35
            createdAt: idea.createdAt                                                                              // 36
        });                                                                                                        // 29
    });                                                                                                            // 38
}                                                                                                                  // 39
                                                                                                                   //
function generateActivityTimelineForIdeaComments(user) {                                                           // 41
    IdeaComments.find({ ownerId: user._id }).forEach(function (comment) {                                          // 42
        Activities.insert({                                                                                        // 43
            type: 'ideas.comments.create',                                                                         // 44
            body: comment.text,                                                                                    // 45
            itemId: comment._id,                                                                                   // 46
            itemOwnerId: comment.ownerId,                                                                          // 47
            itemDetails: { ideaId: comment.ideaId },                                                               // 48
            ownerId: user._id,                                                                                     // 49
            ownerName: user.profile.fullName,                                                                      // 50
            createdAt: comment.createdAt,                                                                          // 51
            targetOwnerId: comment.getIdea().ownerId                                                               // 52
        });                                                                                                        // 43
    });                                                                                                            // 54
}                                                                                                                  // 55
                                                                                                                   //
function generateActivityTimelineForIdeaEmotions(user) {                                                           // 57
    Votes.find({ ownerId: user._id }).forEach(function (vote) {                                                    // 58
        Activities.insert({                                                                                        // 59
            type: 'ideas.votes',                                                                                   // 60
            body: '',                                                                                              // 61
            itemId: vote._id,                                                                                      // 62
            itemOwnerId: vote.ownerId,                                                                             // 63
            itemDetails: { ideaId: vote.ideaId, isUpVote: vote.isUpVote },                                         // 64
            ownerId: user._id,                                                                                     // 65
            ownerName: user.profile.fullName,                                                                      // 66
            createdAt: vote.createdAt,                                                                             // 67
            targetOwnerId: vote.getIdea().ownerId                                                                  // 68
        });                                                                                                        // 59
    });                                                                                                            // 70
}                                                                                                                  // 71
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"3.js":["../../../api/profiles/profiles",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/startup/server/migrations/3.js                                                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var Profiles;module.import('../../../api/profiles/profiles',{"Profiles":function(v){Profiles=v}});                 //
                                                                                                                   // 2
                                                                                                                   //
Migrations.add({                                                                                                   // 4
    version: 3,                                                                                                    // 5
    up: function () {                                                                                              // 6
        function up() {                                                                                            // 6
            console.log('add default profile picture to all profiles');                                            // 7
            Profiles.find({}).forEach(function (profile) {                                                         // 8
                Profiles.update({ _id: profile._id }, {                                                            // 9
                    $set: {                                                                                        // 10
                        profileImage: 'https://www.gravatar.com/avatar/00000000000000000000000000000000'           // 11
                    }                                                                                              // 10
                });                                                                                                // 9
            });                                                                                                    // 14
        }                                                                                                          // 15
                                                                                                                   //
        return up;                                                                                                 // 6
    }()                                                                                                            // 6
});                                                                                                                // 4
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"config.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/startup/server/migrations/config.js                                                                     //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
Migrations.config({                                                                                                // 1
  // Log job run details to console                                                                                // 2
  log: true,                                                                                                       // 3
                                                                                                                   //
  // Use a custom logger function (defaults to Meteor's logging package)                                           // 5
  logger: null,                                                                                                    // 6
                                                                                                                   //
  // Enable/disable logging "Not migrating, already at version {number}"                                           // 8
  logIfLatest: true,                                                                                               // 9
                                                                                                                   //
  // migrations collection name to use in the database                                                             // 11
  collectionName: "migrations"                                                                                     // 12
});                                                                                                                // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":["./config","./1","./2","./3",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/startup/server/migrations/index.js                                                                      //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.import('./config');module.import('./1');module.import('./2');module.import('./3');                          // 1
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   // 4
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"fixtures.js":["meteor/meteor","../../api/ideas/ideas","../../api/idea-comments/idea-comments","../../api/votes/votes",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/startup/server/fixtures.js                                                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Ideas;module.import('../../api/ideas/ideas',{"Ideas":function(v){Ideas=v}});var IdeaComments;module.import('../../api/idea-comments/idea-comments',{"IdeaComments":function(v){IdeaComments=v}});var Votes;module.import('../../api/votes/votes',{"Votes":function(v){Votes=v}});
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   // 4
                                                                                                                   //
Meteor.startup(function () {});                                                                                    // 8
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["meteor/meteor","./fixtures.js","./reset-password-email.js","./security.js","./register-api.js","./migrations/index",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/startup/server/index.js                                                                                 //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});module.import('./fixtures.js');module.import('./reset-password-email.js');module.import('./security.js');module.import('./register-api.js');module.import('./migrations/index');
//import { BrowserPolicy } from 'meteor/browser-policy';                                                           // 2
                                                                                                                   //
// This defines a starting set of data to be loaded if the app is loaded with an empty db.                         // 4
                                                                                                                   // 5
                                                                                                                   //
// This file configures the Accounts package to define the UI of the reset password email.                         // 7
                                                                                                                   // 8
                                                                                                                   //
// Set up some rate limiting and other important security settings.                                                // 10
                                                                                                                   // 11
                                                                                                                   //
// This defines all the collections, publications and methods that the application provides                        // 13
// as an API to the client.                                                                                        // 14
                                                                                                                   // 15
                                                                                                                   //
                                                                                                                   // 17
                                                                                                                   //
Meteor.startup(function () {                                                                                       // 21
    Migrations.migrateTo('latest');                                                                                // 22
                                                                                                                   //
    ['fonts.googleapis.com', 'fonts.gstatic.com', 'cdnjs.cloudflare.com', 'www.gravatar.com', 'at.alicdn.com'].forEach(function (origin) {
        return BrowserPolicy.content.allowOriginForAll(origin);                                                    // 29
    });                                                                                                            // 29
});                                                                                                                // 31
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"register-api.js":["../../api/events","../../api/ideas/methods","../../api/ideas/server/publications","../../api/teams/methods","../../api/teams/server/publications","../../api/sprints/methods","../../api/sprints/server/publications","../../api/idea-comments/methods","../../api/idea-comments/server/publications","../../api/votes/methods","../../api/followers/followers","../../api/followers/methods","../../api/followers/server/publications","../../api/profiles/profiles","../../api/profiles/methods","../../api/profiles/server/publications","../../api/activities/activities","../../api/activities/methods","../../api/activities/server/publications","../../api/activities/server/receiver",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/startup/server/register-api.js                                                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.import('../../api/events');module.import('../../api/ideas/methods');module.import('../../api/ideas/server/publications');module.import('../../api/teams/methods');module.import('../../api/teams/server/publications');module.import('../../api/sprints/methods');module.import('../../api/sprints/server/publications');module.import('../../api/idea-comments/methods');module.import('../../api/idea-comments/server/publications');module.import('../../api/votes/methods');module.import('../../api/followers/followers');module.import('../../api/followers/methods');module.import('../../api/followers/server/publications');module.import('../../api/profiles/profiles');module.import('../../api/profiles/methods');module.import('../../api/profiles/server/publications');module.import('../../api/activities/activities');module.import('../../api/activities/methods');module.import('../../api/activities/server/publications');module.import('../../api/activities/server/receiver');
                                                                                                                   //
                                                                                                                   // 3
                                                                                                                   // 4
                                                                                                                   //
                                                                                                                   // 6
                                                                                                                   // 7
                                                                                                                   //
                                                                                                                   // 9
                                                                                                                   // 10
                                                                                                                   //
                                                                                                                   // 12
                                                                                                                   // 13
                                                                                                                   //
                                                                                                                   // 15
                                                                                                                   //
                                                                                                                   // 17
                                                                                                                   // 18
                                                                                                                   // 19
                                                                                                                   //
                                                                                                                   // 21
                                                                                                                   // 22
                                                                                                                   // 23
                                                                                                                   //
                                                                                                                   // 26
                                                                                                                   // 27
                                                                                                                   // 28
                                                                                                                   // 29
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"reset-password-email.js":["meteor/accounts-base",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/startup/server/reset-password-email.js                                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});                           // 1
                                                                                                                   //
Accounts.emailTemplates.siteName = 'Idea Dashboard';                                                               // 4
Accounts.emailTemplates.from = 'Ideas Dashboard <accounts@example.com>';                                           // 5
                                                                                                                   //
Accounts.emailTemplates.resetPassword = {                                                                          // 7
  subject: function () {                                                                                           // 8
    function subject() {                                                                                           // 7
      return 'Reset your password on Idea Dashboard';                                                              // 9
    }                                                                                                              // 10
                                                                                                                   //
    return subject;                                                                                                // 7
  }(),                                                                                                             // 7
  text: function () {                                                                                              // 11
    function text(user, url) {                                                                                     // 7
      return 'Hello!\n\nClick the link below to reset your password on Idea Dashboard.\n\n' + url + '\n\nIf you didn\'t request this email, please ignore it.\n\nThanks,\nThe Idea Dashboard Team\n';
    }                                                                                                              // 23
                                                                                                                   //
    return text;                                                                                                   // 7
  }()                                                                                                              // 7
};                                                                                                                 // 7
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"security.js":["meteor/meteor","meteor/ddp-rate-limiter","meteor/underscore","./authentication/auth-service-providers","../../api/profiles/profiles",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/startup/server/security.js                                                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var DDPRateLimiter;module.import('meteor/ddp-rate-limiter',{"DDPRateLimiter":function(v){DDPRateLimiter=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var FacebookAuthServiceProvider,GoogleAuthServiceProvider,GitHubAuthServiceProvider;module.import('./authentication/auth-service-providers',{"FacebookAuthServiceProvider":function(v){FacebookAuthServiceProvider=v},"GoogleAuthServiceProvider":function(v){GoogleAuthServiceProvider=v},"GitHubAuthServiceProvider":function(v){GitHubAuthServiceProvider=v}});var Profiles;module.import('../../api/profiles/profiles',{"Profiles":function(v){Profiles=v}});
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   // 4
                                                                                                                   // 5
                                                                                                                   //
// Don't let people write arbitrary data to their 'profile' field from the client                                  // 7
Meteor.users.deny({                                                                                                // 8
  update: function () {                                                                                            // 9
    function update() {                                                                                            // 8
      return true;                                                                                                 // 10
    }                                                                                                              // 11
                                                                                                                   //
    return update;                                                                                                 // 8
  }()                                                                                                              // 8
});                                                                                                                // 8
                                                                                                                   //
// Get a list of all accounts methods by running `Meteor.server.method_handlers` in meteor shell                   // 14
var AUTH_METHODS = ['login', 'logout', 'logoutOtherClients', 'getNewToken', 'removeOtherTokens', 'configureLoginService', 'changePassword', 'forgotPassword', 'resetPassword', 'verifyEmail', 'createUser', 'ATRemoveService', 'ATCreateUserServer', 'ATResendVerificationEmail'];
                                                                                                                   //
if (Meteor.isServer) {                                                                                             // 32
  (function () {                                                                                                   // 32
    // Only allow 2 login attempts per connection per 5 seconds                                                    // 33
    DDPRateLimiter.addRule({                                                                                       // 34
      name: function () {                                                                                          // 35
        function name(_name) {                                                                                     // 34
          return _.contains(AUTH_METHODS, _name);                                                                  // 36
        }                                                                                                          // 37
                                                                                                                   //
        return name;                                                                                               // 34
      }(),                                                                                                         // 34
                                                                                                                   //
                                                                                                                   //
      // Rate limit per connection ID                                                                              // 39
      connectionId: function () {                                                                                  // 40
        function connectionId() {                                                                                  // 34
          return true;                                                                                             // 40
        }                                                                                                          // 40
                                                                                                                   //
        return connectionId;                                                                                       // 34
      }()                                                                                                          // 34
    }, 2, 5000);                                                                                                   // 34
                                                                                                                   //
    console.log('configuring external authentication services');                                                   // 44
                                                                                                                   //
    var providers = [new FacebookAuthServiceProvider(), new GoogleAuthServiceProvider(), new GitHubAuthServiceProvider()];
                                                                                                                   //
    providers.forEach(function (provider) {                                                                        // 50
      return provider.configure();                                                                                 // 50
    });                                                                                                            // 50
                                                                                                                   //
    Accounts.onCreateUser(function (options, user) {                                                               // 54
                                                                                                                   //
      user.profile = options.profile;                                                                              // 56
      providers.forEach(function (p) {                                                                             // 57
        return user = p.getUser(options, user);                                                                    // 57
      });                                                                                                          // 57
                                                                                                                   //
      return user;                                                                                                 // 59
    });                                                                                                            // 60
                                                                                                                   //
    //TODO: remove the following hook once the profile editing feature is implemented                              // 63
    Accounts.onLogin(function () {                                                                                 // 64
                                                                                                                   //
      var user = Meteor.user();                                                                                    // 66
      var userName = user.emails[0].address.split('@')[0];                                                         // 67
                                                                                                                   //
      var profile = Profiles.findOne({ ownerId: user._id });                                                       // 69
                                                                                                                   //
      if (profile) {                                                                                               // 71
        return;                                                                                                    // 72
      }                                                                                                            // 72
                                                                                                                   //
      console.log('logged in user', user);                                                                         // 74
                                                                                                                   //
      Profiles.insert({                                                                                            // 76
        userName: userName,                                                                                        // 77
        ownerId: user._id                                                                                          // 78
      });                                                                                                          // 76
    });                                                                                                            // 80
  })();                                                                                                            // 32
}                                                                                                                  // 81
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}},"i18n":{"en.i18n.json":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// i18n/en.i18n.json                                                                                               //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n._enable({"helper_name":"_","supported_languages":null,"i18n_files_route":"/tap-i18n","preloaded_langs":[],"cdn_path":null});
TAPi18n.languages_names["en"] = ["English","English"];
// integrate the fallback language translations 
translations = {};
translations[namespace] = {"lists":{"makePrivate":{"notLoggedIn":"Must be logged in to make private lists.","lastPublicList":"Cannot make the last public list private."},"makePublic":{"notLoggedIn":"Must be logged in.","accessDenied":"You don't have permission to edit this list."},"updateName":{"accessDenied":"You don't have permission to edit this list."},"remove":{"accessDenied":"'You don't have permission to remove this list.'","lastPublicList":"Cannot delete the last public list."}},"todos":{"insert":{"accessDenied":"Cannot add todos to a private list that is not yours"},"setCheckedStatus":{"accessDenied":"Cannot edit todos in a private list that is not yours"},"updateText":{"accessDenied":"Cannot edit todos in a private list that is not yours"},"remove":{"accessDenied":"Cannot remove todos in a private list that is not yours"}}};
TAPi18n._loadLangFileObject("en", translations);
TAPi18n._registerServerTranslator("en", namespace);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":["/imports/startup/server",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/main.js                                                                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.import('/imports/startup/server');                                                                          // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./i18n/en.i18n.json");
require("./server/main.js");
//# sourceMappingURL=app.js.map
