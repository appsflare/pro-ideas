(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var UniHTML = Package['vazco:universe-html-purifier'].UniHTML;
var UniUtils = Package['universe:utilities'].UniUtils;
var UniConfig = Package['universe:utilities'].UniConfig;
var ECMAScript = Package.ecmascript.ECMAScript;
var _ = Package.underscore._;
var Showdown = Package.markdown.Showdown;
var _i18n = Package['universe:i18n']._i18n;
var i18n = Package['universe:i18n'].i18n;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"universe:react-markdown-wysiwyg":{"check.deps.js":["meteor/cristo:auto-install-npm",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/universe_react-markdown-wysiwyg/check.deps.js                                                     //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var autoInstallNpm;module.import('meteor/cristo:auto-install-npm',{"default":function(v){autoInstallNpm=v}});
                                                                                                              //
autoInstallNpm({                                                                                              // 3
    'to-markdown': '1.3.0',                                                                                   // 4
    'collapse-whitespace': '1.1.2',                                                                           // 5
    'medium-editor': '5.x',                                                                                   // 6
    'rc-tabs': '5.8.x',                                                                                       // 7
    'parse5': '1.3.1'                                                                                         // 8
}, 'universe:react-markdown-wysiwyg');                                                                        // 3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"en.i18n.yml.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/universe_react-markdown-wysiwyg/en.i18n.yml.js                                                    //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
Package['universe:i18n'].i18n.addTranslations('en','universe:react-markdown-wysiwyg',{"markdown":"Markdown","typeYourText":"Type your text","visual":"Visual"});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json",".i18n.yml",".jsx"]});
require("./node_modules/meteor/universe:react-markdown-wysiwyg/check.deps.js");
require("./node_modules/meteor/universe:react-markdown-wysiwyg/en.i18n.yml.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['universe:react-markdown-wysiwyg'] = {};

})();

//# sourceMappingURL=universe_react-markdown-wysiwyg.js.map
